@echo off
setlocal
cd /d "%~dp0backend"
python --version >nul 2>&1
if errorlevel 1 (
 echo Install Python with Add Python to PATH enabled, then run this again.
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
if not exist ".env" (
 copy .env.example .env >nul
 echo.
 echo Edit backend\.env with your MySQL password and admin credentials.
 echo If you already have a working .env, copy it here instead.
 notepad .env
)
echo.
echo Create the MySQL database nexzibyte_attendance if this is a new installation.
echo Then run START_BACKEND.cmd and START_FRONTEND.cmd in separate windows.
pause
exit /b 0
:failed
echo Setup failed. Keep this window open and share the complete error.
pause
exit /b 1
