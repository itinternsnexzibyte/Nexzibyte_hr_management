# Payroll calculation and payslip editor fixes

- Removed the mandatory marker and required validation from **Days worked**. It is calculated from the selected method.
- At least one of the net-working-time or recorded-days calculation checkboxes must be selected.
- Added configurable **Hours per working day** (default 8, adjustable from 0.25 to 24). Net working seconds are converted to decimal-equivalent working days using this value; breaks remain excluded because the calculation uses recorded net working seconds.
- When net working time is selected, Days worked shows the net-time equivalent (including decimals). Otherwise it shows the number of distinct recorded attendance dates.
- Payroll save no longer re-renders the whole workspace, so the editable payslip stays open after saving.
- **Save payslip edits** saves the edited preview with the payroll record. Export uses the current edited preview; if the PDF renderer cannot load, the print dialog fallback contains the edited content.
- Backend payroll calculations use the same configurable hours-per-day value.
