# Payroll and email fixes

## Included
- Calendar selection is remembered in the browser until another intern is selected.
- Payroll days-worked defaults from the selected intern's attendance dates marked Present, while remaining editable.
- Total working days remains editable.
- Added an all-payroll-records view with status filtering.
- Payslip editor is named **Edit payslip** and its edited HTML is included when payroll is saved and when the email attachment is generated.
- Email send errors are no longer silently treated as successful; SMTP timeout increased to 15 seconds.
- Added secure `.env.example` instructions for Gmail SMTP.

## Important setup
1. Keep your actual `backend/.env` local; it is not distributed in this archive.
2. Gmail requires a Google App Password, not your regular Gmail password.
3. Restart the backend after changing `.env`.
4. For a real PDF download, click **Save payslip as PDF**, then choose **Save as PDF** in the browser print dialog. The site cannot silently save a PDF without a browser user action.
5. Validate SMTP by saving a payroll with the email checkbox enabled and check the backend terminal if delivery fails.

## Security
The SMTP password pasted into the chat should be revoked and replaced with a new Google App Password. Do not share or commit that password.
