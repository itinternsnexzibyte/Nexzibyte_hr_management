# Payroll editing and PDF email update

This update fixes the payroll form's numeric payload normalization, live calculation preview, draft-only payslip edits, saved-record View & Edit access, per-record change summaries, and PDF email attachments.

## Notes
- The payroll form recalculates its amounts while entering values. The editable payslip preview follows form changes until the admin manually edits the preview text.
- `Save payslip edits` saves a browser draft only. `Save payroll` is the explicit action that persists payroll data and sends email when the email checkbox is selected.
- Email attachments are PDF files. When the browser PDF renderer is available, the PDF exported from the payslip preview is sent. If it is unavailable, the backend creates a readable PDF fallback from the saved payroll fields.
- Change summaries are stored in the backend payroll JSON record history for edits to an existing intern/month record. Older records may not have a historical summary for changes made before this update.
- Install backend dependencies after updating: `python -m pip install -r requirements.txt`.
