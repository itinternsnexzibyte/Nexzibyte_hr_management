# NexziByte Workforce Workspace — SaaS update

A shared warm cream / yellow / charcoal workspace for administrators and interns,
modeled on the supplied reference video's palette, rounded surfaces, top navigation,
people table, profile panel and calendar. Responsive layouts support laptops and phones.

## Run on Windows

1. Extract this ZIP into a **new folder**. Do not run it from inside the ZIP.
2. If you already ran the previous project, copy its **working backend/.env** into
   this project's backend folder. Keep the same DATABASE_URL and SECRET_KEY.
3. Copy the previous **backend/storage** directory into the new backend/storage,
   merging its files. The database stores filenames; keeping these files preserves
   document and photo downloads. Do not delete your existing MySQL database.
4. Double-click **SETUP_WINDOWS.cmd** and wait until installation completes.
   It creates a fresh `.venv`; old copied environments are not included.
5. Double-click **START_BACKEND.cmd**. Wait for `Application startup complete`.
6. Double-click **START_FRONTEND.cmd**. Open http://localhost:5500/login.html.
7. Keep both server windows open. Log in with your existing credentials.

For a new installation, install Python and MySQL Server, then create the database
in MySQL Workbench:

```sql
CREATE DATABASE IF NOT EXISTS nexzibyte_attendance
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Copy `backend/.env.example` to `backend/.env`, set your MySQL password,
ADMIN_EMAIL, ADMIN_INITIAL_PASSWORD and SECRET_KEY, then run the scripts above.
Generate a secret with `python -c "import secrets; print(secrets.token_hex(32))"`.
Percent-encode special characters in the database password: `@` becomes `%40`.
The seed command creates the admin only if it does not already exist; changing
ADMIN_INITIAL_PASSWORD does not reset an existing account's password.

### PowerShell commands (if you prefer terminals)

From this project's backend directory:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m app.seed
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

In a second PowerShell window, from the frontend directory:

```powershell
python -m http.server 5500
```

API health: http://127.0.0.1:8000/api/health
API documentation: http://127.0.0.1:8000/docs

## What changed

- Removed “Search this page” and theme controls across the portals.
- Rebuilt admin/intern dashboards and all management tabs with the same warm UI.
- Admin name displays as **Admin**, including the dashboard and account menu.
  Company branding remains NEXZIBYTE SOLUTIONS.
- Calendar events are persisted in the database. Admin can create/edit/cancel
  events, select all active interns or one intern, and choose a calendar color.
- Each event save/update creates notifications for its recipients. Cancelling an
  event or removing a recipient also notifies affected interns.
- Assignments notify only the assigned intern; edits, reassignment and removal
  also notify affected interns.
- Interns have a notification bell, unread count, notification history and read
  controls. Notifications update automatically every **10 seconds** while the
  tab is visible, and on focus. Clicking one opens its work/calendar screen.
- Profile photo upload on the intern dashboard accepts JPG, PNG or WebP up to
  5 MB. Images are validated and converted to JPG. Both portals load the same
  authenticated image; admin People shows it between Intern ID and Name.
- Clicking an intern's photo opens full details, linked documents including
  registration offer letters, attendance/break history, assignments and ratings.
- Intern Break in starts a break; Break out ends it. Multiple breaks per day are
  supported, with each pair of timestamps and the cumulative duration visible.
- Attendance lists one record per intern/date. Logging in again on the same day
  resumes a new work session within that daily record. Breaks and repeat logins
  do not add to the attendance headcount.
- Net work = time across work sessions minus break time. Signed-out intervals
  are excluded. Checkout closes a running break. Sessions crossing midnight
  are capped at midnight for the previous India calendar day.
- Admin attendance has date/intern filters and per-break details. The dashboard
  shows unique people present and the sum of today's break time.
- Existing legacy attendance rows remain in the database and are grouped for
  display; overlapping legacy sessions are counted once. Historical periods
  with no recorded timestamps cannot be reconstructed exactly.
- New tables are created automatically on backend startup. Existing application
  tables do not need new columns. Back up your database before an upgrade.
- Added the missing MySQL driver plus timezone/image dependencies. No copied
  virtual environment, database passwords, or test data are shipped.

## Email and registration

Existing email OTP, registration, offer-letter upload, admin approval and password
reset flows remain available. Configure EMAIL_HOST, EMAIL_USERNAME, EMAIL_PASSWORD,
EMAIL_FROM and EMAIL_USE_TLS in `.env` for real email delivery. With no EMAIL_HOST
or EMAIL_FROM, emails/OTPs print to the backend terminal for local development.
Site bell notifications do not depend on SMTP.

New interns verify their email and register with their offer letter. Admin approves
from Approvals. Existing admin-created interns follow the email setup link flow.
The original supplied offer letters and storage files are retained in this package.

## Verification

`python -m pytest -q` from backend runs health and workflow tests. The tests cover
repeat logins, multiple breaks, checkout, midnight, calendar notification recipients,
read ownership, assignment access, submissions, image validation, photo permissions,
legacy duplicate aggregation and date filters. They use SQLite, not your live database.

Manual review: create/edit an event in admin; keep the intern dashboard open and
wait up to 10 seconds; check the bell and colored calendar. Assign work to one intern
and verify that other interns do not receive it. Upload an intern photo and open it
from the admin People page. Record two breaks and check the selected date's totals.

This is a local application. Closing a browser tab alone does not check out;
use Check out or Sign out to record the end of the work session.

### Attendance session monitoring (latest update)
- Switching to another browser tab does not itself trigger a checkout email. The frontend continues sending heartbeat requests while the intern page is hidden.
- Automatic checkout runs after 120 seconds without a heartbeat, which helps avoid false checkouts caused by browser background-tab throttling.
- Closing the tab, losing connectivity, or shutting down the device can be detected only after heartbeats stop; email delivery also depends on the backend and mail provider being available.


## Attendance disconnection alerts (latest update)
- Heartbeat watchdog checks once per second and marks a session inactive after 8 seconds without a heartbeat.
- Switching browser tabs is not directly treated as an attendance violation; background browser throttling may still affect heartbeat timing.
- Emails include intern/session details and the last recorded GPS coordinates with a Google Maps URL when GPS was captured.
- Branded HTML email uses the Nexzibyte logo inline when available.
- Email delivery time still depends on SMTP/provider/network; under-10-second delivery cannot be guaranteed for internet loss or shutdown because those events must first be detected by heartbeat timeout.
- Admin approvals require an authenticated administrator session in the Admin Approvals portal.


## Calendar payroll (updated)

Payroll is available only from **Calendar** in the admin portal. Open Calendar and select an intern; the first intern is selected automatically on initial load. Enter salary earnings and deductions, choose Pending / Under Review / Approved / Rejected / Paid, then save. Records are stored separately by intern in `backend/storage/payroll_records/intern_<id>.json`. Editable Word export is provided as a `.doc` file; PDF export opens the browser print dialog where you can select **Save as PDF**. The send-email checkbox requests email after saving and requires SMTP settings in `backend/.env`.

**Important after extracting an updated ZIP:** close the old frontend tab, extract this ZIP into a new folder (do not merge with an older copy), then run `START_FRONTEND.cmd` and `START_BACKEND.cmd` from this newly extracted project. Hard-refresh the browser with `Ctrl+F5`.


Calendar payroll placement fix: for admins, the Payroll panel appears directly below the calendar grid and before the attendance records table. If an older page is cached, press Ctrl+F5.


## Calendar Payroll (admin)
- Select the specific intern first; payroll is stored under that intern's ID and selected month.
- Enter the total working days for that month and the days worked. Basic payable is calculated as monthly basic salary / total working days × days worked.
- Required fields are marked with an asterisk. Allowances and deductions may be left at zero.
- Use **Edit payslip in portal** to edit the payslip preview before exporting it to PDF. A generated PDF is a document, so edit the preview before export if changes are needed.
- Checking the email option sends the saved payslip as an HTML attachment to the email address stored on the selected intern's profile. The backend must have valid SMTP settings in `backend/.env`; copy your existing working SMTP settings into the new project's `.env` file. Do not use `.env.example` as a live configuration.
- The theme picker applies its palette to the calendar workspace. Payroll records are kept separately per intern and month on the backend.


## Payroll and email reliability notes (updated)

- Calendar keeps the selected intern in this browser until you change the selection. The first intern is selected only when no saved selection exists.
- Payroll records are stored by intern and month on the backend. The calendar includes **View all payroll records** for the full saved payroll list; each record retains its status.
- Days worked defaults to the number of distinct attendance dates marked Present for that intern and month. Admins can still edit the value; total working days is editable.
- Payslip preview is editable. Save payroll to persist the structured form and the edited payslip HTML. The email option sends the payslip as an HTML attachment to the selected intern's registered email.
- **Save payslip as PDF** opens the browser print dialog for the displayed payslip; choose **Save as PDF** in the print destination. Browsers do not allow a website to silently save a PDF to disk without a user action.
- Email delivery requires valid SMTP credentials. For Gmail, use a Google App Password with 2-Step Verification enabled. Never commit real credentials. If a send fails, the backend returns an error rather than falsely reporting success.
- After changing `backend/.env`, restart the backend. Confirm the recipient address on the intern record is correct. Check the backend terminal for SMTP errors.
