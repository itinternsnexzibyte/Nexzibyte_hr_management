let otpVerified = false;


const emailInput =
    document.getElementById("email");

const otpInput =
    document.getElementById("otp");

const passwordInput =
    document.getElementById("password");

const confirmPasswordInput =
    document.getElementById("confirmPassword");

const sendOtpButton =
    document.getElementById("sendOtpButton");

const verifyOtpButton =
    document.getElementById("verifyOtpButton");

const resetPasswordButton =
    document.getElementById("resetPasswordButton");

const otpSection =
    document.getElementById("otpSection");

const passwordSection =
    document.getElementById("passwordSection");

const verificationStatus =
    document.getElementById("verificationStatus");

const message =
    document.getElementById("message");


// =========================================================
// SEND OTP
// =========================================================

sendOtpButton.addEventListener(
    "click",
    async function () {

        const email =
            emailInput.value.trim().toLowerCase();


        if (!email) {

            message.textContent =
                "Please enter your email.";

            return;
        }


        try {

            sendOtpButton.disabled = true;

            sendOtpButton.textContent =
                "Sending...";


            const response =
                await api(
                    "/auth/forgot-password",
                    {
                        method: "POST",

                        body: JSON.stringify({
                            email: email
                        })
                    }
                );


            otpVerified = false;


            // SHOW OTP BOX

            otpSection.style.display =
                "block";


            // HIDE PASSWORD BOX UNTIL OTP
            // IS VERIFIED

            passwordSection.style.display =
                "none";


            // LOCK EMAIL

            emailInput.disabled = true;


            verificationStatus.textContent =
                "OTP sent successfully. Enter the OTP below.";


            message.textContent =
                response.message
                || "OTP sent successfully.";


            otpInput.focus();


        } catch (error) {

            message.textContent =
                error.message;


        } finally {

            sendOtpButton.disabled = false;

            sendOtpButton.textContent =
                "Send OTP";
        }
    }
);


// =========================================================
// VERIFY OTP
// =========================================================

verifyOtpButton.addEventListener(
    "click",
    async function () {

        const email =
            emailInput.value.trim().toLowerCase();

        const otp =
            otpInput.value.trim();


        if (!otp) {

            verificationStatus.textContent =
                "Please enter the OTP.";

            return;
        }


        if (!/^\d{6}$/.test(otp)) {

            verificationStatus.textContent =
                "OTP must contain exactly 6 digits.";

            return;
        }


        try {

            verifyOtpButton.disabled = true;

            verifyOtpButton.textContent =
                "Verifying...";


            await api(
                "/auth/verify-forgot-password-otp",
                {
                    method: "POST",

                    body: JSON.stringify({
                        email: email,
                        otp: otp
                    })
                }
            );


            otpVerified = true;


            verificationStatus.textContent =
                "OTP verified successfully.";


            // SHOW PASSWORD FIELDS

            passwordSection.style.display =
                "block";


            passwordInput.focus();


        } catch (error) {

            otpVerified = false;


            passwordSection.style.display =
                "none";


            verificationStatus.textContent =
                error.message;


        } finally {

            verifyOtpButton.disabled = false;

            verifyOtpButton.textContent =
                "Verify OTP";
        }
    }
);


// =========================================================
// RESET PASSWORD
// =========================================================

resetPasswordButton.addEventListener(
    "click",
    async function () {

        const email =
            emailInput.value.trim().toLowerCase();

        const otp =
            otpInput.value.trim();

        const password =
            passwordInput.value;

        const confirmPassword =
            confirmPasswordInput.value;


        if (!otpVerified) {

            message.textContent =
                "Please verify the OTP first.";

            return;
        }


        if (!password) {

            message.textContent =
                "Please enter a new password.";

            return;
        }


        if (password.length < 8) {

            message.textContent =
                "Password must contain at least 8 characters.";

            return;
        }


        if (password !== confirmPassword) {

            message.textContent =
                "Passwords do not match.";

            return;
        }


        try {

            resetPasswordButton.disabled = true;

            resetPasswordButton.textContent =
                "Updating...";


            const response =
                await api(
                    "/auth/reset-password",
                    {
                        method: "POST",

                        body: JSON.stringify({
                            email: email,
                            otp: otp,
                            password: password,
                            confirm_password: confirmPassword
                        })
                    }
                );


            message.textContent =
                response.message
                || "Password changed successfully.";


            otpVerified = false;


            otpInput.disabled = true;

            verifyOtpButton.disabled = true;

            passwordInput.disabled = true;

            confirmPasswordInput.disabled = true;

            resetPasswordButton.disabled = true;


            setTimeout(
                function () {

                    location.href =
                        "login.html";

                },
                1500
            );


        } catch (error) {

            message.textContent =
                error.message;

        } finally {

            resetPasswordButton.textContent =
                "Reset Password";
        }
    }
);