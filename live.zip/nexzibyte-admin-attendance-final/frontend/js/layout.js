requireAuth();

const u = user();

document.getElementById("app").innerHTML = `
<div class="layout">

    <aside class="sidebar" id="sidebar">

        <div class="brand">

            <img
                src="./images/nexzibyte-logo.png"
                alt="Nexzibyte Logo"
                class="dashboard-logo"
            >

            <span>NEXZIBYTE</span>

        </div>

        <div class="nav">

            <a href="dashboard.html">
                Dashboard
            </a>

            <a href="intern.html">
                Internal
            </a>

            <a href="assignment.html">
                Assignments
            </a>

            <a href="attendance.html">
                Attendance
            </a>

            ${
                u?.role === "admin"
                    ? `
                        <a href="employees.html">
                            Employees
                        </a>

                        <a href="us-client.html">
                            US Client
                        </a>
                    `
                    : ""
            }

        </div>

    </aside>


    <main class="main">

        <div class="topbar">

            <div>

                <button
                    type="button"
                    class="secondary mobile-only"
                    onclick="document.getElementById('sidebar').classList.toggle('open')"
                >
                    Menu
                </button>

                <h1 id="pageTitle">
                    Nexzibyte
                </h1>

            </div>

            <div class="muted">

                ${escapeHtml(u?.name || "User")}

                ·

                ${escapeHtml(u?.role || "")}

            </div>

        </div>


        <div id="page"></div>

    </main>

</div>
`;
