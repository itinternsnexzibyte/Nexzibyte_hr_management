console.log("Assignment Rating JS loaded");

const pageTitle = document.getElementById("pageTitle");

if (pageTitle) {
    pageTitle.textContent = "Assignment Ratings";
}


async function loadRatingsPage() {

    const app = document.getElementById("app");

    const currentUser = user();

    if (!currentUser) {
        location.href = "login.html";
        return;
    }

    app.innerHTML = `
        <div class="content-card">

            <div class="topbar">
                <h2>Assignment Ratings</h2>
            </div>

            <div id="ratingContent">
                Loading ratings...
            </div>

        </div>
    `;

    try {

        if (currentUser.role === "admin") {
            await loadAdminRatings();
        } else {
            await loadUserRatings();
        }

    } catch (error) {

        document.getElementById("ratingContent").innerHTML = `
            <p class="error">
                ${escapeHtml(error.message)}
            </p>
        `;
    }
}


/* =========================
   ADMIN VIEW
========================= */

async function loadAdminRatings() {

    const content = document.getElementById("ratingContent");

    const interns = await api("/interns");

    if (!interns || interns.length === 0) {

        content.innerHTML = `
            <p>No interns found.</p>
        `;

        return;
    }

    let html = `
        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>Intern</th>
                        <th>Date</th>
                        <th>Rating</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
    `;

    for (const intern of interns) {

        html += `
            <tr>

                <td>
                    ${escapeHtml(intern.name)}
                </td>

                <td>
                    <input
                        type="date"
                        id="date-${intern.id}"
                    >
                </td>

                <td>
                    <div id="rating-${intern.id}">
                        Not Rated
                    </div>
                </td>

                <td>

                    <button
                        class="primary"
                        onclick="giveRating(${intern.id})">
                        Give Rating
                    </button>

                </td>

            </tr>
        `;
    }

    html += `
                </tbody>

            </table>

        </div>

        <div
            id="ratingFormArea"
            style="margin-top:20px;">
        </div>
    `;

    content.innerHTML = html;
}


/* =========================
   ADMIN GIVE / CHANGE RATING
========================= */

async function giveRating(internId) {

    const dateInput =
        document.getElementById(`date-${internId}`);

    const selectedDate = dateInput.value;

    if (!selectedDate) {

        alert("Please select a date.");

        return;
    }

    const formArea =
        document.getElementById("ratingFormArea");

    formArea.innerHTML = `
        <div class="content-card">

            <h2>Give / Change Rating</h2>

            <p>
                Date: ${selectedDate}
            </p>

            <label>
                Rating
                <select id="ratingValue">
                    <option value="">Select rating</option>
                    <option value="1">⭐ 1 / 10</option>
                    <option value="2">⭐ 2 / 10</option>
                    <option value="3">⭐ 3 / 10</option>
                    <option value="4">⭐ 4 / 10</option>
                    <option value="5">⭐ 5 / 10</option>
                    <option value="6">⭐ 6 / 10</option>
                    <option value="7">⭐ 7 / 10</option>
                    <option value="8">⭐ 8 / 10</option>
                    <option value="9">⭐ 9 / 10</option>
                    <option value="10">⭐ 10 / 10</option>
                </select>
            </label>

            <br>

            <label>
                Feedback
                <textarea
                    id="ratingFeedback"
                    rows="4"
                    placeholder="Optional feedback">
                </textarea>
            </label>

            <br>

            <button
                class="primary"
                onclick="saveRating(${internId}, '${selectedDate}')">
                Save Rating
            </button>

        </div>
    `;
}


/* =========================
   SAVE RATING
========================= */

async function saveRating(internId, ratingDate) {

    const rating =
        Number(document.getElementById("ratingValue").value);

    const feedback =
        document.getElementById("ratingFeedback").value;

    if (!rating || rating < 1 || rating > 10) {

        alert("Please select a rating from 1 to 10.");

        return;
    }

    try {

        await api("/assignment-ratings", {

            method: "POST",

            body: JSON.stringify({

                intern_id: internId,

                rating_date: ratingDate,

                rating: rating,

                feedback: feedback

            })

        });

        alert("Rating saved successfully.");

        document.getElementById(
            `rating-${internId}`
        ).textContent = `⭐ ${rating} / 10`;

        document.getElementById(
            "ratingFormArea"
        ).innerHTML = "";

    } catch (error) {

        console.error("Rating error:", error);
        alert(JSON.stringify(error.message, null, 2));
    }
}


/* =========================
   USER / INTERN VIEW
========================= */

async function loadUserRatings() {

    const content =
        document.getElementById("ratingContent");

    try {

        const ratings =
            await api("/assignment-ratings");

        if (!ratings || ratings.length === 0) {

            content.innerHTML = `
                <div class="content-card">

                    <h3>My Ratings</h3>

                    <p>
                        Admin hasn't updated any ratings yet.
                    </p>

                </div>
            `;

            return;
        }

        let html = `
            <div class="table-wrap">

                <table>

                    <thead>

                        <tr>
                            <th>Date</th>
                            <th>Rating</th>
                            <th>Feedback</th>
                        </tr>

                    </thead>

                    <tbody>
        `;

        ratings.forEach(item => {

            html += `
                <tr>

                    <td>
                        ${escapeHtml(item.rating_date)}
                    </td>

                    <td>
                        ⭐ ${item.rating} / 10
                    </td>

                    <td>
                        ${escapeHtml(item.feedback || "-")}
                    </td>

                </tr>
            `;
        });

        html += `
                    </tbody>

                </table>

            </div>
        `;

        content.innerHTML = html;

    } catch (error) {

        content.innerHTML = `
            <p class="error">
                ${escapeHtml(error.message)}
            </p>
        `;
    }
}


loadRatingsPage();