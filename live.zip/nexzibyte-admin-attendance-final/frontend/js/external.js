console.log("External JS loaded");


function loadExternalPage() {

    const app = document.getElementById("app");
    const currentUser = user();


    if (!currentUser) {
        location.href = "login.html";
        return;
    }


    app.innerHTML = `

        <div class="content-card">

            <div class="topbar">

                <div>

                    <h2>EXTERNAL</h2>

                    <p class="muted">
                        Employee and US client management
                    </p>

                </div>

            </div>


            <div class="hero-grid">


                <!-- EMPLOYEES -->

                <div
                    class="hero-card"
                    onclick="location.href='employees.html'"
                    style="cursor: pointer;"
                >

                    <h2>Employees</h2>

                    <p>
                        View and manage employee
                        information and details.
                    </p>

                </div>


                <!-- US CLIENTS -->

                <div
                    class="hero-card"
                    onclick="location.href='us-client.html'"
                    style="cursor: pointer;"
                >

                    <h2>US Clients</h2>

                    <p>
                        Manage US client details,
                        documents and MOU agreements.
                    </p>

                </div>


            </div>

        </div>

    `;
}


loadExternalPage();
