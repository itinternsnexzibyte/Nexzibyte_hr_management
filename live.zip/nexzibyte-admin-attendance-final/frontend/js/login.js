document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const message = document.getElementById("message");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    if (message) {
      message.textContent = "Signing in...";
      message.style.color = "#2563eb";
    }

    try {
      const data = await api("/auth/login", {
        method: "POST",
        body: JSON.stringify({
          email: emailInput.value.trim(),
          password: passwordInput.value,
        }),
      });

      console.log("LOGIN SUCCESS RESPONSE:", data);

      // Support token in access_token or token field
      const token = data.access_token || data.token;
      if (!token) {
        throw new Error("No authentication token received from server.");
      }

      // Resolve user object
      const user = data.user || {
        email: emailInput.value.trim(),
        role: data.role || "intern",
        name: data.name || data.full_name || "Intern"
      };

      // Save credentials in sessionStorage
      sessionStorage.setItem("nza_token", token);
      sessionStorage.setItem("nza_user", JSON.stringify(user));

      // Normalize role string
      const rawRole = (user.role || data.role || "").toString().toLowerCase().trim();
      console.log("DETECTED USER ROLE:", rawRole);

      // Routing logic
      if (rawRole === "admin") {
        window.location.href = "dashboard.html";
      } else {
        // Any intern/student/user goes to the intern portal
        window.location.href = "intern-dashboard.html";
      }

    } catch (error) {
      console.error("Login failed:", error);
      if (message) {
        message.textContent = error.message || "Invalid email or password.";
        message.style.color = "#dc2626";
      }
    }
  });
});