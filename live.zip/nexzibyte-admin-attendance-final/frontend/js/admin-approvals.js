requireAuth();

const currentUser = user();

if (!currentUser || currentUser.role !== "admin") {
location.href = "dashboard.html";
}

// ---------------------------------------------------------
// PAGE
// ---------------------------------------------------------

const app = document.getElementById("app");

app.innerHTML = `
<div class="content-card">

    <div class="topbar">

        <div>
            <h2>Intern Account Approvals</h2>

            <p class="muted">
                Review intern registrations and offer letters.
            </p>
        </div>

        <div>
            <button
                type="button"
                class="secondary"
                onclick="location.href='dashboard.html'"
            >
                Back to Dashboard
            </button>
        </div>

    </div>

    <div
        id="approvalMessage"
        class="message"
    ></div>

    <div id="approvalContent">
        Loading pending approvals...
    </div>

</div>

`;

// ---------------------------------------------------------
// LOAD PENDING APPROVALS
// ---------------------------------------------------------

async function loadPendingApprovals() {

const content =
    document.getElementById("approvalContent");

try {

    const users =
        await api("/admin/pending-approvals");

    if (!users.length) {

        content.innerHTML = `
            <div class="content-card">

                <h3>No Pending Approvals</h3>

                <p class="muted">
                    There are currently no intern accounts
                    waiting for approval.
                </p>

            </div>
        `;

        return;
    }


    content.innerHTML = `

        <div class="table-wrap">

            <table>

                <thead>

                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Offer Letter</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                </thead>


                <tbody>

                    ${
                        users.map(intern => `

                            <tr>

                                <td>
                                    ${escapeHtml(
                                        intern.name
                                    )}
                                </td>


                                <td>
                                    ${escapeHtml(
                                        intern.email
                                    )}
                                </td>


                                <td>

                                    ${
                                        intern.offer_original_name
                                            ? `
                                                <button
                                                    type="button"
                                                    class="secondary"
                                                    onclick="viewOfferLetter(${Number(intern.id)})"
                                                >
                                                    View Offer Letter
                                                </button>

                                                <div class="muted">
                                                    ${escapeHtml(
                                                        intern.offer_original_name
                                                    )}
                                                </div>
                                            `
                                            : `
                                                <span class="muted">
                                                    Not uploaded
                                                </span>
                                            `
                                    }

                                </td>


                                <td>
                                    ${escapeHtml(
                                        intern.approval_status
                                    )}
                                </td>


                                <td>

                                    <button
                                        type="button"
                                        class="primary"
                                        onclick="approveIntern(${Number(intern.id)})"
                                    >
                                        Approve
                                    </button>


                                    <button
                                        type="button"
                                        class="danger"
                                        onclick="rejectIntern(${Number(intern.id)})"
                                    >
                                        Reject
                                    </button>

                                </td>

                            </tr>

                        `).join("")
                    }

                </tbody>

            </table>

        </div>
    `;

} catch (error) {

    content.innerHTML = `
        <div class="content-card">

            <p class="error">
                ${escapeHtml(error.message)}
            </p>

        </div>
    `;
}

}

// ---------------------------------------------------------
// VIEW OFFER LETTER
// ---------------------------------------------------------

async function viewOfferLetter(userId) {

const message =
    document.getElementById("approvalMessage");

message.textContent =
    "Opening offer letter...";

try {

    const response = await fetch(
        `${API_BASE}/admin/pending-approvals/${userId}/offer-letter`,
        {
            method: "GET",

            headers: {
                Authorization:
                    `Bearer ${token()}`
            }
        }
    );


    if (!response.ok) {

        let data = null;

        try {
            data = await response.json();
        } catch {
            data = null;
        }

        throw new Error(
            data?.detail ||
            `Unable to open offer letter (${response.status})`
        );
    }


    const blob =
        await response.blob();

    const url =
        URL.createObjectURL(blob);

    window.open(
        url,
        "_blank"
    );

    message.textContent = "";

    setTimeout(() => {
        URL.revokeObjectURL(url);
    }, 60000);

} catch (error) {

    message.textContent =
        error.message;
}

}

// ---------------------------------------------------------
// APPROVE INTERN
// ---------------------------------------------------------

async function approveIntern(userId) {

const confirmed = confirm(
    "Are you sure you want to approve this intern account?"
);

if (!confirmed) {
    return;
}


const message =
    document.getElementById("approvalMessage");

message.textContent =
    "Approving intern account...";


try {

    await api(
        `/admin/approve/${userId}`,
        {
            method: "POST"
        }
    );


    message.textContent =
        "Intern account approved successfully.";


    await loadPendingApprovals();

} catch (error) {

    message.textContent =
        error.message;
}

}

// ---------------------------------------------------------
// REJECT INTERN
// ---------------------------------------------------------

async function rejectIntern(userId) {

const confirmed = confirm(
    "Are you sure you want to reject this intern account?"
);

if (!confirmed) {
    return;
}


const message =
    document.getElementById("approvalMessage");

message.textContent =
    "Rejecting intern account...";


try {

    await api(
        `/admin/reject/${userId}`,
        {
            method: "POST"
        }
    );


    message.textContent =
        "Intern account rejected.";


    await loadPendingApprovals();

} catch (error) {

    message.textContent =
        error.message;
}

}

// ---------------------------------------------------------
// START
// ---------------------------------------------------------

loadPendingApprovals();