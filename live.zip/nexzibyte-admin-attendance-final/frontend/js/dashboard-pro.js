let approvalsChartInstance = null;

document.addEventListener("DOMContentLoaded", async () => {
  // 1. DYNAMIC CALENDAR (Live Today's Date & Weekday)
  const now = new Date();
  const dateOptions = { month: "long", day: "numeric", year: "numeric" };
  const dayOptions = { weekday: "long" };

  const liveDateElem = document.getElementById("liveDate");
  const liveDayElem = document.getElementById("liveDay");
  if (liveDateElem) liveDateElem.innerText = now.toLocaleDateString("en-US", dateOptions);
  if (liveDayElem) liveDayElem.innerText = now.toLocaleDateString("en-US", dayOptions);

  // 2. THEME SWITCHER (Light & Dark Mode)
  const savedTheme = localStorage.getItem("nexzibyte_theme") || "light";
  document.body.setAttribute("data-theme", savedTheme);

  const themeToggleBtn = document.getElementById("themeToggleBtn");
  const themeIcon = document.getElementById("themeIcon");

  function updateThemeIcon(theme) {
    if (themeIcon) {
      themeIcon.setAttribute("data-lucide", theme === "dark" ? "moon" : "sun");
      if (window.lucide) lucide.createIcons();
    }
  }
  updateThemeIcon(savedTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", () => {
      const currentTheme = document.body.getAttribute("data-theme");
      const nextTheme = currentTheme === "dark" ? "light" : "dark";
      document.body.setAttribute("data-theme", nextTheme);
      localStorage.setItem("nexzibyte_theme", nextTheme);
      updateThemeIcon(nextTheme);
    });
  }

  // 3. ADMIN DROPDOWN TOGGLE & LOGOUT
  const profileDropdownBtn = document.getElementById("profileDropdownBtn");
  const adminDropdownMenu = document.getElementById("adminDropdownMenu");
  const logoutBtn = document.getElementById("logoutBtn");

  if (profileDropdownBtn && adminDropdownMenu) {
    profileDropdownBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      adminDropdownMenu.classList.toggle("show");
      profileDropdownBtn.classList.toggle("active");
    });

    document.addEventListener("click", (e) => {
      if (!adminDropdownMenu.contains(e.target) && !profileDropdownBtn.contains(e.target)) {
        adminDropdownMenu.classList.remove("show");
        profileDropdownBtn.classList.remove("active");
      }
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      sessionStorage.removeItem("nza_token");
      sessionStorage.removeItem("nza_user");
      localStorage.clear();
      window.location.href = "index.html";
    });
  }

  // 4. FETCH DYNAMIC METRICS USING nza_token
  const token = sessionStorage.getItem("nza_token");

  if (!token) {
    console.warn("No token found. Redirecting to login...");
    window.location.href = "index.html";
    return;
  }

  let dashboardData = null;

  try {
    const response = await fetch("http://127.0.0.1:8000/api/dashboard/summary", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    });

    if (response.ok) {
      dashboardData = await response.json();
    } else if (response.status === 401) {
      console.warn("Session expired or unauthorized. Redirecting to login...");
      sessionStorage.removeItem("nza_token");
      sessionStorage.removeItem("nza_user");
      window.location.href = "index.html";
      return;
    }
  } catch (err) {
    console.error("Dashboard fetch error:", err);
  }

 // 5. POPULATE METRICS
  if (dashboardData) {
    // Read cached user info as fallback for admin name
    let storedUser = null;
    try {
      storedUser = JSON.parse(sessionStorage.getItem("nza_user"));
    } catch (_) {}

    const adminName = dashboardData.admin_name || storedUser?.name || "Nexzibyte Admin";
    if (document.getElementById("welcomeAdminName")) document.getElementById("welcomeAdminName").innerText = adminName;
    if (document.getElementById("adminHeaderName")) document.getElementById("adminHeaderName").innerText = adminName;
    if (document.getElementById("dropdownAdminName")) document.getElementById("dropdownAdminName").innerText = adminName;

    // Top 6 Main KPI Stat Cards
    if (document.getElementById("statInterns")) document.getElementById("statInterns").innerText = dashboardData.total_interns ?? 0;
    if (document.getElementById("statEmployees")) document.getElementById("statEmployees").innerText = dashboardData.total_employees ?? 0;
    if (document.getElementById("statAssignments")) document.getElementById("statAssignments").innerText = dashboardData.total_assignments ?? 0;
    if (document.getElementById("statAttendance")) document.getElementById("statAttendance").innerText = dashboardData.today_attendance ?? 0;
    if (document.getElementById("statRatings")) document.getElementById("statRatings").innerText = dashboardData.pending_ratings ?? 0;
    if (document.getElementById("statClients")) document.getElementById("statClients").innerText = dashboardData.active_us_clients ?? 0;

    // Sidebar Navigation Card Badges (Cyan Pills)
    if (document.getElementById("badgeInterns")) document.getElementById("badgeInterns").innerText = dashboardData.total_interns ?? 0;
    if (document.getElementById("badgeAssignments")) document.getElementById("badgeAssignments").innerText = dashboardData.total_assignments ?? 0;
    if (document.getElementById("badgeAttendance")) document.getElementById("badgeAttendance").innerText = dashboardData.today_attendance ?? 0;
    if (document.getElementById("badgeRatings")) document.getElementById("badgeRatings").innerText = dashboardData.pending_ratings ?? 0;
    if (document.getElementById("badgeEmployees")) document.getElementById("badgeEmployees").innerText = dashboardData.total_employees ?? 0;
    if (document.getElementById("badgeClients")) document.getElementById("badgeClients").innerText = dashboardData.active_us_clients ?? 0;

    // Chart Approvals Breakdown
    const breakdown = dashboardData.breakdown || {};
    if (document.getElementById("miniRegistrations")) document.getElementById("miniRegistrations").innerText = breakdown.new_registrations ?? 0;
    if (document.getElementById("miniOfferLetters")) document.getElementById("miniOfferLetters").innerText = breakdown.offer_letters ?? 0;
    if (document.getElementById("miniApprovals")) document.getElementById("miniApprovals").innerText = breakdown.approval_requests ?? 0;
  }
  // 6. RENDER DYNAMIC CHART
  const chartLabels = dashboardData?.chart?.labels || ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Today"];
  const chartValues = dashboardData?.chart?.data || [0, 0, 0, 0, 0, 0, 0];

  const ctx = document.getElementById("approvalsChart");
  if (ctx) {
    if (approvalsChartInstance) approvalsChartInstance.destroy();

    const isDark = document.body.getAttribute("data-theme") === "dark";

    approvalsChartInstance = new Chart(ctx, {
      type: "line",
      data: {
        labels: chartLabels,
        datasets: [{
          data: chartValues,
          borderColor: "#4F46E5",
          borderWidth: 2.5,
          pointBackgroundColor: "#4F46E5",
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.35,
          fill: true,
          backgroundColor: "rgba(79, 70, 229, 0.08)"
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { 
            grid: { display: false }, 
            ticks: { font: { size: 10.5 }, color: isDark ? "#94A3B8" : "#64748B" } 
          },
          y: { 
            beginAtZero: true,
            ticks: { precision: 0, font: { size: 10.5 }, color: isDark ? "#94A3B8" : "#64748B" }, 
            grid: { color: isDark ? "#1E293B" : "#F1F5F9" } 
          }
        }
      }
    });
  }

  // 7. INITIALIZE ICONS
  if (window.lucide) {
    lucide.createIcons();
  }
  // 8. ACCORDION DROPDOWNS (Internal & External Cards)
  const menuToggles = document.querySelectorAll(".menu-toggle");
  menuToggles.forEach((btn) => {
    btn.addEventListener("click", () => {
      const parentSection = btn.closest(".menu-section");
      if (!parentSection) return;

      // Close the other card if you only want one open at a time
      document.querySelectorAll(".menu-section").forEach((sec) => {
        if (sec !== parentSection) {
          sec.classList.remove("open");
        }
      });

      // Toggle the clicked card
      parentSection.classList.toggle("open");
    });
  });
});