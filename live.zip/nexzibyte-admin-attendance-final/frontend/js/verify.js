(async () => {

    const message = document.getElementById("message");
    const passwordForm = document.getElementById("passwordForm");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirmPassword");

    const token = new URLSearchParams(location.search).get("token");

    if (!token) {
        message.textContent = "Missing verification token.";
        return;
    }

    // First check whether the token is valid.
    try {

        const data = await api(
            "/auth/verify?token=" + encodeURIComponent(token)
        );

        message.textContent =
            data.message || "Verification link is valid.";

        passwordForm.style.display = "block";

    } catch (error) {

        message.textContent = error.message;
        passwordForm.style.display = "none";

    }


    passwordForm.addEventListener("submit", async (event) => {

        event.preventDefault();

        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        if (password.length < 8) {
            message.textContent =
                "Password must be at least 8 characters.";
            return;
        }

        if (password !== confirmPassword) {
            message.textContent =
                "Passwords do not match.";
            return;
        }

        try {

            message.textContent = "Creating your password...";

            const data = await api(
                "/auth/set-password",
                {
                    method: "POST",

                    body: JSON.stringify({
                        token: token,
                        password: password,
                        confirm_password: confirmPassword
                    })
                }
            );

            message.textContent =
                data.message || "Password created successfully.";

            passwordForm.style.display = "none";

            setTimeout(() => {
                location.href = "login.html";
            }, 2000);

        } catch (error) {

            message.textContent = error.message;

        }

    });

})();

