/* =========================================================
   NEXZIBYTE UI LAYER  (js/nexzi-ui.js)
   Shared, dependency-free enhancements. Safe to load on any page.
   Does not touch API calls, auth, or page data logic.
   ========================================================= */
(function () {
  "use strict";

  /* ---------- Toasts ---------- */
  function host() {
    let h = document.getElementById("nx-toasts");
    if (!h) {
      h = document.createElement("div");
      h.id = "nx-toasts";
      h.setAttribute("role", "status");
      h.setAttribute("aria-live", "polite");
      document.body.appendChild(h);
    }
    return h;
  }

  function toast(message, type, title, ms) {
    type = type || "info";
    const el = document.createElement("div");
    el.className = "nx-toast " + type;
    if (type === "error") el.setAttribute("role", "alert");
    const body = document.createElement("div");
    const t = document.createElement("span");
    t.className = "nx-t-title";
    t.textContent = title || ({ success: "Success", error: "Something went wrong", warn: "Notice", info: "Notice" })[type];
    const m = document.createElement("span");
    m.className = "nx-t-msg";
    m.textContent = String(message == null ? "" : message);   // textContent: no HTML injection
    body.append(t, m);
    const x = document.createElement("button");
    x.type = "button"; x.setAttribute("aria-label", "Dismiss"); x.textContent = "\u00d7";
    el.append(body, x);
    const close = () => { el.classList.add("out"); setTimeout(() => el.remove(), 180); };
    x.addEventListener("click", close);
    host().appendChild(el);
    setTimeout(close, ms || (type === "error" ? 7000 : 4000));
  }
  window.NX = window.NX || {};
  window.NX.toast = toast;

  // Non-blocking replacement for alert(). Same call signature, no return value
  // (alert() also returns undefined), so existing code keeps working.
  const nativeAlert = window.alert ? window.alert.bind(window) : null;
  window.alert = function (msg) {
    try {
      const s = String(msg == null ? "" : msg);
      const type = /fail|error|could not|unable|invalid|denied|not allowed|required|incorrect|already|expired/i.test(s)
        ? "error" : /success|saved|created|updated|deleted|approved|rejected|sent|uploaded|marked|recorded|complete/i.test(s)
        ? "success" : "info";
      toast(s, type);
    } catch (e) { if (nativeAlert) nativeAlert(msg); }
  };

  /* ---------- Button loading helper (opt-in) ---------- */
  window.NX.busy = function (btn, on) {
    if (!btn) return;
    btn.classList.toggle("nx-loading", !!on);
    btn.disabled = !!on;
    btn.setAttribute("aria-busy", on ? "true" : "false");
  };

  /* ---------- Theme persistence: pages read "nza_theme" before paint
     but the toggle saves "nexzibyte_theme". Keep both in sync. ---------- */
  function syncTheme() {
    try {
      const saved = localStorage.getItem("nexzibyte_theme");
      if (saved && saved !== localStorage.getItem("nza_theme")) localStorage.setItem("nza_theme", saved);
    } catch (e) { /* storage unavailable */ }
  }

  /* ---------- Shell enhancements ---------- */
  function initShell() {
    const sidebar = document.querySelector("aside.sidebar");
    const topLeft = document.querySelector(".topbar-left");
    const main = document.querySelector(".main-content, main");

    // Skip link + landmark
    if (main) {
      if (!main.id) main.id = "nx-main";
      main.setAttribute("tabindex", "-1");
      const skip = document.createElement("a");
      skip.className = "skip-link"; skip.href = "#" + main.id; skip.textContent = "Skip to content";
      document.body.insertBefore(skip, document.body.firstChild);
    }
    if (!sidebar) return;

    // Mark current page in navigation (also exposes it to screen readers)
    const here = (location.pathname.split("/").pop() || "dashboard.html").toLowerCase();
    let label = "";
    sidebar.querySelectorAll("a[href]").forEach(a => {
      const href = (a.getAttribute("href") || "").split("?")[0].toLowerCase();
      if (href === here) {
        a.setAttribute("aria-current", "page");
        label = (a.textContent || "").trim().replace(/\s+/g, " ");
        // open collapsed group containing the active page
        const sec = a.closest(".menu-section");
        if (sec) sec.classList.add("open");
      }
    });
    sidebar.setAttribute("aria-label", "Primary navigation");

    // Collapsible groups: expose state
    sidebar.querySelectorAll(".menu-toggle").forEach(b => {
      const sec = b.closest(".menu-section");
      const sync = () => b.setAttribute("aria-expanded", sec && sec.classList.contains("open") ? "true" : "false");
      sync();
      b.addEventListener("click", () => setTimeout(sync, 0));
    });

    // Breadcrumb (derived from real nav labels; nothing invented)
    if (topLeft && !topLeft.children.length) {
      const sec = sidebar.querySelector('a[aria-current="page"]');
      const group = sec && sec.closest(".menu-section") ? sec.closest(".menu-section").querySelector(".menu-toggle span") : null;
      const nav = document.createElement("nav");
      nav.className = "nx-crumbs"; nav.setAttribute("aria-label", "Breadcrumb");
      const parts = ["Nexzibyte"];
      if (group) parts.push(group.textContent.trim());
      if (label) parts.push(label);
      nav.innerHTML = "";
      parts.forEach((p, i) => {
        if (i) { const s = document.createElement("span"); s.setAttribute("aria-hidden", "true"); s.textContent = "/"; nav.appendChild(s); }
        const e = document.createElement(i === parts.length - 1 ? "b" : "span");
        e.textContent = p; nav.appendChild(e);
      });
      topLeft.appendChild(nav);
    }

    // Mobile navigation
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "nx-menu-btn";
    btn.setAttribute("aria-label", "Open navigation"); btn.setAttribute("aria-expanded", "false");
    btn.innerHTML = "&#9776;";
    (topLeft || document.querySelector(".topbar") || document.body).insertBefore(btn, (topLeft || document.body).firstChild);
    const scrim = document.createElement("div");
    scrim.className = "nx-scrim"; document.body.appendChild(scrim);
    const set = open => {
      document.body.classList.toggle("nx-nav-open", open);
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    };
    btn.addEventListener("click", () => set(!document.body.classList.contains("nx-nav-open")));
    scrim.addEventListener("click", () => set(false));
    document.addEventListener("keydown", e => { if (e.key === "Escape") set(false); });
    sidebar.addEventListener("click", e => { if (e.target.closest("a")) set(false); });
    window.matchMedia("(min-width: 861px)").addEventListener("change", e => { if (e.matches) set(false); });
  }

  /* ---------- Modals: Escape closes the active one (uses page's own close button) ---------- */
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    const m = document.querySelector(".modal-overlay.active");
    const close = m && m.querySelector(".modal-close-btn");
    if (close) close.click();
  });

  /* ---------- Wrap bare tables so they scroll instead of breaking layout ---------- */
  function wrapTables(root) {
    (root || document).querySelectorAll("table").forEach(t => {
      if (t.closest(".table-wrap, .table-container, .table-responsive, .nx-scroll")) return;
      const w = document.createElement("div");
      w.className = "nx-scroll"; w.style.overflowX = "auto";
      t.parentNode.insertBefore(w, t); w.appendChild(t);
    });
  }

  /* ---------- Friendly fallback for uncaught errors (technical detail stays in console) ---------- */
  let lastErr = 0;
  window.addEventListener("unhandledrejection", e => {
    console.error("[Nexzibyte] Unhandled promise rejection:", e.reason);
    if (Date.now() - lastErr < 4000) return;
    lastErr = Date.now();
    const msg = e.reason && e.reason.message;
    if (/failed to fetch|networkerror|load failed/i.test(String(msg))) {
      toast("Unable to reach the server. Check your connection and try again.", "error", "Connection problem");
    }
  });

  function ready() { syncTheme(); initShell(); wrapTables(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready); else ready();

  /* =====================================================================
     v2: visible shell upgrades (all driven by real session / API data)
     ===================================================================== */
  function sessionUser() {
    try { return JSON.parse(sessionStorage.getItem("nza_user") || "null"); } catch (e) { return null; }
  }
  function initials(n) {
    const p = String(n || "U").trim().split(/\s+/);
    return ((p[0] || "U")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
  }
  const ICON = {
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
    out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/></svg>'
  };

  function upgradeSidebar() {
    const sb = document.querySelector("aside.sidebar");
    if (!sb) return;
    const u = sessionUser();
    const isAdmin = u && u.role === "admin";

    // Product name under the logo
    const box = sb.querySelector(".brand-box");
    if (box && !box.querySelector(".nx-product")) {
      const t = document.createElement("div");
      t.className = "nx-product"; t.textContent = "Workforce Management";
      box.appendChild(t);
    }

    // Management section (Approvals) — link existed in the app but was missing from navigation
    const menu = sb.querySelector(".sidebar-menu");
    if (menu && isAdmin && !menu.querySelector('a[href="admin-approvals.html"]')) {
      const sec = document.createElement("div");
      sec.className = "menu-section open";
      sec.innerHTML = '<div class="section-header-btn" role="presentation"><span>Management</span></div>' +
        '<div class="section-card"><a href="admin-approvals.html" class="card-item"><div class="item-left">' +
        '<i data-lucide="shield-check"></i> <span>Approvals</span></div></a></div>';
      menu.appendChild(sec);
      const here = (location.pathname.split("/").pop() || "").toLowerCase();
      if (here === "admin-approvals.html") sec.querySelector("a").setAttribute("aria-current", "page");
    }

    // Rename the first section label to a product-style heading
    sb.querySelectorAll(".section-header-btn span").forEach(sp => {
      const t = sp.textContent.trim().toLowerCase();
      if (t === "internal") sp.textContent = "Workspace";
      else if (t === "external") sp.textContent = "Clients & Team";
    });

    // Profile + logout footer (replaces the generic promo card)
    if (!sb.querySelector(".nx-side-foot")) {
      const f = document.createElement("div");
      f.className = "nx-side-foot";
      const name = (u && (u.name || u.full_name)) || "Account";
      f.innerHTML = '<div class="nx-user"><div class="nx-avatar"></div><div class="nx-user-meta"><b></b><small></small></div>' +
        '<button type="button" class="nx-logout" aria-label="Log out" title="Log out">' + ICON.out + '</button></div>';
      f.querySelector(".nx-avatar").textContent = initials(name);
      f.querySelector("b").textContent = name;
      f.querySelector("small").textContent = (u && u.role) || "";
      f.querySelector(".nx-logout").addEventListener("click", () => {
        if (typeof window.logout === "function") window.logout(); else { sessionStorage.clear(); location.href = "login.html"; }
      });
      sb.appendChild(f);
    }
    if (window.lucide && lucide.createIcons) lucide.createIcons();
  }

  function upgradeTopbar() {}

  function personalizeDashboard() {
    const h = document.querySelector(".welcome-header .welcome-text h1");
    if (!h) return;
    const u = sessionUser();
    const hr = new Date().getHours();
    const g = hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening";
    const first = String((u && (u.name || u.full_name)) || "").trim().split(/\s+/)[0];
    h.textContent = g + (first ? ", " + first : "");
    const p = document.querySelector(".welcome-header .welcome-text p");
    if (p) p.textContent = "Here\u2019s your workforce overview for today.";

    // Attendance rate = today's attendance / total interns (both come from the backend dashboard call)
    const pres = document.getElementById("todayAttendanceCount") || document.getElementById("statAttendance");
    const tot = document.getElementById("totalInternsCount") || document.getElementById("statInterns");
    if (pres && tot) {
      const sub = pres.parentElement.querySelector(".stat-sub span");
      const calc = () => {
        const a = parseInt(pres.textContent, 10), t = parseInt(tot.textContent, 10);
        if (sub && t > 0 && !isNaN(a)) sub.textContent = Math.round((a / t) * 100) + "% of interns present";
      };
      const mo = new MutationObserver(calc);
      [pres, tot].forEach(el => mo.observe(el, { childList: true, characterData: true, subtree: true }));
      calc();
    }
  }

  function upgradeAuth() {
    if (!document.body.classList.contains("auth-page") || document.querySelector(".nx-brand-panel")) return;
    const p = document.createElement("section");
    p.className = "nx-brand-panel";
    p.setAttribute("aria-hidden", "true");
    p.innerHTML = '<div class="nx-logo-chip"><img src="images/nexzibyte-logo.png" alt="" onerror="this.onerror=null;this.src=\'images/logo.png\';"></div>' +
      '<div><h2>Workforce management,<br>made clear.</h2><p>Attendance, interns, assignments, ratings and approvals \u2014 in one secure platform for your whole organisation.</p>' +
      '<ul><li>Real-time attendance tracking</li><li>Intern onboarding &amp; document approvals</li><li>Assignments and performance ratings</li></ul></div>' +
      '<small>\u00a9 ' + new Date().getFullYear() + ' NexziByte Solutions Pvt Ltd</small>';
    document.body.insertBefore(p, document.body.firstChild);
    document.querySelectorAll(".auth-card input[required]").forEach(i => {
      const l = i.closest("label");
      if (l && !l.dataset.nxReq) { l.dataset.nxReq = "1"; }
    });
  }

  function ready2() { upgradeSidebar(); upgradeTopbar(); personalizeDashboard(); upgradeAuth(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ready2); else ready2();
})();
