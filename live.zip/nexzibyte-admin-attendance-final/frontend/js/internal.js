console.log("Internal JS loaded");


function loadInternalPage() {

    const app = document.getElementById("app");
    const currentUser = user();

    if (!currentUser) {
        location.href = "login.html";
        return;
    }


    app.innerHTML = `

        <div class="content-card">

            <div class="topbar">
                <div>
                    <h2>INTERNAL</h2>

                    <p class="muted">
                        Intern management and intern activities
                    </p>
                </div>
            </div>


            <div class="hero-grid">


                <!-- INTERN DETAILS -->

                <a
                    class="hero-card"
                    href="intern.html"
                >

                    <h2>Intern Details</h2>

                    <p>
                        View and manage intern information,
                        joining details, duration, role
                        and offer letters.
                    </p>

                    <span class="dashboard-card-action">
                        Open Intern Details →
                    </span>

                </a>


                <!-- ASSIGNMENTS -->

                <a
                    class="hero-card"
                    href="assignment.html"
                >

                    <h2>Assignments</h2>

                    <p>
                        View assignments and
                        manage daily intern ratings.
                    </p>

                    <span class="dashboard-card-action">
                        Open Assignments →
                    </span>

                </a>


                <!-- ATTENDANCE -->

                <a
                    class="hero-card"
                    href="attendance.html"
                >

                    <h2>Attendance</h2>

                    <p>
                        View login time, lunch break,
                        logout time and working duration.
                    </p>

                    <span class="dashboard-card-action">
                        Open Attendance →
                    </span>

                </a>


            </div>

        </div>

    `;
}


loadInternalPage();

