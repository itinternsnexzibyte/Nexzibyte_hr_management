let emailVerified = false;

// =========================================================
// ELEMENTS
// =========================================================

const registerForm =
document.getElementById("registerForm");

const nameInput =
document.getElementById("name");

const emailInput =
document.getElementById("email");

const passwordInput =
document.getElementById("password");

const confirmPasswordInput =
document.getElementById("confirm_password");

const offerLetterInput =
document.getElementById("offer_letter");

const sendOtpButton =
document.getElementById("sendOtpButton");

const verifyOtpButton =
document.getElementById("verifyOtpButton");

const otpSection =
document.getElementById("otpSection");

const otpInput =
document.getElementById("otp");

const verificationStatus =
document.getElementById("verificationStatus");

const createAccountButton =
document.getElementById("createAccountButton");

const message =
document.getElementById("message");

// =========================================================
// SEND OTP
// =========================================================

sendOtpButton.addEventListener(
"click",
async () => {

    const email =
        emailInput.value.trim().toLowerCase();

    if (!email) {

        message.textContent =
            "Please enter your email address.";

        return;
    }


    if (!emailInput.checkValidity()) {

        message.textContent =
            "Please enter a valid email address.";

        return;
    }


    message.textContent =
        "Sending OTP...";

    verificationStatus.textContent =
        "";


    try {

        await api(
            "/auth/send-registration-otp",
            {
                method: "POST",

                body: JSON.stringify({
                    email: email
                })
            }
        );


        emailVerified = false;


        otpSection.style.display =
            "block";


        createAccountButton.disabled =
            true;


        createAccountButton.textContent =
            "Verify Email First";


        emailInput.readOnly =
            true;


        sendOtpButton.textContent =
            "Resend OTP";


        verificationStatus.textContent =
            "OTP sent. Please check your email.";

        message.textContent =
            "";


        otpInput.focus();

    } catch (error) {

        message.textContent =
            error.message;
    }
}

);

// =========================================================
// VERIFY OTP
// =========================================================

verifyOtpButton.addEventListener(
"click",
async () => {

    const email =
        emailInput.value.trim().toLowerCase();

    const otp =
        otpInput.value.trim();


    if (!otp) {

        verificationStatus.textContent =
            "Please enter the OTP.";

        return;
    }


    if (!/^\d{6}$/.test(otp)) {

        verificationStatus.textContent =
            "OTP must contain exactly 6 digits.";

        return;
    }


    verificationStatus.textContent =
        "Verifying OTP...";


    try {

        const result =
            await api(
                "/auth/verify-registration-otp",
                {
                    method: "POST",

                    body: JSON.stringify({
                        email: email,
                        otp: otp
                    })
                }
            );


        if (
            result &&
            result.verified === true
        ) {

            emailVerified =
                true;


            verificationStatus.textContent =
                "Email verified successfully ✓";


            createAccountButton.disabled =
                false;


            createAccountButton.textContent =
                "Create Account";


            otpInput.disabled =
                true;


            verifyOtpButton.disabled =
                true;


            sendOtpButton.disabled =
                true;


            emailInput.readOnly =
                true;


            message.textContent =
                "";

        } else {

            emailVerified =
                false;


            verificationStatus.textContent =
                "Email verification failed.";

        }

    } catch (error) {

        emailVerified =
            false;


        verificationStatus.textContent =
            error.message;
    }
}

);

// =========================================================
// IF EMAIL IS CHANGED
// =========================================================

emailInput.addEventListener(
"input",
() => {

    if (!emailInput.readOnly) {

        emailVerified =
            false;

        otpSection.style.display =
            "none";

        createAccountButton.disabled =
            true;

        createAccountButton.textContent =
            "Verify Email First";

        verificationStatus.textContent =
            "";

    }
}

);

// =========================================================
// CREATE ACCOUNT
// =========================================================

registerForm.addEventListener(
"submit",
async (e) => {

    e.preventDefault();


    // -------------------------------------------------
    // EMAIL VERIFICATION
    // -------------------------------------------------

    if (!emailVerified) {

        message.textContent =
            "Please verify your email using the OTP first.";

        return;
    }


    // -------------------------------------------------
    // PASSWORD CHECK
    // -------------------------------------------------

    if (
        passwordInput.value !==
        confirmPasswordInput.value
    ) {

        message.textContent =
            "Passwords do not match.";

        return;
    }


    // -------------------------------------------------
    // OFFER LETTER CHECK
    // -------------------------------------------------

    if (
        !offerLetterInput.files ||
        offerLetterInput.files.length === 0
    ) {

        message.textContent =
            "Please upload your offer letter.";

        return;
    }


    const file =
        offerLetterInput.files[0];


    const allowedTypes = [
        "application/pdf",
        "image/jpeg",
        "image/png"
    ];


    if (
        !allowedTypes.includes(
            file.type
        )
    ) {

        message.textContent =
            "Offer letter must be PDF, JPG, JPEG, or PNG.";

        return;
    }


    // -------------------------------------------------
    // CREATE FORM DATA
    // -------------------------------------------------

    const formData =
        new FormData();


    formData.append(
        "name",
        nameInput.value.trim()
    );


    formData.append(
        "email",
        emailInput.value.trim().toLowerCase()
    );


    formData.append(
        "password",
        passwordInput.value
    );


    formData.append(
        "confirm_password",
        confirmPasswordInput.value
    );


    formData.append(
        "offer_letter",
        file
    );


    message.textContent =
        "Creating account...";


    createAccountButton.disabled =
        true;


    try {

        await api(
            "/auth/register",
            {
                method: "POST",
                body: formData
            }
        );


        message.textContent =
            "Account created successfully. Your email is verified and your account is now waiting for admin approval.";


        registerForm.reset();


        emailVerified =
            false;


        otpSection.style.display =
            "none";


        createAccountButton.disabled =
            true;


        createAccountButton.textContent =
            "Verify Email First";


        sendOtpButton.disabled =
            false;


        sendOtpButton.textContent =
            "Send OTP";


        emailInput.readOnly =
            false;


        otpInput.disabled =
            false;


        verifyOtpButton.disabled =
            false;


        verificationStatus.textContent =
            "";

    } catch (error) {

        createAccountButton.disabled =
            false;


        message.textContent =
            error.message;
    }
}

);