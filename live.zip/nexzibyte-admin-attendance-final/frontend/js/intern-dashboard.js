requireAuth();

const currentUser = user();

if (!currentUser || currentUser.role !== "student") {
    location.href = "login.html";
    return;
}

const app = document.getElementById("app");

app.innerHTML = `
    <div class="content-card">

        <div
            style="
                text-align: center;
                margin-bottom: 50px;
            "
        >
            <img
                src="images/nexzibyte-logo.png"
                alt="Nexzibyte Logo"
                style="
                    width: 350px;
                    height: auto;
                    display: inline-block;
                "
            >
        </div>

        <div class="topbar">

            <div>
                <h2>Intern Dashboard</h2>

                <p class="muted">
                    Welcome back,
                    ${escapeHtml(currentUser.name)}
                </p>
            </div>

            <div>
                <button
                    type="button"
                    class="secondary"
                    onclick="logout()"
                >
                    Logout
                </button>
            </div>

        </div>

        <div class="hero-grid">

            <div
                class="hero-card"
                onclick="location.href='intern.html'"
                style="cursor: pointer;"
            >
                <h2>Intern Details</h2>

                <p>
                    View your internship details
                    and offer letter.
                </p>
            </div>

            <div
                class="hero-card"
                onclick="location.href='assignment.html'"
                style="cursor: pointer;"
            >
                <h2>Assignments</h2>

                <p>
                    View your assignments,
                    submissions and ratings.
                </p>
            </div>

            <div
                class="hero-card"
                onclick="location.href='attendance.html'"
                style="cursor: pointer;"
            >
                <h2>Attendance</h2>

                <p>
                    View your attendance
                    and working hours.
                </p>
            </div>

        </div>

    </div>
`;