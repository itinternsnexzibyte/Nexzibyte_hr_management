const API_BASE = "http://127.0.0.1:8000/api";


function token() {
    return sessionStorage.getItem("nza_token");
}


function user() {
    try {
        return JSON.parse(
            sessionStorage.getItem("nza_user") || "null"
        );
    } catch {
        return null;
    }
}


async function logout() {
    const currentUser = user();

    // -----------------------------------------------------
    // INTERN LOGOUT
    // -----------------------------------------------------

    if (
        currentUser &&
        currentUser.role === "student" &&
        token()
    ) {
        try {

            await api(
                "/attendance/logout",
                {
                    method: "POST"
                }
            );

        } catch (error) {

            alert(
                "Logout attendance could not be recorded.\n\n" +
                error.message +
                "\n\nPlease try again."
            );

            return;
        }
    }

    // -----------------------------------------------------
    // CLEAR LOGIN SESSION
    // -----------------------------------------------------

    sessionStorage.removeItem("nza_token");
    sessionStorage.removeItem("nza_user");

    location.href = "login.html";
}


async function api(
    path,
    options = {}
) {
    const headers =
        new Headers(
            options.headers || {}
        );

    // -----------------------------------------------------
    // JSON REQUESTS
    // -----------------------------------------------------

    if (
        options.body
        && !(options.body instanceof FormData)
    ) {
        headers.set(
            "Content-Type",
            "application/json"
        );
    }

    // -----------------------------------------------------
    // ADD JWT
    // -----------------------------------------------------

    if (token()) {

        headers.set(
            "Authorization",
            `Bearer ${token()}`
        );
    }

    const response = await fetch(
        API_BASE + path,
        {
            ...options,
            headers
        }
    );

    let data = null;

    try {

        data = await response.json();

    } catch {

        data = null;
    }

    // -----------------------------------------------------
    // HANDLE ERRORS
    // -----------------------------------------------------

    if (!response.ok) {

        let message = "Request failed";

        if (Array.isArray(data?.detail)) {

            message = data.detail
                .map(item => {

                    if (typeof item === "string") {
                        return item;
                    }

                    return (
                        item.msg
                        || JSON.stringify(item)
                    );

                })
                .join("\n");

        } else if (
            typeof data?.detail === "string"
        ) {

            message = data.detail;

        } else if (data?.detail) {

            message = JSON.stringify(
                data.detail,
                null,
                2
            );
        }

        throw new Error(message);
    }

    return data;
}


function requireAuth() {

    if (!token()) {

        location.href = "login.html";
    }
}


function escapeHtml(s) {

    return String(
        s ?? ""
    ).replace(
        /[&<>"']/g,
        c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[c])
    );
}