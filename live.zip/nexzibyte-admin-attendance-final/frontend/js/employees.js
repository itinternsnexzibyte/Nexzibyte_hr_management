requireAuth();

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

async function loadEmployees() {
    const app = document.getElementById("app");
    if (!app) return;

    app.innerHTML = `
        <div class="content-card">
            <div class="topbar" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;">
                <div>
                    <h1>Employees</h1>
                    <p class="muted">Employee management</p>
                </div>
                <div>
                    <button
                        type="button"
                        class="primary"
                        id="btnCreateEmployee"
                        onclick="openEmployeeForm()"
                    >
                        Add Employee
                    </button>
                </div>
            </div>

            <div id="employeeContent">
                Loading employees...
            </div>
        </div>

        <div id="formArea"></div>
    `;

    try {
        const rows = await api("/employees");

        document.getElementById("employeeContent").innerHTML = `
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Joining</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${
                            Array.isArray(rows) && rows.length
                                ? rows.map(x => `
                                    <tr>
                                        <td>${escapeHtml(x.employee_id || "—")}</td>
                                        <td>${escapeHtml(x.name || "—")}</td>
                                        <td>${escapeHtml(x.email || "—")}</td>
                                        <td>${escapeHtml(x.role || "—")}</td>
                                        <td>${escapeHtml(x.department || "—")}</td>
                                        <td>${x.joining_date || "—"}</td>
                                        <td>
                                            <button
                                                type="button"
                                                class="secondary"
                                                onclick='editEmployee(${JSON.stringify(x).replace(/'/g, "&#39;")})'
                                            >
                                                Edit
                                            </button>
                                            <button
                                                type="button"
                                                class="danger"
                                                onclick="delEmployee(${x.id})"
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                `).join("")
                                : `
                                    <tr>
                                        <td colspan="7" class="muted" style="text-align:center; padding: 24px;">
                                            No employees found.
                                        </td>
                                    </tr>
                                `
                        }
                    </tbody>
                </table>
            </div>
        `;

    } catch (error) {
        document.getElementById("employeeContent").innerHTML = `
            <div class="content-card">
                <p class="error" style="color: #dc2626;">
                    ${escapeHtml(error.message)}
                </p>
            </div>
        `;
    }
}

function openEmployeeForm(x = {}) {
    const formArea = document.getElementById("formArea");
    if (!formArea) return;

    formArea.innerHTML = `
        <div class="content-card" style="margin-top: 24px;" id="employeeFormContainer">
            <div class="topbar" style="margin-bottom: 16px;">
                <div>
                    <h2>${x.id ? "Edit" : "Add"} Employee</h2>
                </div>
            </div>

            <form id="ef" class="form-grid">
                <label>
                    Employee ID
                    <input
                        name="employee_id"
                        value="${escapeHtml(x.employee_id || "")}"
                        required
                        placeholder="e.g. 001"
                    >
                </label>

                <label>
                    Name
                    <input
                        name="name"
                        value="${escapeHtml(x.name || "")}"
                        required
                        placeholder="Full Name"
                    >
                </label>

                <label>
                    Email
                    <input
                        name="email"
                        type="email"
                        value="${escapeHtml(x.email || "")}"
                        placeholder="name@nexzibyte.com"
                    >
                </label>

                <label>
                    Phone
                    <input
                        name="phone"
                        value="${escapeHtml(x.phone || "")}"
                        placeholder="Phone Number"
                    >
                </label>

                <label>
                    Role
                    <input
                        name="role"
                        value="${escapeHtml(x.role || "")}"
                        placeholder="e.g. Developer, Designer"
                    >
                </label>

                <label>
                    Department
                    <input
                        name="department"
                        value="${escapeHtml(x.department || "")}"
                        placeholder="e.g. Engineering"
                    >
                </label>

                <label>
                    Joining Date
                    <input
                        name="joining_date"
                        type="date"
                        value="${x.joining_date || ""}"
                    >
                </label>

                <div class="actions full" style="margin-top: 18px; display: flex; gap: 10px;">
                    <button type="submit" class="primary">
                        Save
                    </button>
                    <button type="button" class="secondary" onclick="closeForm()">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    `;

    // Smooth scroll down to the form
    setTimeout(() => {
        const formEl = document.getElementById("employeeFormContainer");
        const scrollParent = document.querySelector(".main-content") || window;
        if (formEl) {
            formEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    }, 50);

    document.getElementById("ef").onsubmit = async function (e) {
        e.preventDefault();

        try {
            const data = Object.fromEntries(new FormData(e.target));

            await api(
                x.id ? `/employees/${x.id}` : "/employees",
                {
                    method: x.id ? "PUT" : "POST",
                    body: JSON.stringify(data)
                }
            );

            alert(x.id ? "Employee updated successfully" : "Employee added successfully");
            closeForm();
            await loadEmployees();

        } catch (error) {
            alert("Operation failed: " + error.message);
        }
    };
}

// Backward-compatible function aliases
window.form = openEmployeeForm;
window.openEmployeeForm = openEmployeeForm;

function editEmployee(x) {
    openEmployeeForm(x);
}
window.edit = editEmployee;
window.editEmployee = editEmployee;

function closeForm() {
    const formArea = document.getElementById("formArea");
    if (formArea) {
        formArea.innerHTML = "";
    }
}
window.closeForm = closeForm;

async function delEmployee(id) {
    if (!confirm("Are you sure you want to delete this employee?")) {
        return;
    }

    try {
        await api(`/employees/${id}`, { method: "DELETE" });
        alert("Employee deleted successfully");
        await loadEmployees();
    } catch (error) {
        alert("Delete failed: " + error.message);
    }
}
window.del = delEmployee;
window.delEmployee = delEmployee;

loadEmployees();