requireAuth();

async function loadAttendance() {

    const app = document.getElementById("app");
    const currentUser = user();

    if (!currentUser) {
        location.href = "login.html";
        return;
    }

    app.innerHTML = `
        <div class="content-card">

            <div class="topbar">

                <div>

                    <h1>Attendance</h1>

                    <p class="muted">
                        Attendance records
                    </p>

                </div>

                ${
                    currentUser.role === "admin"
                        ? `
                        `
                        : ""
                }

            </div>


            <div id="attendanceContent">
                Loading attendance...
            </div>

        </div>


        <div id="formArea"></div>
    `;


    try {

        const rows = await api("/attendance");

        let interns = [];

        if (currentUser.role === "admin") {
            interns = await api("/interns");
        }


        document.getElementById(
            "attendanceContent"
        ).innerHTML = `

            <div class="table-wrap">

                <table>

                    <thead>

                        <tr>

                            <th>Date</th>
                            <th>Intern</th>
                            <th>Login</th>
                            <th>Logout</th>
                            <th>Status</th>
                            <th>Working</th>

                        </tr>

                    </thead>


                    <tbody>

                        ${
                            rows.length
                                ? rows.map(r => {

                                    const internName =
                                        currentUser.role === "admin"
                                            ? (
                                                interns.find(
                                                    i => i.id === r.intern_id
                                                )?.name || "Unknown"
                                            )
                                            : "You";


                                    const working =
                                        r.working_minutes != null
                                            ? Math.floor(
                                                r.working_minutes / 60
                                            ) +
                                            "h " +
                                            (
                                                r.working_minutes % 60
                                            ) +
                                            "m"
                                            : "-";


                                    return `

                                        <tr>

                                            <td>
                                                ${r.attendance_date || "-"}
                                            </td>

                                            <td>
                                                ${escapeHtml(internName)}
                                            </td>

                                            <td>
                                                ${r.login_time || "-"}
                                            </td>

                                            <td>
                                                ${r.logout_time || "-"}
                                            </td>

                                            <td>

                                                <span class="badge">
                                                    ${escapeHtml(
                                                        r.status || "-"
                                                    )}
                                                </span>

                                            </td>

                                            <td>
                                                ${working}
                                            </td>

                                        </tr>

                                    `;

                                }).join("")
                                : `

                                    <tr>

                                        <td
                                            colspan="6"
                                            class="muted"
                                        >
                                            No attendance records found.
                                        </td>

                                    </tr>

                                `
                        }

                    </tbody>

                </table>

            </div>
        `;


    } catch (error) {

        document.getElementById(
            "attendanceContent"
        ).innerHTML = `

            <div class="content-card">

                <p class="error">
                    ${escapeHtml(error.message)}
                </p>

            </div>

        `;
    }
}


async function attForm() {

    const currentUser = user();

    if (!currentUser || currentUser.role !== "admin") {
        alert("Access denied");
        return;
    }


    try {

        const interns = await api("/interns");


        document.getElementById(
            "formArea"
        ).innerHTML = `

            <div class="content-card">

                <div class="topbar">

                    <div>
                        <h2>Attendance Entry</h2>
                    </div>

                </div>


                <form
                    id="attf"
                    class="form-grid"
                >

                    <label>

                        Intern

                        <select
                            name="intern_id"
                            required
                        >

                            ${interns.map(i => `

                                <option value="${i.id}">
                                    ${escapeHtml(i.name)}
                                </option>

                            `).join("")}

                        </select>

                    </label>


                    <label>

                        Date

                        <input
                            name="attendance_date"
                            type="date"
                            required
                        >

                    </label>


                    <label>

                        Login Time

                        <input
                            name="login_time"
                            placeholder="09:02 AM"
                        >

                    </label>


                    <label>

                        Logout Time

                        <input
                            name="logout_time"
                            placeholder="05:30 PM"
                        >

                    </label>


                    <label>

                        Status

                        <select name="status">

                            <option value="Present">
                                Present
                            </option>

                            <option value="Absent">
                                Absent
                            </option>

                            <option value="Leave">
                                Leave
                            </option>

                        </select>

                    </label>


                    <label>

                        Working Minutes

                        <input
                            name="working_minutes"
                            type="number"
                            min="0"
                        >

                    </label>


                    <div class="actions full">

                        <button
                            type="submit"
                            class="primary"
                        >
                            Save
                        </button>


                        <button
                            type="button"
                            class="secondary"
                            onclick="closeAttendanceForm()"
                        >
                            Cancel
                        </button>

                    </div>

                </form>

            </div>
        `;


        document.getElementById(
            "attf"
        ).onsubmit = async function (e) {

            e.preventDefault();


            try {

                const d =
                    Object.fromEntries(
                        new FormData(e.target)
                    );


                d.intern_id =
                    Number(d.intern_id);


                if (d.working_minutes) {

                    d.working_minutes =
                        Number(d.working_minutes);

                } else {

                    d.working_minutes = null;

                }


                await api(
                    "/attendance",
                    {
                        method: "POST",
                        body: JSON.stringify(d)
                    }
                );


                alert(
                    "Attendance saved successfully"
                );


                closeAttendanceForm();

                await loadAttendance();


            } catch (error) {

                alert(
                    "Failed to save attendance: " +
                    error.message
                );

            }

        };


    } catch (error) {

        alert(
            "Unable to load interns: " +
            error.message
        );

    }
}


function closeAttendanceForm() {

    const formArea =
        document.getElementById("formArea");

    if (formArea) {
        formArea.innerHTML = "";
    }
}


loadAttendance();
