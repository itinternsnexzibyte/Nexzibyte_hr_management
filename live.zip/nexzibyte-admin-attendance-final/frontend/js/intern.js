console.log("Intern JS loaded");

let isAdmin = false;
let currentIntern = null;

// =========================================================
// FORMAT DATE
// =========================================================

function formatDate(dateValue) {
if (!dateValue) {
return "-";
}

const date = new Date(dateValue);

if (Number.isNaN(date.getTime())) {
    return dateValue;
}

return date.toLocaleDateString("en-IN");

}

// =========================================================
// LOAD PAGE
// =========================================================

async function loadInternPage() {

const app =
    document.getElementById("app");

const currentUser =
    user();

if (!currentUser) {
    location.href = "login.html";
    return;
}

isAdmin =
    currentUser.role === "admin";


// =====================================================
// ADMIN VIEW
// =====================================================

if (isAdmin) {
    await loadAdminInternPage();
    return;
}


// =====================================================
// INTERN VIEW
// =====================================================

await loadMyInternPage();

}

// =========================================================
// ADMIN PAGE
// =========================================================

async function loadAdminInternPage() {

const app =
    document.getElementById("app");


app.innerHTML = `

    <div class="content-card">

        <div class="topbar">

            <div>

                <h2>Intern Details</h2>

                <p class="muted">
                    Manage intern information
                    and offer letters.
                </p>

            </div>


            <div>

                <button
                    type="button"
                    class="btn primary"
                    onclick="showAdminInternForm()"
                >
                    + Add Intern
                </button>

            </div>

        </div>


        <div class="toolbar">

            <input
                id="internSearch"
                class="input"
                type="text"
                placeholder="Search interns..."
            >

        </div>


        <div id="internContent">
            Loading interns...
        </div>

    </div>
`;


await loadAdminInterns();


const searchInput =
    document.getElementById(
        "internSearch"
    );


if (searchInput) {

    searchInput.addEventListener(
        "input",
        loadAdminInterns
    );
}

}

// =========================================================
// ADMIN - LOAD ALL INTERNS
// =========================================================

async function loadAdminInterns() {

const container =
    document.getElementById(
        "internContent"
    );


if (!container) {
    return;
}


try {

    const searchInput =
        document.getElementById(
            "internSearch"
        );


    const search =
        searchInput?.value.trim() || "";


    const query =
        search
            ? `?search=${encodeURIComponent(search)}`
            : "";


    const interns =
        await api(
            `/interns${query}`
        );


    if (!interns || interns.length === 0) {

        container.innerHTML = `
            <div class="empty-state">

                <p>
                    No interns found.
                </p>

            </div>
        `;

        return;
    }


    container.innerHTML = `

        <div style="overflow-x:auto;">

            <table class="data-table">

                <thead>

                    <tr>

                        <th>Intern ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>College</th>
                        <th>Course</th>
                        <th>Role</th>
                        <th>Joining Date</th>
                        <th>Duration</th>
                        <th>Status</th>
                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                    ${
                        interns.map(
                            intern => `

                                <tr>

                                    <td>
                                        ${escapeHtml(
                                            intern.intern_code || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.name || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.email || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.phone || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.college || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.course || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            intern.internship_role || "-"
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            formatDate(
                                                intern.joining_date
                                            )
                                        )}
                                    </td>

                                    <td>
                                        ${escapeHtml(
                                            String(
                                                intern.duration_months || 0
                                            )
                                        )}
                                        months
                                    </td>

                                    <td>
                                        <span class="status-badge">
                                            ${escapeHtml(
                                                intern.status || "-"
                                            )}
                                        </span>
                                    </td>

                                    <td>

                                        <button
                                            type="button"
                                            class="btn small"
                                            onclick="editAdminIntern(${Number(intern.id)})"
                                        >
                                            Edit
                                        </button>

                                        <button
                                            type="button"
                                            class="btn small danger"
                                            onclick="deleteAdminIntern(${Number(intern.id)})"
                                        >
                                            Delete
                                        </button>

                                    </td>

                                </tr>

                            `
                        ).join("")
                    }

                </tbody>

            </table>

        </div>
    `;

} catch (error) {

    console.error(
        "Admin intern loading failed:",
        error
    );


    container.innerHTML = `
        <div class="error">
            ${escapeHtml(
                error.message
            )}
        </div>
    `;
}

}

// =========================================================
// INTERN PERSONAL PAGE
// =========================================================

async function loadMyInternPage() {

const app =
    document.getElementById("app");


const currentUser =
    user();


app.innerHTML = `

    <div class="content-card">

        <div class="topbar">

            <div>

                <h2>My Intern Details</h2>

                <p class="muted">
                    View and manage your
                    internship information.
                </p>

            </div>


            <div>

                <button
                    type="button"
                    class="secondary"
                    onclick="location.href='intern-dashboard.html'"
                >
                    Back to Dashboard
                </button>

            </div>

        </div>


        <div id="myInternContent">
            Loading your details...
        </div>

    </div>
`;


try {

    const intern =
        await api("/interns/me");


    currentIntern =
        intern;


    renderMyInternDetails(
        intern
    );

} catch (error) {

    // -------------------------------------------------
    // NO INTERN RECORD YET
    // -------------------------------------------------

    if (
        error.message
            .toLowerCase()
            .includes("have not been created")
    ) {

        currentIntern = null;

        renderCreateInternMessage();

        return;
    }


    console.error(
        "Loading my intern details failed:",
        error
    );


    document.getElementById(
        "myInternContent"
    ).innerHTML = `

        <div class="error">
            ${escapeHtml(
                error.message
            )}
        </div>

    `;
}

}

// =========================================================
// RENDER INTERN DETAILS
// =========================================================

function renderMyInternDetails(
intern
) {

const container =
    document.getElementById(
        "myInternContent"
    );


container.innerHTML = `

    <div class="content-card">

        <div class="topbar">

            <div>

                <h3>
                    Internship Information
                </h3>

                <p class="muted">
                    Your registered intern details.
                </p>

            </div>


            <div>

                <button
                    type="button"
                    class="btn primary"
                    onclick="showMyInternForm()"
                >
                    Edit Details
                </button>

            </div>

        </div>


        <div class="table-wrap">

            <table class="data-table">

                <tbody>

                    <tr>

                        <th>Intern ID</th>

                        <td>
                            ${escapeHtml(
                                intern.intern_code || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Name</th>

                        <td>
                            ${escapeHtml(
                                intern.name || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Email</th>

                        <td>
                            ${escapeHtml(
                                intern.email || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Phone</th>

                        <td>
                            ${escapeHtml(
                                intern.phone || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>College</th>

                        <td>
                            ${escapeHtml(
                                intern.college || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Course</th>

                        <td>
                            ${escapeHtml(
                                intern.course || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Internship Role</th>

                        <td>
                            ${escapeHtml(
                                intern.internship_role || "-"
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Joining Date</th>

                        <td>
                            ${escapeHtml(
                                formatDate(
                                    intern.joining_date
                                )
                            )}
                        </td>

                    </tr>


                    <tr>

                        <th>Duration</th>

                        <td>
                            ${escapeHtml(
                                String(
                                    intern.duration_months || 0
                                )
                            )}
                            months
                        </td>

                    </tr>


                    <tr>

                        <th>Status</th>

                        <td>

                            <span class="status-badge">
                                ${escapeHtml(
                                    intern.status || "-"
                                )}
                            </span>

                        </td>

                    </tr>

                </tbody>

            </table>

        </div>


        <div
            style="
                margin-top: 25px;
                text-align: center;
            "
        >

            <button
                type="button"
                class="secondary"
                onclick="location.href='attendance.html'"
            >
                Attendance
            </button>


            <button
                type="button"
                class="secondary"
                onclick="location.href='assignment.html'"
            >
                Assignments
            </button>

        </div>

    </div>
`;

}

// =========================================================
// CREATE DETAILS MESSAGE
// =========================================================

function renderCreateInternMessage() {

const container =
    document.getElementById(
        "myInternContent"
    );


container.innerHTML = `

    <div class="content-card">

        <h3>
            Intern Details Not Found
        </h3>


        <p class="muted">

            Your account has been approved,
            but your intern details have not
            been created yet.

        </p>


        <button
            type="button"
            class="btn primary"
            onclick="showMyInternForm()"
        >
            Create My Details
        </button>

    </div>
`;

}

// =========================================================
// INTERN CREATE / EDIT FORM
// =========================================================

function showMyInternForm() {

const intern =
    currentIntern;


const isEdit =
    Boolean(intern);


const currentUser =
    user();


const modal =
    document.createElement(
        "div"
    );


modal.className =
    "modal-overlay";


modal.innerHTML = `

    <div class="modal">

        <div class="modal-header">

            <h3>

                ${
                    isEdit
                        ? "Edit My Details"
                        : "Create My Details"
                }

            </h3>


            <button
                type="button"
                class="modal-close"
                onclick="this.closest('.modal-overlay').remove()"
            >
                ×
            </button>

        </div>


        <form id="myInternForm">

            <div class="form-grid">


                <!-- INTERN ID -->

                <div>

                    <label>
                        Intern ID
                    </label>

                    <input
                        id="myInternCode"
                        class="input"
                        type="text"
                        maxlength="20"
                        value="${escapeHtml(
                            intern?.intern_code || ""
                        )}"
                        ${
                            isEdit
                                ? "readonly"
                                : ""
                        }
                        required
                    >

                </div>


                <!-- NAME -->

                <div>

                    <label>
                        Name
                    </label>

                    <input
                        id="myInternName"
                        class="input"
                        type="text"
                        maxlength="150"
                        value="${escapeHtml(
                            intern?.name ||
                            currentUser.name ||
                            ""
                        )}"
                        required
                    >

                </div>


                <!-- EMAIL -->

                <div>

                    <label>
                        Email
                    </label>

                    <input
                        id="myInternEmail"
                        class="input"
                        type="email"
                        value="${escapeHtml(
                            currentUser.email ||
                            intern?.email ||
                            ""
                        )}"
                        readonly
                    >

                </div>


                <!-- PHONE -->

                <div>

                    <label>
                        Phone
                    </label>

                    <input
                        id="myInternPhone"
                        class="input"
                        type="text"
                        value="${escapeHtml(
                            intern?.phone || ""
                        )}"
                    >

                </div>


                <!-- COLLEGE -->

                <div>

                    <label>
                        College
                    </label>

                    <input
                        id="myInternCollege"
                        class="input"
                        type="text"
                        value="${escapeHtml(
                            intern?.college || ""
                        )}"
                    >

                </div>


                <!-- COURSE -->

                <div>

                    <label>
                        Course
                    </label>

                    <input
                        id="myInternCourse"
                        class="input"
                        type="text"
                        value="${escapeHtml(
                            intern?.course || ""
                        )}"
                    >

                </div>


                <!-- ROLE -->

                <div>

                    <label>
                        Internship Role
                    </label>

                    <input
                        id="myInternRole"
                        class="input"
                        type="text"
                        value="${escapeHtml(
                            intern?.internship_role ||
                            "Full Stack Developer"
                        )}"
                        required
                    >

                </div>


                <!-- JOINING DATE -->

                <div>

                    <label>
                        Joining Date
                    </label>

                    <input
                        id="myJoiningDate"
                        class="input"
                        type="date"
                        value="${escapeHtml(
                            intern?.joining_date || ""
                        )}"
                        required
                    >

                </div>


                <!-- DURATION -->

                <div>

                    <label>
                        Duration (months)
                    </label>

                    <input
                        id="myDuration"
                        class="input"
                        type="number"
                        min="1"
                        max="60"
                        value="${escapeHtml(
                            intern?.duration_months ||
                            5
                        )}"
                        required
                    >

                </div>


                <!-- STATUS -->

                <div>

                    <label>
                        Status
                    </label>

                    <select
                        id="myStatus"
                        class="input"
                    >

                        <option
                            value="Active"
                            ${
                                !intern ||
                                intern.status === "Active"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Active
                        </option>

                        <option
                            value="Completed"
                            ${
                                intern?.status === "Completed"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Completed
                        </option>

                        <option
                            value="Inactive"
                            ${
                                intern?.status === "Inactive"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Inactive
                        </option>

                    </select>

                </div>

            </div>


            <div class="modal-actions">

                <button
                    type="button"
                    class="btn"
                    onclick="this.closest('.modal-overlay').remove()"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="btn primary"
                >

                    ${
                        isEdit
                            ? "Update Details"
                            : "Create Details"
                    }

                </button>

            </div>

        </form>

    </div>
`;


document.body.appendChild(
    modal
);


document
    .getElementById(
        "myInternForm"
    )
    .addEventListener(
        "submit",
        saveMyInternDetails
    );

}

// =========================================================
// SAVE MY DETAILS
// =========================================================

async function saveMyInternDetails(
event
) {

event.preventDefault();


const data = {

    intern_code:
        document
            .getElementById(
                "myInternCode"
            )
            .value
            .trim(),

    name:
        document
            .getElementById(
                "myInternName"
            )
            .value
            .trim(),

    email:
        document
            .getElementById(
                "myInternEmail"
            )
            .value
            .trim(),

    phone:
        document
            .getElementById(
                "myInternPhone"
            )
            .value
            .trim() ||
        null,

    college:
        document
            .getElementById(
                "myInternCollege"
            )
            .value
            .trim() ||
        null,

    course:
        document
            .getElementById(
                "myInternCourse"
            )
            .value
            .trim() ||
        null,

    internship_role:
        document
            .getElementById(
                "myInternRole"
            )
            .value
            .trim(),

    joining_date:
        document
            .getElementById(
                "myJoiningDate"
            )
            .value,

    duration_months:
        Number(
            document
                .getElementById(
                    "myDuration"
                )
                .value
        ),

    status:
        document
            .getElementById(
                "myStatus"
            )
            .value
};


if (!data.intern_code) {
    alert(
        "Intern ID is required"
    );
    return;
}


if (!data.name) {
    alert(
        "Name is required"
    );
    return;
}


if (!data.joining_date) {
    alert(
        "Joining date is required"
    );
    return;
}


if (
    !data.duration_months ||
    data.duration_months < 1
) {
    alert(
        "Duration must be at least 1 month"
    );
    return;
}


try {

    if (currentIntern) {

        await api(
            "/interns/me",
            {
                method: "PUT",
                body:
                    JSON.stringify(
                        data
                    )
            }
        );


        alert(
            "Your intern details were updated successfully."
        );

    } else {

        await api(
            "/interns/me",
            {
                method: "POST",
                body:
                    JSON.stringify(
                        data
                    )
            }
        );


        alert(
            "Your intern details were created successfully."
        );
    }


    const modal =
        document.querySelector(
            ".modal-overlay"
        );


    if (modal) {
        modal.remove();
    }


    await loadMyInternPage();

} catch (error) {

    console.error(
        "Saving my intern details failed:",
        error
    );


    alert(
        error.message
    );
}

}

// =========================================================
// ADMIN FORM
// =========================================================

function showAdminInternForm(
intern = null
) {

if (!isAdmin) {
    return;
}


const modal =
    document.createElement(
        "div"
    );


modal.className =
    "modal-overlay";


modal.innerHTML = `

    <div class="modal">

        <div class="modal-header">

            <h3>
                ${
                    intern
                        ? "Edit Intern"
                        : "Add Intern"
                }
            </h3>


            <button
                type="button"
                class="modal-close"
                onclick="this.closest('.modal-overlay').remove()"
            >
                ×
            </button>

        </div>


        <form id="adminInternForm">

            <div class="form-grid">

                <div>

                    <label>
                        Intern ID
                    </label>

                    <input
                        id="adminInternCode"
                        class="input"
                        required
                        value="${escapeHtml(
                            intern?.intern_code || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Name
                    </label>

                    <input
                        id="adminInternName"
                        class="input"
                        required
                        value="${escapeHtml(
                            intern?.name || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Email
                    </label>

                    <input
                        id="adminInternEmail"
                        class="input"
                        type="email"
                        required
                        value="${escapeHtml(
                            intern?.email || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Phone
                    </label>

                    <input
                        id="adminInternPhone"
                        class="input"
                        value="${escapeHtml(
                            intern?.phone || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        College
                    </label>

                    <input
                        id="adminInternCollege"
                        class="input"
                        value="${escapeHtml(
                            intern?.college || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Course
                    </label>

                    <input
                        id="adminInternCourse"
                        class="input"
                        value="${escapeHtml(
                            intern?.course || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Internship Role
                    </label>

                    <input
                        id="adminInternRole"
                        class="input"
                        value="${escapeHtml(
                            intern?.internship_role ||
                            "Full Stack Developer"
                        )}"
                        required
                    >

                </div>


                <div>

                    <label>
                        Joining Date
                    </label>

                    <input
                        id="adminJoiningDate"
                        class="input"
                        type="date"
                        required
                        value="${escapeHtml(
                            intern?.joining_date || ""
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Duration (months)
                    </label>

                    <input
                        id="adminDuration"
                        class="input"
                        type="number"
                        min="1"
                        max="60"
                        required
                        value="${escapeHtml(
                            intern?.duration_months || 5
                        )}"
                    >

                </div>


                <div>

                    <label>
                        Status
                    </label>

                    <select
                        id="adminStatus"
                        class="input"
                    >

                        <option
                            value="Active"
                            ${
                                !intern ||
                                intern.status === "Active"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Active
                        </option>

                        <option
                            value="Completed"
                            ${
                                intern?.status === "Completed"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Completed
                        </option>

                        <option
                            value="Inactive"
                            ${
                                intern?.status === "Inactive"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Inactive
                        </option>

                    </select>

                </div>

            </div>


            <div class="modal-actions">

                <button
                    type="button"
                    class="btn"
                    onclick="this.closest('.modal-overlay').remove()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="btn primary"
                >
                    ${
                        intern
                            ? "Update"
                            : "Create"
                    }
                </button>

            </div>

        </form>

    </div>
`;


document.body.appendChild(
    modal
);


document
    .getElementById(
        "adminInternForm"
    )
    .addEventListener(
        "submit",
        async event => {

            event.preventDefault();


            const data = {

                intern_code:
                    document
                        .getElementById(
                            "adminInternCode"
                        )
                        .value
                        .trim(),

                name:
                    document
                        .getElementById(
                            "adminInternName"
                        )
                        .value
                        .trim(),

                email:
                    document
                        .getElementById(
                            "adminInternEmail"
                        )
                        .value
                        .trim(),

                phone:
                    document
                        .getElementById(
                            "adminInternPhone"
                        )
                        .value
                        .trim() ||
                    null,

                college:
                    document
                        .getElementById(
                            "adminInternCollege"
                        )
                        .value
                        .trim() ||
                    null,

                course:
                    document
                        .getElementById(
                            "adminInternCourse"
                        )
                        .value
                        .trim() ||
                    null,

                internship_role:
                    document
                        .getElementById(
                            "adminInternRole"
                        )
                        .value
                        .trim(),

                joining_date:
                    document
                        .getElementById(
                            "adminJoiningDate"
                        )
                        .value,

                duration_months:
                    Number(
                        document
                            .getElementById(
                                "adminDuration"
                            )
                            .value
                    ),

                status:
                    document
                        .getElementById(
                            "adminStatus"
                        )
                        .value
            };


            try {

                if (intern) {

                    await api(
                        `/interns/${intern.id}`,
                        {
                            method: "PUT",
                            body:
                                JSON.stringify(
                                    data
                                )
                        }
                    );


                    alert(
                        "Intern updated successfully."
                    );

                } else {

                    await api(
                        "/interns",
                        {
                            method: "POST",
                            body:
                                JSON.stringify(
                                    data
                                )
                        }
                    );


                    alert(
                        "Intern created successfully."
                    );
                }


                modal.remove();

                await loadAdminInterns();

            } catch (error) {

                alert(
                    error.message
                );
            }
        }
    );

}

// =========================================================
// ADMIN EDIT
// =========================================================

async function editAdminIntern(
internId
) {

try {

    const intern =
        await api(
            `/interns/${internId}`
        );


    showAdminInternForm(
        intern
    );

} catch (error) {

    alert(
        error.message
    );
}

}

// =========================================================
// ADMIN DELETE
// =========================================================

async function deleteAdminIntern(
internId
) {

const confirmed =
    confirm(
        "Are you sure you want to delete this intern?"
    );


if (!confirmed) {
    return;
}


try {

    await api(
        `/interns/${internId}`,
        {
            method: "DELETE"
        }
    );


    alert(
        "Intern deleted successfully."
    );


    await loadAdminInterns();

} catch (error) {

    alert(
        error.message
    );
}

}

// =========================================================
// START
// =========================================================

loadInternPage();