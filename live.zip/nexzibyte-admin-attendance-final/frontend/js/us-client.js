console.log("US Client JS loaded");


requireAuth();


const app = document.getElementById("app");



/* =========================================================
   COUNTRY PHONE CODES
========================================================= */


const countryCodes = [
    { name: "Afghanistan", code: "+93" },
    { name: "Albania", code: "+355" },
    { name: "Algeria", code: "+213" },
    { name: "Andorra", code: "+376" },
    { name: "Angola", code: "+244" },
    { name: "Argentina", code: "+54" },
    { name: "Armenia", code: "+374" },
    { name: "Australia", code: "+61" },
    { name: "Austria", code: "+43" },
    { name: "Azerbaijan", code: "+994" },
    { name: "Bahamas", code: "+1" },
    { name: "Bahrain", code: "+973" },
    { name: "Bangladesh", code: "+880" },
    { name: "Belarus", code: "+375" },
    { name: "Belgium", code: "+32" },
    { name: "Belize", code: "+501" },
    { name: "Benin", code: "+229" },
    { name: "Bhutan", code: "+975" },
    { name: "Bolivia", code: "+591" },
    { name: "Bosnia and Herzegovina", code: "+387" },
    { name: "Botswana", code: "+267" },
    { name: "Brazil", code: "+55" },
    { name: "Brunei", code: "+673" },
    { name: "Bulgaria", code: "+359" },
    { name: "Burkina Faso", code: "+226" },
    { name: "Burundi", code: "+257" },
    { name: "Cambodia", code: "+855" },
    { name: "Cameroon", code: "+237" },
    { name: "Canada", code: "+1" },
    { name: "Chad", code: "+235" },
    { name: "Chile", code: "+56" },
    { name: "China", code: "+86" },
    { name: "Colombia", code: "+57" },
    { name: "Comoros", code: "+269" },
    { name: "Costa Rica", code: "+506" },
    { name: "Croatia", code: "+385" },
    { name: "Cuba", code: "+53" },
    { name: "Cyprus", code: "+357" },
    { name: "Czech Republic", code: "+420" },
    { name: "Denmark", code: "+45" },
    { name: "Djibouti", code: "+253" },
    { name: "Dominica", code: "+1" },
    { name: "Ecuador", code: "+593" },
    { name: "Egypt", code: "+20" },
    { name: "El Salvador", code: "+503" },
    { name: "Estonia", code: "+372" },
    { name: "Ethiopia", code: "+251" },
    { name: "Fiji", code: "+679" },
    { name: "Finland", code: "+358" },
    { name: "France", code: "+33" },
    { name: "Gabon", code: "+241" },
    { name: "Gambia", code: "+220" },
    { name: "Georgia", code: "+995" },
    { name: "Germany", code: "+49" },
    { name: "Ghana", code: "+233" },
    { name: "Greece", code: "+30" },
    { name: "Guatemala", code: "+502" },
    { name: "Guinea", code: "+224" },
    { name: "Guyana", code: "+592" },
    { name: "Haiti", code: "+509" },
    { name: "Honduras", code: "+504" },
    { name: "Hong Kong", code: "+852" },
    { name: "Hungary", code: "+36" },
    { name: "Iceland", code: "+354" },
    { name: "India", code: "+91" },
    { name: "Indonesia", code: "+62" },
    { name: "Iran", code: "+98" },
    { name: "Iraq", code: "+964" },
    { name: "Ireland", code: "+353" },
    { name: "Israel", code: "+972" },
    { name: "Italy", code: "+39" },
    { name: "Jamaica", code: "+1" },
    { name: "Japan", code: "+81" },
    { name: "Jordan", code: "+962" },
    { name: "Kazakhstan", code: "+7" },
    { name: "Kenya", code: "+254" },
    { name: "Kuwait", code: "+965" },
    { name: "Kyrgyzstan", code: "+996" },
    { name: "Laos", code: "+856" },
    { name: "Latvia", code: "+371" },
    { name: "Lebanon", code: "+961" },
    { name: "Lesotho", code: "+266" },
    { name: "Liberia", code: "+231" },
    { name: "Libya", code: "+218" },
    { name: "Liechtenstein", code: "+423" },
    { name: "Lithuania", code: "+370" },
    { name: "Luxembourg", code: "+352" },
    { name: "Madagascar", code: "+261" },
    { name: "Malawi", code: "+265" },
    { name: "Malaysia", code: "+60" },
    { name: "Maldives", code: "+960" },
    { name: "Mali", code: "+223" },
    { name: "Malta", code: "+356" },
    { name: "Mauritius", code: "+230" },
    { name: "Mexico", code: "+52" },
    { name: "Moldova", code: "+373" },
    { name: "Monaco", code: "+377" },
    { name: "Mongolia", code: "+976" },
    { name: "Montenegro", code: "+382" },
    { name: "Morocco", code: "+212" },
    { name: "Mozambique", code: "+258" },
    { name: "Myanmar", code: "+95" },
    { name: "Namibia", code: "+264" },
    { name: "Nepal", code: "+977" },
    { name: "Netherlands", code: "+31" },
    { name: "New Zealand", code: "+64" },
    { name: "Nicaragua", code: "+505" },
    { name: "Niger", code: "+227" },
    { name: "Nigeria", code: "+234" },
    { name: "North Korea", code: "+850" },
    { name: "North Macedonia", code: "+389" },
    { name: "Norway", code: "+47" },
    { name: "Oman", code: "+968" },
    { name: "Pakistan", code: "+92" },
    { name: "Palestine", code: "+970" },
    { name: "Panama", code: "+507" },
    { name: "Papua New Guinea", code: "+675" },
    { name: "Paraguay", code: "+595" },
    { name: "Peru", code: "+51" },
    { name: "Philippines", code: "+63" },
    { name: "Poland", code: "+48" },
    { name: "Portugal", code: "+351" },
    { name: "Qatar", code: "+974" },
    { name: "Romania", code: "+40" },
    { name: "Russia", code: "+7" },
    { name: "Rwanda", code: "+250" },
    { name: "Saudi Arabia", code: "+966" },
    { name: "Senegal", code: "+221" },
    { name: "Serbia", code: "+381" },
    { name: "Singapore", code: "+65" },
    { name: "Slovakia", code: "+421" },
    { name: "Slovenia", code: "+386" },
    { name: "Somalia", code: "+252" },
    { name: "South Africa", code: "+27" },
    { name: "South Korea", code: "+82" },
    { name: "South Sudan", code: "+211" },
    { name: "Spain", code: "+34" },
    { name: "Sri Lanka", code: "+94" },
    { name: "Sudan", code: "+249" },
    { name: "Suriname", code: "+597" },
    { name: "Sweden", code: "+46" },
    { name: "Switzerland", code: "+41" },
    { name: "Syria", code: "+963" },
    { name: "Taiwan", code: "+886" },
    { name: "Tajikistan", code: "+992" },
    { name: "Tanzania", code: "+255" },
    { name: "Thailand", code: "+66" },
    { name: "Togo", code: "+228" },
    { name: "Tonga", code: "+676" },
    { name: "Trinidad and Tobago", code: "+1" },
    { name: "Tunisia", code: "+216" },
    { name: "Turkey", code: "+90" },
    { name: "Turkmenistan", code: "+993" },
    { name: "Uganda", code: "+256" },
    { name: "Ukraine", code: "+380" },
    { name: "United Arab Emirates", code: "+971" },
    { name: "United Kingdom", code: "+44" },
    { name: "United States", code: "+1" },
    { name: "Uruguay", code: "+598" },
    { name: "Uzbekistan", code: "+998" },
    { name: "Vanuatu", code: "+678" },
    { name: "Vatican City", code: "+39" },
    { name: "Venezuela", code: "+58" },
    { name: "Vietnam", code: "+84" },
    { name: "Yemen", code: "+967" },
    { name: "Zambia", code: "+260" },
    { name: "Zimbabwe", code: "+263" }
];


function countryCodeOptions(selectedCode = "") {
    return countryCodes.map(country => `
        <option
            value="${escapeHtml(country.code)}"
            ${country.code === selectedCode ? "selected" : ""}
        >
            ${escapeHtml(country.name)} (${escapeHtml(country.code)})
        </option>
    `).join("");
}


/* =========================================================
   LOAD US CLIENTS
========================================================= */

async function loadUSClients() {

    if (!app) {
        console.error("Element #app not found.");
        return;
    }

    app.innerHTML = `
        <div class="content-card">

            <div class="topbar">

                <div>
                    <h2>US Clients</h2>
                    <p>
                        Manage US clients, documents, availability and agreements.
                    </p>
                </div>

                <button
                    class="primary"
                    onclick="showClientForm()"
                >
                    + Add US Client
                </button>

            </div>

            <div id="clientContent">
                Loading clients...
            </div>

        </div>
    `;

    try {

        const clients = await api("/us-client");

        renderClients(clients);

    } catch (error) {

        console.error("Error loading US clients:", error);

        document.getElementById("clientContent").innerHTML = `
            <p class="error">
                ${escapeHtml(error.message)}
            </p>
        `;
    }
}


/* =========================================================
   RENDER CLIENTS
========================================================= */

function renderClients(clients) {

    const content =
        document.getElementById("clientContent");

    if (!content) {
        return;
    }

    if (!clients || clients.length === 0) {

        content.innerHTML = `
            <div class="empty-state">

                <h3>No US Clients</h3>

                <p>
                    No US clients have been added yet.
                </p>

                <button
                    class="primary"
                    onclick="showClientForm()"
                >
                    + Add US Client
                </button>

            </div>
        `;

        return;
    }

    let html = `
        <div class="table-wrap">

            <table>

                <thead>

                    <tr>
                        <th>Photo</th>
                        <th>Client Name</th>
                        <th>Phone</th>
                        <th>Location</th>
                        <th>Reference Email</th>
                        <th>Availability</th>
                        <th>Aadhaar</th>
                        <th>MOU Agreement</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>
    `;


    clients.forEach(client => {

        const clientName =
            client.client_name || "Unnamed Client";

        const phone =
            client.phone_country_code && client.phone_number
                ? `${client.phone_country_code} ${client.phone_number}`
                : "-";


        const locationParts = [
            client.city,
            client.state_region,
            client.country
        ].filter(Boolean);


        const location =
            locationParts.length > 0
                ? locationParts.join(", ")
                : "-";


        const availability =
            client.availability || "Available";


        const availabilityBadge =
            availability === "Available"
                ? "status-badge"
                : "status-badge unavailable-badge";


        const availableTime =
            availability === "Available" &&
            (client.available_from || client.available_to)
                ? `${client.available_from || "-"} - ${client.available_to || "-"}`
                : "";


        html += `
            <tr>

                <!-- PHOTO -->
                <td>

                    ${
                        client.photo_original_name
                            ? `
                                <div style="
                                    display:flex;
                                    flex-direction:column;
                                    align-items:center;
                                    gap:5px;
                                ">

                                    <img
                                        id="client-photo-${client.id}"
                                        src=""
                                        alt="Client Photo"
                                        style="
                                            width:50px;
                                            height:50px;
                                            object-fit:cover;
                                            border-radius:50%;
                                            display:none;
                                        "
                                    >

                                    <button
                                        type="button"
                                        class="secondary"
                                        onclick="viewPhoto(${client.id})"
                                    >
                                        View
                                    </button>

                                </div>
                            `
                            : `
                                <span>No photo</span>
                            `
                    }

                </td>


                <!-- CLIENT NAME -->
                <td>

                    <strong>
                        ${escapeHtml(clientName)}
                    </strong>

                </td>


                <!-- PHONE -->
                <td>

                    ${escapeHtml(phone)}

                </td>


                <!-- LOCATION -->
                <td>

                    ${escapeHtml(location)}

                    ${
                        client.address
                            ? `
                                <br>
                                <small>
                                    ${escapeHtml(client.address)}
                                </small>
                            `
                            : ""
                    }

                </td>


                <!-- REFERENCE EMAIL -->
                <td>

                    ${
                        client.reference_email
                            ? `
                                <a
                                    href="mailto:${escapeHtml(client.reference_email)}"
                                    title="Send email to ${escapeHtml(client.reference_email)}"
                                >
                                    ${escapeHtml(client.reference_email)}
                                </a>
                            `
                            : `
                                <span>-</span>
                            `
                    }

                </td>


                <!-- AVAILABILITY -->
                <td>

                    <span class="${availabilityBadge}">
                        ${escapeHtml(availability)}
                    </span>

                    ${
                        availableTime
                            ? `
                                <br>
                                <small>
                                    ${escapeHtml(availableTime)}
                                </small>
                            `
                            : ""
                    }

                </td>


                <!-- AADHAAR -->
                <td>

                    ${
                        client.aadhar_original_name
                            ? `
                                <div style="
                                    display:flex;
                                    flex-direction:column;
                                    gap:5px;
                                    align-items:flex-start;
                                ">

                                    <span
                                        title="${escapeHtml(client.aadhar_original_name)}"
                                    >
                                        📄 Aadhaar
                                    </span>

                                    <button
                                        type="button"
                                        class="secondary"
                                        onclick="downloadAadhar(${client.id})"
                                    >
                                        View / Download
                                    </button>

                                </div>
                            `
                            : `
                                <span>
                                    No Aadhaar
                                </span>
                            `
                    }

                </td>


                <!-- MOU -->
                <td>

                    ${
                        client.mou_original_name
                            ? `
                                <div style="
                                    display:flex;
                                    flex-direction:column;
                                    gap:5px;
                                    align-items:flex-start;
                                ">

                                    <span
                                        title="${escapeHtml(client.mou_original_name)}"
                                    >
                                        📄 MOU
                                    </span>

                                    <button
                                        type="button"
                                        class="secondary"
                                        onclick="downloadMou(${client.id})"
                                    >
                                        View / Download
                                    </button>

                                </div>
                            `
                            : `
                                <span>
                                    No MOU
                                </span>
                            `
                    }

                </td>


                <!-- ACTIONS -->
                <td>

                    <button
                        class="secondary"
                        onclick="showEditClientForm(${client.id})"
                    >
                        Edit
                    </button>

                    <button
                        class="secondary"
                        onclick="showDocumentForm(${client.id})"
                    >
                        Documents
                    </button>

                    <button
                        class="danger"
                        onclick="deleteClient(${client.id})"
                    >
                        Delete
                    </button>

                </td>

            </tr>
        `;
    });


    html += `
                </tbody>

            </table>

        </div>

        <div id="clientFormArea"></div>

        <div id="documentFormArea"></div>
    `;


    content.innerHTML = html;


    /* Load protected photos after rendering */

    clients.forEach(client => {

        if (client.photo_original_name) {
            loadClientPhoto(client.id);
        }

    });
}


/* =========================================================
   LOAD PROTECTED CLIENT PHOTO
========================================================= */

async function loadClientPhoto(clientId) {

    const image =
        document.getElementById(
            `client-photo-${clientId}`
        );

    if (!image) {
        return;
    }

    try {

        const response =
            await fetch(
                `${API_BASE}/us-client/${clientId}/photo`,
                {
                    method: "GET",
                    headers: {
                        "Authorization":
                            `Bearer ${token()}`
                    }
                }
            );


        if (!response.ok) {
            throw new Error(
                "Unable to load client photo."
            );
        }


        const blob =
            await response.blob();


        const url =
            window.URL.createObjectURL(blob);


        image.src =
            url;


        image.style.display =
            "block";


    } catch (error) {

        console.error(
            `Error loading photo for client ${clientId}:`,
            error
        );
    }
}


/* =========================================================
   ADD CLIENT FORM
========================================================= */

function showClientForm() {

    const content =
        document.getElementById("clientContent");

    if (!content) {
        return;
    }

    let formArea =
        document.getElementById("clientFormArea");

    if (!formArea) {

        formArea =
            document.createElement("div");

        formArea.id =
            "clientFormArea";

        content.appendChild(formArea);
    }

    formArea.innerHTML = `

        <div
            class="content-card"
            style="margin-top:20px;"
        >

            <h3>Add US Client</h3>

            <form onsubmit="createClient(event)">

                <label>
                    Client Name
                </label>

                <input
                    type="text"
                    id="clientName"
                    placeholder="Enter client name"
                    required
                >


                <label>
                    Phone Country Code
                </label>

                <select id="phoneCountryCode">

                    <option value="">
                        Select country code
                    </option>

                    ${countryCodeOptions()}

                </select>


                <label>
                    Phone Number
                </label>

                <input
                    type="tel"
                    id="phoneNumber"
                    placeholder="Enter phone number"
                >


                <label>
                    Country
                </label>

                <input
                    type="text"
                    id="country"
                    placeholder="Enter country"
                >


                <label>
                    State / Region
                </label>

                <input
                    type="text"
                    id="stateRegion"
                    placeholder="Enter state or region"
                >


                <label>
                    City / Location
                </label>

                <input
                    type="text"
                    id="city"
                    placeholder="Enter city or location"
                >


                <label>
                    Address
                </label>

                <textarea
                    id="address"
                    rows="3"
                    placeholder="Enter complete address"
                ></textarea>


                <label>
                    Availability
                </label>

                <select
                    id="availability"
                    onchange="toggleAvailabilityTime()"
                >

                    <option value="Available">
                        Available
                    </option>

                    <option value="Unavailable">
                        Unavailable
                    </option>

                </select>


                <div id="availabilityTimeArea">

                    <label>
                        Available From
                    </label>

                    <input
                        type="time"
                        id="availableFrom"
                    >


                    <label>
                        Available To
                    </label>

                    <input
                        type="time"
                        id="availableTo"
                    >

                </div>


                <label>
                    Reference Email
                </label>

                <input
                    type="email"
                    id="referenceEmail"
                    placeholder="reference@example.com"
                >


                <label>
                    Notes
                </label>

                <textarea
                    id="notes"
                    rows="4"
                    placeholder="Additional notes"
                ></textarea>


                <br>


                <button
                    type="submit"
                    class="primary"
                >
                    Add Client
                </button>


                <button
                    type="button"
                    class="secondary"
                    onclick="closeClientForm()"
                >
                    Cancel
                </button>

            </form>

        </div>
    `;


    toggleAvailabilityTime();


    formArea.scrollIntoView({
        behavior: "smooth"
    });
}


/* =========================================================
   TOGGLE AVAILABILITY TIME
========================================================= */

function toggleAvailabilityTime() {

    const availability =
        document.getElementById("availability");

    const area =
        document.getElementById(
            "availabilityTimeArea"
        );

    if (!availability || !area) {
        return;
    }

    if (availability.value === "Available") {

        area.style.display =
            "block";

    } else {

        area.style.display =
            "none";

    }
}


/* =========================================================
   CLOSE CLIENT FORM
========================================================= */

function closeClientForm() {

    const formArea =
        document.getElementById(
            "clientFormArea"
        );

    if (formArea) {
        formArea.remove();
    }
}


/* =========================================================
   CREATE CLIENT
========================================================= */

async function createClient(event) {

    event.preventDefault();

    const clientName =
        document.getElementById(
            "clientName"
        ).value.trim();

    if (!clientName) {

        alert(
            "Please enter a client name."
        );

        return;
    }


    const availability =
        document.getElementById(
            "availability"
        ).value;


    const data = {

        client_name:
            clientName,

        phone_country_code:
            document.getElementById(
                "phoneCountryCode"
            ).value || null,

        phone_number:
            document.getElementById(
                "phoneNumber"
            ).value.trim() || null,

        country:
            document.getElementById(
                "country"
            ).value.trim() || null,

        state_region:
            document.getElementById(
                "stateRegion"
            ).value.trim() || null,

        city:
            document.getElementById(
                "city"
            ).value.trim() || null,

        address:
            document.getElementById(
                "address"
            ).value.trim() || null,

        availability:
            availability,

        available_from:
            availability === "Available"
                ? document.getElementById(
                    "availableFrom"
                ).value || null
                : null,

        available_to:
            availability === "Available"
                ? document.getElementById(
                    "availableTo"
                ).value || null
                : null,

        reference_email:
            document.getElementById(
                "referenceEmail"
            ).value.trim() || null,

        notes:
            document.getElementById(
                "notes"
            ).value.trim() || null
    };


    try {

        const result =
            await api(
                "/us-client",
                {
                    method: "POST",
                    body: JSON.stringify(data)
                }
            );


        alert(
            result.message ||
            "US Client added successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error creating client:",
            error
        );

        alert(error.message);
    }
}


/* =========================================================
   EDIT CLIENT FORM
========================================================= */

async function showEditClientForm(clientId) {

    try {

        const clients =
            await api(
                "/us-client"
            );


        const client =
            clients.find(
                item => item.id === clientId
            );


        if (!client) {

            alert(
                "Client not found."
            );

            return;
        }


        const content =
            document.getElementById(
                "clientContent"
            );


        let formArea =
            document.getElementById(
                "clientFormArea"
            );


        if (!formArea) {

            formArea =
                document.createElement(
                    "div"
                );

            formArea.id =
                "clientFormArea";

            content.appendChild(
                formArea
            );
        }


        const availableFrom =
            client.available_from
                ? String(
                    client.available_from
                ).substring(0, 5)
                : "";


        const availableTo =
            client.available_to
                ? String(
                    client.available_to
                ).substring(0, 5)
                : "";


        formArea.innerHTML = `

            <div
                class="content-card"
                style="margin-top:20px;"
            >

                <h3>
                    Edit US Client
                </h3>


                <form
                    onsubmit="updateClient(event, ${client.id})"
                >

                    <label>
                        Client Name
                    </label>

                    <input
                        type="text"
                        id="editClientName"
                        value="${escapeHtml(
                            client.client_name || ""
                        )}"
                        required
                    >


                    <label>
                        Phone Country Code
                    </label>

                    <select
                        id="editPhoneCountryCode"
                    >

                        <option value="">
                            Select country code
                        </option>

                        ${countryCodeOptions(
                            client.phone_country_code || ""
                        )}

                    </select>


                    <label>
                        Phone Number
                    </label>

                    <input
                        type="tel"
                        id="editPhoneNumber"
                        value="${escapeHtml(
                            client.phone_number || ""
                        )}"
                    >


                    <label>
                        Country
                    </label>

                    <input
                        type="text"
                        id="editCountry"
                        value="${escapeHtml(
                            client.country || ""
                        )}"
                    >


                    <label>
                        State / Region
                    </label>

                    <input
                        type="text"
                        id="editStateRegion"
                        value="${escapeHtml(
                            client.state_region || ""
                        )}"
                    >


                    <label>
                        City / Location
                    </label>

                    <input
                        type="text"
                        id="editCity"
                        value="${escapeHtml(
                            client.city || ""
                        )}"
                    >


                    <label>
                        Address
                    </label>

                    <textarea
                        id="editAddress"
                        rows="3"
                    >${escapeHtml(
                        client.address || ""
                    )}</textarea>


                    <label>
                        Availability
                    </label>

                    <select
                        id="editAvailability"
                        onchange="toggleEditAvailabilityTime()"
                    >

                        <option
                            value="Available"
                            ${
                                client.availability ===
                                "Available"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Available
                        </option>

                        <option
                            value="Unavailable"
                            ${
                                client.availability ===
                                "Unavailable"
                                    ? "selected"
                                    : ""
                            }
                        >
                            Unavailable
                        </option>

                    </select>


                    <div
                        id="editAvailabilityTimeArea"
                        style="${
                            client.availability ===
                            "Unavailable"
                                ? "display:none;"
                                : "display:block;"
                        }"
                    >

                        <label>
                            Available From
                        </label>

                        <input
                            type="time"
                            id="editAvailableFrom"
                            value="${escapeHtml(
                                availableFrom
                            )}"
                        >


                        <label>
                            Available To
                        </label>

                        <input
                            type="time"
                            id="editAvailableTo"
                            value="${escapeHtml(
                                availableTo
                            )}"
                        >

                    </div>


                    <label>
                        Reference Email
                    </label>

                    <input
                        type="email"
                        id="editReferenceEmail"
                        value="${escapeHtml(
                            client.reference_email || ""
                        )}"
                    >


                    <label>
                        Notes
                    </label>

                    <textarea
                        id="editNotes"
                        rows="4"
                    >${escapeHtml(
                        client.notes || ""
                    )}</textarea>


                    <br>


                    <button
                        type="submit"
                        class="primary"
                    >
                        Save Changes
                    </button>


                    <button
                        type="button"
                        class="secondary"
                        onclick="closeClientForm()"
                    >
                        Cancel
                    </button>

                </form>

            </div>
        `;


        formArea.scrollIntoView({
            behavior: "smooth"
        });


    } catch (error) {

        console.error(
            "Error loading client:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   TOGGLE EDIT AVAILABILITY TIME
========================================================= */

function toggleEditAvailabilityTime() {

    const availability =
        document.getElementById(
            "editAvailability"
        );

    const area =
        document.getElementById(
            "editAvailabilityTimeArea"
        );


    if (!availability || !area) {
        return;
    }


    area.style.display =
        availability.value ===
        "Available"
            ? "block"
            : "none";
}


/* =========================================================
   UPDATE CLIENT
========================================================= */

async function updateClient(
    event,
    clientId
) {

    event.preventDefault();


    const availability =
        document.getElementById(
            "editAvailability"
        ).value;


    const data = {

        client_name:
            document.getElementById(
                "editClientName"
            ).value.trim(),

        phone_country_code:
            document.getElementById(
                "editPhoneCountryCode"
            ).value || null,

        phone_number:
            document.getElementById(
                "editPhoneNumber"
            ).value.trim() || null,

        country:
            document.getElementById(
                "editCountry"
            ).value.trim() || null,

        state_region:
            document.getElementById(
                "editStateRegion"
            ).value.trim() || null,

        city:
            document.getElementById(
                "editCity"
            ).value.trim() || null,

        address:
            document.getElementById(
                "editAddress"
            ).value.trim() || null,

        availability:
            availability,

        available_from:
            availability === "Available"
                ? document.getElementById(
                    "editAvailableFrom"
                ).value || null
                : null,

        available_to:
            availability === "Available"
                ? document.getElementById(
                    "editAvailableTo"
                ).value || null
                : null,

        reference_email:
            document.getElementById(
                "editReferenceEmail"
            ).value.trim() || null,

        notes:
            document.getElementById(
                "editNotes"
            ).value.trim() || null
    };


    try {

        const result =
            await api(
                `/us-client/${clientId}`,
                {
                    method: "PUT",
                    body: JSON.stringify(data)
                }
            );


        alert(
            result.message ||
            "Client updated successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error updating client:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   DOCUMENT MANAGEMENT FORM
========================================================= */

function showDocumentForm(clientId) {

    const content =
        document.getElementById(
            "clientContent"
        );


    if (!content) {
        return;
    }


    let formArea =
        document.getElementById(
            "documentFormArea"
        );


    if (!formArea) {

        formArea =
            document.createElement(
                "div"
            );

        formArea.id =
            "documentFormArea";

        content.appendChild(
            formArea
        );
    }


    formArea.innerHTML = `

        <div
            class="content-card"
            style="margin-top:20px;"
        >

            <h3>
                Client Documents
            </h3>

            <p>
                Upload or manage the client's Photo, Aadhaar and MOU Agreement.
            </p>

            <hr>


            <h4>
                Client Photo
            </h4>

            <input
                type="file"
                id="photoFile"
                accept=".jpg,.jpeg,.png"
            >

            <br><br>


            <button
                class="primary"
                onclick="uploadPhoto(${clientId})"
            >
                Upload Photo
            </button>

            <button
                class="secondary"
                onclick="viewPhoto(${clientId})"
            >
                View Photo
            </button>

            <button
                class="danger"
                onclick="deletePhoto(${clientId})"
            >
                Delete Photo
            </button>


            <hr>


            <h4>
                Aadhaar Card
            </h4>

            <input
                type="file"
                id="aadharFile"
                accept=".pdf,.jpg,.jpeg,.png"
            >

            <br><br>


            <button
                class="primary"
                onclick="uploadAadhar(${clientId})"
            >
                Upload Aadhaar
            </button>

            <button
                class="secondary"
                onclick="downloadAadhar(${clientId})"
            >
                View / Download Aadhaar
            </button>

            <button
                class="danger"
                onclick="deleteAadhar(${clientId})"
            >
                Delete Aadhaar
            </button>


            <hr>


            <h4>
                MOU Agreement
            </h4>

            <input
                type="file"
                id="mouFile"
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            >

            <br><br>


            <button
                class="primary"
                onclick="uploadMou(${clientId})"
            >
                Upload MOU
            </button>

            <button
                class="secondary"
                onclick="downloadMou(${clientId})"
            >
                View / Download MOU
            </button>

            <button
                class="danger"
                onclick="deleteMou(${clientId})"
            >
                Delete MOU
            </button>


            <br><br>


            <button
                class="secondary"
                onclick="closeDocumentForm()"
            >
                Close
            </button>

        </div>
    `;
    
    
    formArea.scrollIntoView({
        behavior: "smooth"
    });
}


/* =========================================================
   CLOSE DOCUMENT FORM
========================================================= */

function closeDocumentForm() {

    const formArea =
        document.getElementById(
            "documentFormArea"
        );

    if (formArea) {
        formArea.remove();
    }
}


/* =========================================================
   UPLOAD PHOTO
========================================================= */

async function uploadPhoto(clientId) {

    const input =
        document.getElementById(
            "photoFile"
        );


    if (
        !input ||
        !input.files ||
        input.files.length === 0
    ) {

        alert(
            "Please select a photo."
        );

        return;
    }


    const formData =
        new FormData();


    formData.append(
        "file",
        input.files[0]
    );


    try {

        const result =
            await api(
                `/us-client/${clientId}/photo`,
                {
                    method: "POST",
                    body: formData
                }
            );


        alert(
            result.message ||
            "Photo uploaded successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error uploading photo:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   VIEW PHOTO
========================================================= */

async function viewPhoto(clientId) {

    try {

        const response =
            await fetch(
                `${API_BASE}/us-client/${clientId}/photo`,
                {
                    method: "GET",
                    headers: {
                        "Authorization":
                            `Bearer ${token()}`
                    }
                }
            );


        if (!response.ok) {

            let message =
                "Unable to view client photo.";


            try {

                const data =
                    await response.json();


                if (data && data.detail) {

                    message =
                        typeof data.detail ===
                        "string"
                            ? data.detail
                            : JSON.stringify(
                                data.detail
                            );
                }


            } catch {
                // Response was not JSON.
            }


            throw new Error(
                message
            );
        }


        const blob =
            await response.blob();


        const url =
            window.URL.createObjectURL(
                blob
            );


        const newWindow =
            window.open(
                "",
                "_blank"
            );


        if (!newWindow) {

            alert(
                "Please allow pop-ups to view the photo."
            );


            window.URL.revokeObjectURL(
                url
            );


            return;
        }


        newWindow.document.write(`
            <!doctype html>

            <html>

            <head>

                <title>
                    Client Photo
                </title>

                <style>

                    body {
                        margin: 0;
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        background: #111;
                    }

                    img {
                        max-width: 95vw;
                        max-height: 95vh;
                        object-fit: contain;
                    }

                </style>

            </head>

            <body>

                <img
                    src="${url}"
                    alt="Client Photo"
                >

            </body>

            </html>
        `);


        newWindow.document.close();


    } catch (error) {

        console.error(
            "Error viewing photo:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   DELETE PHOTO
========================================================= */

async function deletePhoto(clientId) {

    if (
        !confirm(
            "Are you sure you want to delete the client photo?"
        )
    ) {
        return;
    }


    try {

        const result =
            await api(
                `/us-client/${clientId}/photo`,
                {
                    method: "DELETE"
                }
            );


        alert(
            result.message ||
            "Photo deleted successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error deleting photo:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   UPLOAD AADHAAR
========================================================= */

async function uploadAadhar(clientId) {

    const input =
        document.getElementById(
            "aadharFile"
        );


    if (
        !input ||
        !input.files ||
        input.files.length === 0
    ) {

        alert(
            "Please select an Aadhaar file."
        );

        return;
    }


    const formData =
        new FormData();


    formData.append(
        "file",
        input.files[0]
    );


    try {

        const result =
            await api(
                `/us-client/${clientId}/aadhar`,
                {
                    method: "POST",
                    body: formData
                }
            );


        alert(
            result.message ||
            "Aadhaar uploaded successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error uploading Aadhaar:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   VIEW / DOWNLOAD AADHAAR
========================================================= */

async function downloadAadhar(clientId) {

    try {

        const response =
            await fetch(
                `${API_BASE}/us-client/${clientId}/aadhar`,
                {
                    method: "GET",
                    headers: {
                        "Authorization":
                            `Bearer ${token()}`
                    }
                }
            );


        if (!response.ok) {

            let message =
                "Unable to download Aadhaar.";


            try {

                const data =
                    await response.json();


                if (data && data.detail) {

                    message =
                        typeof data.detail ===
                        "string"
                            ? data.detail
                            : JSON.stringify(
                                data.detail
                            );
                }


            } catch {
                // Response was not JSON.
            }


            throw new Error(
                message
            );
        }


        const blob =
            await response.blob();


        const url =
            window.URL.createObjectURL(
                blob
            );


        const newWindow =
            window.open(
                url,
                "_blank"
            );


        if (!newWindow) {

            const link =
                document.createElement(
                    "a"
                );


            link.href =
                url;


            link.download =
                "Aadhaar-document";


            document.body.appendChild(
                link
            );


            link.click();


            link.remove();
        }


        setTimeout(() => {

            window.URL.revokeObjectURL(
                url
            );

        }, 60000);


    } catch (error) {

        console.error(
            "Error viewing Aadhaar:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   DELETE AADHAAR
========================================================= */

async function deleteAadhar(clientId) {

    if (
        !confirm(
            "Are you sure you want to delete the Aadhaar document?"
        )
    ) {
        return;
    }


    try {

        const result =
            await api(
                `/us-client/${clientId}/aadhar`,
                {
                    method: "DELETE"
                }
            );


        alert(
            result.message ||
            "Aadhaar deleted successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error deleting Aadhaar:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   UPLOAD MOU
========================================================= */

async function uploadMou(clientId) {

    const input =
        document.getElementById(
            "mouFile"
        );


    if (
        !input ||
        !input.files ||
        input.files.length === 0
    ) {

        alert(
            "Please select an MOU file."
        );

        return;
    }


    const formData =
        new FormData();


    formData.append(
        "file",
        input.files[0]
    );


    try {

        const result =
            await api(
                `/us-client/${clientId}/mou`,
                {
                    method: "POST",
                    body: formData
                }
            );


        alert(
            result.message ||
            "MOU uploaded successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error uploading MOU:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   VIEW / DOWNLOAD MOU
========================================================= */

async function downloadMou(clientId) {

    try {

        const response =
            await fetch(
                `${API_BASE}/us-client/${clientId}/mou`,
                {
                    method: "GET",
                    headers: {
                        "Authorization":
                            `Bearer ${token()}`
                    }
                }
            );


        if (!response.ok) {

            let message =
                "Unable to download MOU.";


            try {

                const data =
                    await response.json();


                if (data && data.detail) {

                    message =
                        typeof data.detail ===
                        "string"
                            ? data.detail
                            : JSON.stringify(
                                data.detail
                            );
                }


            } catch {
                // Response was not JSON.
            }


            throw new Error(
                message
            );
        }


        const blob =
            await response.blob();


        const url =
            window.URL.createObjectURL(
                blob
            );


        const newWindow =
            window.open(
                url,
                "_blank"
            );


        if (!newWindow) {

            const link =
                document.createElement(
                    "a"
                );


            link.href =
                url;


            link.download =
                "MOU-Agreement";


            document.body.appendChild(
                link
            );


            link.click();


            link.remove();
        }


        setTimeout(() => {

            window.URL.revokeObjectURL(
                url
            );

        }, 60000);


    } catch (error) {

        console.error(
            "Error viewing MOU:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   DELETE MOU
========================================================= */

async function deleteMou(clientId) {

    if (
        !confirm(
            "Are you sure you want to delete this MOU agreement?"
        )
    ) {
        return;
    }


    try {

        const result =
            await api(
                `/us-client/${clientId}/mou`,
                {
                    method: "DELETE"
                }
            );


        alert(
            result.message ||
            "MOU deleted successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error deleting MOU:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   DELETE CLIENT
========================================================= */

async function deleteClient(clientId) {

    if (
        !confirm(
            "Are you sure you want to delete this entire US client and all associated documents?"
        )
    ) {
        return;
    }


    try {

        const result =
            await api(
                `/us-client/${clientId}`,
                {
                    method: "DELETE"
                }
            );


        alert(
            result.message ||
            "Client deleted successfully."
        );


        await loadUSClients();


    } catch (error) {

        console.error(
            "Error deleting client:",
            error
        );

        alert(
            error.message
        );
    }
}


/* =========================================================
   INITIAL LOAD
========================================================= */

loadUSClients();

