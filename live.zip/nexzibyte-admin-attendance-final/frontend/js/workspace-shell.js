/* Shared workforce shell. All personal data comes from authenticated APIs. */
(() => {
  'use strict';
  const u = () => {try{return JSON.parse(sessionStorage.getItem('nza_user')||'null')}catch{return null}};
  const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const svg = type => `<svg viewBox="0 0 24 24" aria-hidden="true">${type==='bell'?'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21h4"/>':'<path d="M9 4H4v16h5m6-13 5 5-5 5m-7-5h12"/>'}</svg>`;
  const init = name => String(name||'I').trim().split(/\s+/).slice(0,2).map(n=>n[0]).join('').toUpperCase();
  const fmt = seconds => {seconds=Math.max(0,Math.floor(seconds||0));return `${Math.floor(seconds/3600)}h ${String(Math.floor(seconds%3600/60)).padStart(2,'0')}m ${String(seconds%60).padStart(2,'0')}s`};
  const today = () => new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  function toast(msg,type='info'){let host=document.querySelector('.wp-toast-host');if(!host){host=document.createElement('div');host.className='wp-toast-host';host.setAttribute('role','status');document.body.append(host)}const el=document.createElement('div');el.className='wp-toast '+type;el.textContent=msg;host.append(el);setTimeout(()=>el.remove(),6500)}
  async function request(path,options={}){const response=await fetch('http://127.0.0.1:8000/api'+path,{...options,headers:{...(options.body && !(options.body instanceof FormData)?{'Content-Type':'application/json'}:{}),Authorization:'Bearer '+sessionStorage.getItem('nza_token'),...options.headers}});if(!response.ok){let data;try{data=await response.json()}catch{};throw Error(typeof data?.detail==='string'?data.detail:Array.isArray(data?.detail)?data.detail.map(x=>x.msg).join('; '):'Request failed')}return response.json()}
  async function binary(path){const r=await fetch('http://127.0.0.1:8000/api'+path,{headers:{Authorization:'Bearer '+sessionStorage.getItem('nza_token')}});if(!r.ok){throw Error(r.status===404?'No stored file was found':'Unable to open this file')}return URL.createObjectURL(await r.blob())}
  const imageUrls=new Map();let photoIds=null;
  async function avatar(el,iid){if(!iid||(photoIds&&!photoIds.has(iid)))return;try{let url=imageUrls.get(iid);if(!url){url=await binary(`/profiles/${iid}/photo`);imageUrls.set(iid,url)}el.innerHTML=`<img class="wp-avatar ${el.dataset.large?'large':''}" src="${url}" alt="${esc(el.dataset.name||'Intern')} profile photo">`}catch{/* initials remain for interns without photos */}}
  async function refreshPhotos(root=document){const ids=[...root.querySelectorAll('[data-photo]')];await Promise.all(ids.map(el=>avatar(el,Number(el.dataset.photo))))}
  function photo(i,large=false){return `<span data-photo="${i.id}" data-name="${esc(i.name)}" ${large?'data-large="1"':''}><span class="wp-avatar ${large?'large':''}">${esc(init(i.name))}</span></span>`}

  /* Header with medium-sized logo pill & updated labels */
  function header(){
    const user = u();
    if(!user) return '';
    const admin = user.role==='admin';
    const path = location.pathname.split('/').pop();

    const links = admin ? [
      ['dashboard.html', 'Overview'],
      ['intern.html', 'Interns'],
      ['attendance.html', 'Attendance'],
      ['assignment.html', 'Work'],
      ['calendar.html', 'Calendar'],
      ['ratings.html', 'Ratings'],
      ['employees.html', 'Employees'],
      ['us-client.html', 'Clients'],
      ['admin-approvals.html', 'Approvals']
    ] : [
      ['intern-dashboard.html', 'Overview'],
      ['intern.html', 'My profile'],
      ['attendance.html', 'Attendance'],
      ['assignment.html', 'Work'],
      ['calendar.html', 'Calendar']
    ];

    return `<header class="wp-header">
      <a class="wp-brand" href="${admin?'dashboard':'intern-dashboard'}.html" style="display:inline-flex;align-items:center;justify-content:center;background:#ffffff;padding:5px 14px;border-radius:9999px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,0.06);text-decoration:none;">
        <img src="images/nexzibyte-logo.png" alt="Logo" style="height:32px;width:auto;max-width:140px;object-fit:contain;display:block;">
      </a>
      <div class="wp-header-tools">
        <nav class="wp-nav" aria-label="Main navigation">
          ${links.map(([url,n])=>`<a href="${url}" class="${path===url?'active':''}">${n}</a>`).join('')}
        </nav>
        <button class="wp-icon-btn" id="wp-bell" aria-label="Notifications" aria-expanded="false">${svg('bell')}<span id="wp-bell-count" class="wp-notification-count" hidden></span></button>
        <button class="wp-user" id="wp-account" aria-label="Account and logout" aria-expanded="false"><span class="wp-user-dot">${esc(init(admin?'Admin':user.name))}</span><span>${esc(admin?'Admin':user.name?.split(' ')[0]||'Intern')}</span></button>
      </div>
      <section id="wp-notifications" class="wp-popover" hidden aria-label="Notifications"></section>
      <section id="wp-account-menu" class="wp-popover" style="width:240px" hidden>
        <b>${esc(admin?'Admin':user.name)}</b>
        <p class="muted" style="font-size:11px;margin:5px 0 15px">${esc(user.email)}</p>
        ${admin?'<button class="wp-btn light" id="wp-password" style="margin-bottom:10px">Change password</button>':''}
        <button class="wp-btn" id="wp-logout">Sign out</button>
      </section>
    </header>`;
  }

  let notificationData={items:[],unread_count:0};
  let pollBusy=false;
  async function poll(){if(pollBusy||!u()||!sessionStorage.getItem('nza_token'))return;pollBusy=true;try{if(u().role==='admin'){const [approvals,attendanceRequests]=await Promise.all([request('/admin/pending-approvals'),request('/admin/attendance-access-requests')]);notificationData={unread_count:approvals.length+attendanceRequests.length,items:[]};const panel=document.getElementById('wp-notifications');if(panel)panel.innerHTML=`<h3>Notifications</h3><div class="wp-empty">${approvals.length} account approvals · ${attendanceRequests.length} attendance requests</div><a class="wp-btn yellow" href="admin-approvals.html">Review approvals</a>`}else{notificationData=await request('/notifications');renderNotifications()}const count=document.getElementById('wp-bell-count');if(count){count.hidden=!notificationData.unread_count;count.textContent=notificationData.unread_count>99?'99+':notificationData.unread_count}document.getElementById('wp-bell')?.setAttribute('aria-label',`Notifications, ${notificationData.unread_count} unread`)}catch(e){console.warn('Notification refresh:',e.message)}finally{pollBusy=false}}
  function renderNotifications(){const panel=document.getElementById('wp-notifications');if(!panel)return;panel.innerHTML=`<div class="wp-panel-head"><h3>Notifications</h3><button class="wp-btn light" id="wp-read-all">Read all</button></div>${notificationData.items.length?notificationData.items.map(n=>`<button class="wp-notification ${n.is_read?'':'unread'}" data-notice="${n.id}"><b>${esc(n.title)}</b><p>${esc(n.message)}</p><small>${new Date(n.created_at).toLocaleString('en-IN')}</small></button>`).join(''):'<div class="wp-empty">You’re all caught up.</div>'}`;panel.querySelector('#wp-read-all')?.addEventListener('click',async()=>{try{await request('/notifications/read-all',{method:'POST'});await poll()}catch(e){toast(e.message,'error')}});panel.querySelectorAll('[data-notice]').forEach(btn=>btn.onclick=async()=>{try{const n=notificationData.items.find(x=>x.id===Number(btn.dataset.notice));await request(`/notifications/${n.id}/read`,{method:'POST'});if(/^(calendar|assignment)\.html(?:\?|$)/.test(n.link))location.href=n.link;else await poll()}catch(e){toast(e.message,'error')}})}
  function setup(){document.documentElement.dataset.theme=localStorage.getItem('nza_theme')||'light';document.body.dataset.theme=document.documentElement.dataset.theme;document.querySelectorAll('.theme-toggle,.theme-btn,#themeToggleBtn,.nx-search').forEach(el=>el.remove());if(!document.getElementById('wp-bell')&&u()&&!document.body.classList.contains('auth-page')){document.body.classList.add('wp-legacy');document.body.insertAdjacentHTML('afterbegin',header())}document.getElementById('wp-bell')?.addEventListener('click',()=>{const p=document.getElementById('wp-notifications');p.hidden=!p.hidden;document.getElementById('wp-account-menu').hidden=true;document.getElementById('wp-bell').setAttribute('aria-expanded',!p.hidden);poll()});document.getElementById('wp-account')?.addEventListener('click',()=>{const p=document.getElementById('wp-account-menu');p.hidden=!p.hidden;document.getElementById('wp-notifications').hidden=true;document.getElementById('wp-account').setAttribute('aria-expanded',!p.hidden)});document.getElementById('wp-password')?.addEventListener('click',()=>{const d=document.getElementById('wp-modal');if(!d)return;d.innerHTML=`<button class="wp-modal-close" aria-label="Close">×</button><h2>Change admin password</h2><form class="wp-form"><label class="full">Current password<input type="password" name="current_password" required autocomplete="current-password"></label><label class="full">New password<input type="password" name="new_password" minlength="8" maxlength="128" required autocomplete="new-password"></label><label class="full">Confirm new password<input type="password" name="confirm" required autocomplete="new-password"></label><div class="wp-form-actions"><button class="wp-btn yellow">Save password</button></div></form>`;d.style.width='min(600px,95vw)';d.querySelector('.wp-modal-close').onclick=()=>d.close();d.querySelector('form').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));if(data.new_password!==data.confirm){toast('Passwords do not match','error');return}e.submitter.disabled=true;try{await request('/admin/change-password',{method:'POST',body:JSON.stringify({current_password:data.current_password,new_password:data.new_password})});d.close();toast('Password changed.')}catch(e){toast(e.message,'error')}finally{const b=d.querySelector('button[type="submit"],.wp-form-actions button');if(b)b.disabled=false}};d.showModal()});document.getElementById('wp-logout')?.addEventListener('click',async()=>{try{if(u().role!=='admin')await request('/attendance/check-out',{method:'POST'});sessionStorage.removeItem('nza_token');sessionStorage.removeItem('nza_user');location.href='login.html'}catch(e){toast(e.message,'error')}});document.addEventListener('click',e=>{if(!e.target.closest('#wp-bell,#wp-account,.wp-popover'))document.querySelectorAll('.wp-popover').forEach(p=>p.hidden=true)});document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.wp-popover').forEach(p=>p.hidden=true)});poll();setInterval(()=>{if(!document.hidden)poll()},10000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll()});window.addEventListener('focus',poll)}

  // Persistent, professional color palettes for the authenticated admin/intern workspace.
  function installThemePicker(){
    if(document.getElementById('wp-theme-picker'))return;
    const themes=[
      {id:'sunstone',name:'Sunstone',bg:'#eeeade',card:'#fbfaf1',accent:'#f3c440',ink:'#292a23'},
      {id:'ocean',name:'Ocean',bg:'#eaf1f5',card:'#ffffff',accent:'#4c9fba',ink:'#17313c'},
      {id:'forest',name:'Forest',bg:'#eaf0e8',card:'#fbfdf9',accent:'#7da37c',ink:'#26392a'},
      {id:'lavender',name:'Lavender',bg:'#f0edf7',card:'#fffaff',accent:'#a99ad8',ink:'#302b43'},
      {id:'rose',name:'Rose',bg:'#f7eded',card:'#fffafa',accent:'#d88f9c',ink:'#432d34'}
    ];
    const apply=id=>{const t=themes.find(x=>x.id===id)||themes[0],r=document.documentElement;r.style.setProperty('--bg',t.bg);r.style.setProperty('--card-bg',t.card);r.style.setProperty('--surface',t.card);r.style.setProperty('--card-subtle',t.id==='ocean'?'#eaf3f7':t.id==='forest'?'#edf4eb':t.id==='lavender'?'#f3eff9':t.id==='rose'?'#f8eeee':'#f2efe3');r.style.setProperty('--card-border',t.id==='ocean'?'#cddfe7':t.id==='forest'?'#d4e1d2':t.id==='lavender'?'#ddd5ed':t.id==='rose'?'#ead6da':'#e4e0cf');r.style.setProperty('--primary',t.accent);r.style.setProperty('--accent',t.accent);r.style.setProperty('--ink',t.ink);r.style.setProperty('--text-main',t.ink);document.body.style.background=t.bg;localStorage.setItem('nza_workspace_theme',t.id);};
    apply(localStorage.getItem('nza_workspace_theme')||'sunstone');
    const b=document.createElement('div');b.id='wp-theme-picker';b.innerHTML='<button type="button" aria-label="Choose color theme" title="Choose theme">◐</button><div class="wp-theme-options" hidden>'+themes.map(t=>'<button type="button" data-theme-choice="'+t.id+'"><i style="background:'+t.accent+'"></i>'+t.name+'</button>').join('')+'</div>';
    document.body.appendChild(b);
    b.querySelector('button[aria-label]').onclick=()=>{const m=b.querySelector('.wp-theme-options');m.hidden=!m.hidden};
    b.querySelectorAll('[data-theme-choice]').forEach(x=>x.onclick=()=>{apply(x.dataset.themeChoice);b.querySelector('.wp-theme-options').hidden=true});
  }
  if(document.body.dataset.workspace){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installThemePicker);else installThemePicker();}

  window.WP={setPhotoMeta:photos=>{photoIds=new Set(photos.map(p=>p.intern_id))},setup,user:u,esc,fmt,today,toast,request,binary,photo,refreshPhotos,header,poll,clearPhoto:id=>{const url=imageUrls.get(id);if(url)URL.revokeObjectURL(url);imageUrls.delete(id)}};
  if(document.body.dataset.workspace)return;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);else setup();
})();