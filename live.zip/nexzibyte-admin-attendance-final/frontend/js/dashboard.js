console.log("Dashboard JS loaded");

async function loadDashboard() {

const app = document.getElementById("app");
const currentUser = user();

if (!currentUser) {
    location.href = "login.html";
    return;
}


app.innerHTML = `
    <div class="content-card">

        <div
            style="
                text-align: center;
                margin-bottom: 80px;
            "
        >

            <img
                src="images/nexzibyte-logo.png"
                alt="Nexzibyte Logo"
                style="
                    width: 500px;
                    height: auto;
                    display: inline-block;
                "
            >

        </div>


        <div class="topbar">

            <div>

                <h2>Dashboard</h2>

                <p class="muted">
                    Welcome back,
                    ${escapeHtml(currentUser.name)}
                </p>

            </div>


            <div>

                <button
                    type="button"
                    class="secondary"
                    onclick="logout()"
                >
                    Logout
                </button>

            </div>

        </div>


        <div id="dashboardContent">
            Loading dashboard...
        </div>

    </div>
`;


try {

    const s =
        await api("/dashboard/summary");

    const dashboardContent =
        document.getElementById(
            "dashboardContent"
        );


    dashboardContent.innerHTML = `

        <div class="cards">

            <div class="stat">

                <span class="muted">
                    Total Interns
                </span>

                <strong>
                    ${s.total_interns || 0}
                </strong>

            </div>


            <div class="stat">

                <span class="muted">
                    Total Employees
                </span>

                <strong>
                    ${s.total_employees || 0}
                </strong>

            </div>


            <div class="stat">

                <span class="muted">
                    Total Assignments
                </span>

                <strong>
                    ${s.total_assignments || 0}
                </strong>

            </div>


            <div class="stat">

                <span class="muted">
                    Today's Attendance
                </span>

                <strong>
                    ${s.today_attendance || 0}
                </strong>

            </div>


            <div class="stat">

                <span class="muted">
                    Pending Ratings
                </span>

                <strong>
                    ${s.pending_ratings || 0}
                </strong>

            </div>


            <div class="stat">

                <span class="muted">
                    Active US Clients
                </span>

                <strong>
                    ${s.active_us_clients || 0}
                </strong>

            </div>

        </div>


        ${
            currentUser.role === "admin"
                ? `
                    <div
                        class="content-card"
                        style="margin-top: 30px;"
                    >

                        <div class="topbar">

                            <div>
                                <h2>
                                    Intern Account Approvals
                                </h2>

                                <p class="muted">
                                    Review new intern registrations,
                                    offer letters, and approval requests.
                                </p>
                            </div>

                            <div>

                                <button
                                    type="button"
                                    class="primary"
                                    onclick="location.href='admin-approvals.html'"
                                >
                                    Intern Approvals
                                </button>

                            </div>

                        </div>

                    </div>
                `
                : ""
        }


        <div
            class="hero-grid"
            style="margin-top: 30px;"
        >

            <!-- INTERNAL -->

            <div
                class="hero-card"
                onclick="location.href='internal.html'"
                style="cursor: pointer;"
            >

                <h2>INTERNAL</h2>

                <p>
                    Intern management and
                    intern-related activities.
                </p>

            </div>


            <!-- EXTERNAL -->

            <div
                class="hero-card"
                onclick="location.href='external.html'"
                style="cursor: pointer;"
            >

                <h2>EXTERNAL</h2>

                <p>
                    External employee and
                    US client management.
                </p>

            </div>

        </div>

    `;

} catch (error) {

    document.getElementById(
        "dashboardContent"
    ).innerHTML = `

        <div class="content-card">

            <p class="error">
                ${escapeHtml(error.message)}
            </p>

        </div>

    `;

}

}

loadDashboard();