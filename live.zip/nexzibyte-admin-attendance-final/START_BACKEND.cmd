@echo off
setlocal
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
 echo Run SETUP_WINDOWS.cmd first.
 pause
 exit /b 1
)
if not exist ".env" (
 echo Copy your working .env into backend, or run SETUP_WINDOWS.cmd.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m app.seed
if errorlevel 1 (
 echo Check your MySQL connection and .env settings above.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
pause
