from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "mysql+pymysql://root:YOUR_PASSWORD@127.0.0.1:3306/nexzibyte_attendance"

    secret_key: str = "change-me"

    access_token_expire_minutes: int = 720

    frontend_url: str = "http://localhost:5500"

    admin_email: str = ""

    admin_initial_password: str = ""

    email_host: str = ""

    email_port: int = 587

    email_username: str = ""

    email_password: str = ""

    email_from: str = ""

    email_use_tls: bool = True

    max_file_size_mb: int = 10

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )


settings = Settings()