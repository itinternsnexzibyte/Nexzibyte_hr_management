"""Daily attendance in India time. Timestamps are stored as naive IST values.
Legacy rows stay intact; the API groups them into one intern/day record.
"""
from concurrent.futures import ThreadPoolExecutor
import logging
from datetime import datetime, time, timedelta
from math import radians, sin, cos, sqrt, atan2
from zoneinfo import ZoneInfo
from sqlalchemy import select
from ..models import Attendance, Intern, User, WorkSession, AttendanceBreak, AttendanceLocation

email_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="attendance-email")
logger = logging.getLogger(__name__)
IST = ZoneInfo("Asia/Kolkata")


def deliver_checkout_email(to_email: str, body: str, subject: str = "Attendance Alert - Connection Lost") -> None:
    try:
        from ..email_service import send_email
        send_email(to_email, subject, body)
    except Exception:
        logger.exception("Could not send forced-checkout email to %s", to_email)

def now_ist():
    return datetime.now(IST).replace(tzinfo=None)



def haversine_meters(lat1, lon1, lat2, lon2):
    """Return surface distance in meters between two GPS coordinates."""
    earth_radius = 6371000.0
    p1, p2 = radians(lat1), radians(lat2)
    dp = radians(lat2 - lat1)
    dl = radians(lon2 - lon1)
    a = sin(dp / 2) ** 2 + cos(p1) * cos(p2) * sin(dl / 2) ** 2
    return 2 * earth_radius * atan2(sqrt(a), sqrt(max(0.0, 1 - a)))


def record_location(db, attendance_id, latitude, longitude, accuracy=None, captured_at=None):
    captured_at = captured_at or now_ist()
    history = db.scalars(
        select(AttendanceLocation)
        .where(AttendanceLocation.attendance_id == attendance_id)
        .order_by(AttendanceLocation.captured_at)
    ).all()
    if history:
        start = history[0]
        total_from_start = haversine_meters(start.latitude, start.longitude, latitude, longitude)
        previous = history[-1]
        from_previous = haversine_meters(previous.latitude, previous.longitude, latitude, longitude)
    else:
        total_from_start = 0.0
        from_previous = 0.0
    row = AttendanceLocation(
        attendance_id=attendance_id,
        captured_at=captured_at,
        latitude=float(latitude),
        longitude=float(longitude),
        accuracy_meters=float(accuracy) if accuracy is not None else None,
        distance_from_start_meters=round(total_from_start, 2),
        distance_from_previous_meters=round(from_previous, 2),
    )
    db.add(row)
    return row

def parse_time(value):
    for fmt in ("%H:%M:%S", "%H:%M", "%I:%M:%S %p", "%I:%M %p"):
        try:
            return datetime.strptime(value, fmt).time()
        except (ValueError, TypeError):
            pass
    return None

def midnight_after(day):
    return datetime.combine(day + timedelta(days=1), time.min)

def import_legacy_sessions(db):
    # Only rows with no session history need importing; no destructive migration.
    for row in db.scalars(select(Attendance)).all():
        if db.scalar(select(WorkSession.id).where(WorkSession.attendance_id == row.id)):
            continue
        start = parse_time(row.login_time)
        if not start:
            continue
        start = datetime.combine(row.attendance_date, start)
        end_time = parse_time(row.logout_time)
        end = datetime.combine(row.attendance_date, end_time) if end_time else None
        if end and end < start:
            end += timedelta(days=1)
        if end is None and row.attendance_date < now_ist().date():
            end = midnight_after(row.attendance_date)
        db.add(WorkSession(attendance_id=row.id, started_at=start, ended_at=end))
    db.flush()

def expire_previous_days(db, intern_id, now):
    rows = db.scalars(select(Attendance).where(Attendance.intern_id == intern_id, Attendance.attendance_date < now.date())).all()
    for row in rows:
        cutoff = midnight_after(row.attendance_date)
        for model in (WorkSession, AttendanceBreak):
            for item in db.scalars(select(model).where(model.attendance_id == row.id, model.ended_at.is_(None))).all():
                item.ended_at = cutoff
        if not row.logout_time:
            row.logout_time = "23:59:59"
            row.status = "Present"

def check_in(db, intern, now=None):
    now = now or now_ist()
    # Serializes actions for this intern on MySQL/PostgreSQL, including new daily rows.
    db.scalar(select(Intern).where(Intern.id == intern.id).with_for_update())
    expire_previous_days(db, intern.id, now)
    row = db.scalar(select(Attendance).where(Attendance.intern_id == intern.id, Attendance.attendance_date == now.date()).order_by(Attendance.id))
    if row is None:
        row = Attendance(intern_id=intern.id, attendance_date=now.date(), login_time=now.strftime("%H:%M:%S"), status="Online", working_minutes=0)
        db.add(row)
        db.flush()
    ids = list(db.scalars(select(Attendance.id).where(Attendance.intern_id == intern.id, Attendance.attendance_date == now.date())))
    active = db.scalar(select(WorkSession).where(WorkSession.attendance_id.in_(ids), WorkSession.ended_at.is_(None)))
    if not active:
        active = WorkSession(attendance_id=row.id, started_at=now, last_heartbeat_at=now)
        db.add(active)
    else:
        active.last_heartbeat_at = now
    row.logout_time = None
    row.status = "Online"
    db.flush()
    return row

def duration(seconds):
    seconds = max(0, int(seconds))
    h, r = divmod(seconds, 3600)
    m, s = divmod(r, 60)
    return f"{h}h {m:02d}m {s:02d}s"

def daily_records(db, intern_id=None, day=None):
    stmt = select(Attendance).order_by(Attendance.attendance_date.desc(), Attendance.id)
    if intern_id is not None:
        stmt = stmt.where(Attendance.intern_id == intern_id)
    if day is not None:
        stmt = stmt.where(Attendance.attendance_date == day)
    groups = {}
    for row in db.scalars(stmt).all():
        groups.setdefault((row.intern_id, row.attendance_date), []).append(row)
    now = now_ist()
    result = []
    for (iid, d), rows in groups.items():
        ids = [r.id for r in rows]
        intern = db.get(Intern, iid)
        sessions = db.scalars(select(WorkSession).where(WorkSession.attendance_id.in_(ids)).order_by(WorkSession.started_at)).all()
        breaks = db.scalars(select(AttendanceBreak).where(AttendanceBreak.attendance_id.in_(ids)).order_by(AttendanceBreak.started_at)).all()
        cutoff = min(now, midnight_after(d))
        # Union intervals prevents duplicate legacy sessions inflating work totals.
        intervals = sorted((s.started_at, min(s.ended_at or cutoff, cutoff)) for s in sessions)
        merged = []
        for start, end in intervals:
            if end <= start:
                continue
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        gross = sum((end-start).total_seconds() for start,end in merged)
        break_seconds = 0
        break_items = []
        for b in breaks:
            end = min(b.ended_at or cutoff, cutoff)
            seconds = max(0, (end-b.started_at).total_seconds())
            break_seconds += seconds
            break_items.append({"id":b.id,"break_in":b.started_at.strftime("%H:%M:%S"),"break_out":b.ended_at.strftime("%H:%M:%S") if b.ended_at else None,"duration_seconds":int(seconds),"duration":duration(seconds)})
        online = d == now.date() and any(s.ended_at is None for s in sessions)
        on_break = online and any(b.ended_at is None for b in breaks)
        first = sessions[0].started_at.strftime("%H:%M:%S") if sessions else rows[0].login_time
        last = max((s.ended_at for s in sessions if s.ended_at),default=None)
        net = max(0,int(gross-break_seconds))
        locations = db.scalars(select(AttendanceLocation).where(AttendanceLocation.attendance_id.in_(ids)).order_by(AttendanceLocation.captured_at)).all()
        latest_location = locations[-1] if locations else None
        result.append({"id":rows[0].id,"intern_id":iid,"intern_code":intern.intern_code if intern else None,"name":intern.name if intern else "Intern","date":str(d),"attendance_date":str(d),"check_in":first or "-","check_out":"-" if online else (last.strftime("%H:%M:%S") if last else rows[-1].logout_time or "-"),"login_time":first,"logout_time":None if online else (last.strftime("%H:%M:%S") if last else rows[-1].logout_time),"status":"On break" if on_break else "Online" if online else rows[-1].status if rows[-1].status not in ("Online",) else "Present","is_online":online,"on_break":on_break,"session_count":len(sessions),"check_in_count":len(sessions),"check_out_count":sum(1 for s in sessions if s.ended_at is not None),"working_seconds":net,"working_minutes":net//60,"working_hours":duration(net),"working_time":duration(net),"break_seconds":int(break_seconds),"break_total":duration(break_seconds),"breaks":break_items,"gps": [{"captured_at": x.captured_at.isoformat(), "latitude": x.latitude, "longitude": x.longitude, "accuracy_meters": x.accuracy_meters, "distance_from_start_meters": x.distance_from_start_meters, "distance_from_previous_meters": x.distance_from_previous_meters} for x in locations],"gps_start": {"latitude": locations[0].latitude, "longitude": locations[0].longitude} if locations else None,"gps_current": {"latitude": latest_location.latitude, "longitude": latest_location.longitude, "accuracy_meters": latest_location.accuracy_meters, "distance_from_start_meters": latest_location.distance_from_start_meters} if latest_location else None})
    return result


def force_checkout_inactive(db, timeout_seconds=60):
    """Close sessions whose browser heartbeat stopped (sleep, shutdown, crash, or lost page)."""
    now = now_ist()
    cutoff = now - timedelta(seconds=timeout_seconds)
    active_sessions = db.scalars(
        select(WorkSession).where(WorkSession.ended_at.is_(None))
    ).all()
    changed = []
    pending_email_jobs = []
    for session in active_sessions:
        last_seen = session.last_heartbeat_at or session.started_at
        if last_seen > cutoff:
            continue
        attendance = db.get(Attendance, session.attendance_id)
        if not attendance:
            continue
        # Close every open session/break for the same attendance day.
        open_sessions = db.scalars(select(WorkSession).where(
            WorkSession.attendance_id == attendance.id,
            WorkSession.ended_at.is_(None)
        )).all()
        for item in open_sessions:
            item.ended_at = last_seen
            item.forced_checkout = True
            item.checkout_reason = "device_sleep_or_shutdown"
        for br in db.scalars(select(AttendanceBreak).where(
            AttendanceBreak.attendance_id == attendance.id,
            AttendanceBreak.ended_at.is_(None)
        )).all():
            br.ended_at = last_seen
        attendance.logout_time = last_seen.strftime("%H:%M:%S")
        attendance.status = "Forced checkout"
        intern = db.get(Intern, attendance.intern_id)
        if intern and intern.user_id:
            user = db.get(User, intern.user_id)
            if user:
                user.attendance_enabled = False
                email_to = user.email
                email_name = user.name
                checkout_time = last_seen.strftime('%d-%m-%Y %H:%M:%S')
                # Include the last known GPS fix so the intern can identify the event.
                gps = db.scalars(select(AttendanceLocation).where(
                    AttendanceLocation.attendance_id == attendance.id
                ).order_by(AttendanceLocation.captured_at.desc())).first()
                latitude = gps.latitude if gps else None
                longitude = gps.longitude if gps else None
                map_url = f"https://www.google.com/maps?q={latitude},{longitude}" if gps else None
                start_session = db.scalars(select(WorkSession).where(
                    WorkSession.attendance_id == attendance.id
                ).order_by(WorkSession.started_at.asc())).first()
                start_time = start_session.started_at.strftime('%d-%m-%Y %H:%M:%S') if start_session else 'Not recorded'
                reason = 'Connection lost / portal disconnected (possible sleep or shutdown)'
                email_body = (
                    f"Hello {email_name},\n\n"
                    f"Nexzibyte Attendance detected that your active session stopped sending its heartbeat. "
                    f"This may happen if internet is lost, the attendance tab is closed, or the device sleeps/shuts down. "
                    f"Switching browser tabs alone is not treated as a violation.\n\n"
                    f"ATTENDANCE SESSION DETAILS\nIntern name: {email_name}\nIntern ID: {intern.intern_code or intern.id}\n"
                    f"Date: {attendance.attendance_date}\nSession start: {start_time} IST\n"
                    f"Last connection / estimated checkout: {checkout_time} IST\nStatus: {reason}\n"
                    + (f"Last GPS latitude: {latitude}\nLast GPS longitude: {longitude}\nMap: {map_url}\n" if gps else "Last GPS location: No GPS fix was recorded for this session.\n")
                    + "\nYour attendance access has been paused for verification. Reopen the Intern Portal and submit a reason for reactivation. An administrator must approve the request before attendance is enabled again.\n\nRegards,\nNexzibyte Attendance Team"
                )
                pending_email_jobs.append((email_to, email_body, 'Attendance Alert - Connection Lost'))
                changed.append(intern.id)
    if changed:
        db.commit()
        for to_email, body, subject in pending_email_jobs:
            email_executor.submit(deliver_checkout_email, to_email, body, subject)
    return changed
