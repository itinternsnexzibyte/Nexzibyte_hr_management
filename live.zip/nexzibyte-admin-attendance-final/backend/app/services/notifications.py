from sqlalchemy import select
from ..models import Intern, Notification

def notify(db, intern_ids, title, message, kind, link):
    for iid in set(intern_ids):
        db.add(Notification(intern_id=iid,title=title,message=message,kind=kind,link=link))

def recipients(db, intern_id=None):
    if intern_id is not None:
        return [intern_id]
    return list(db.scalars(select(Intern.id).where(Intern.status == "Active")))
