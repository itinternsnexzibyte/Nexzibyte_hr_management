from datetime import date, datetime
from sqlalchemy import Date, DateTime, ForeignKey, Integer, String, Float, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base


class Attendance(Base):
    __tablename__ = "attendance"

    id: Mapped[int] = mapped_column(primary_key=True)
    intern_id: Mapped[int] = mapped_column(ForeignKey("interns.id"), index=True)
    attendance_date: Mapped[date] = mapped_column(Date, index=True)
    login_time: Mapped[str | None] = mapped_column(String(20), nullable=True)
    logout_time: Mapped[str | None] = mapped_column(String(20), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="Present")
    working_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    intern: Mapped["Intern"] = relationship(back_populates="attendance")


class AttendanceLocation(Base):
    __tablename__ = "attendance_locations"

    id: Mapped[int] = mapped_column(primary_key=True)
    attendance_id: Mapped[int] = mapped_column(ForeignKey("attendance.id", ondelete="CASCADE"), index=True)
    captured_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    accuracy_meters: Mapped[float | None] = mapped_column(Float, nullable=True)
    distance_from_start_meters: Mapped[float] = mapped_column(Float, default=0)
    distance_from_previous_meters: Mapped[float] = mapped_column(Float, default=0)
    label: Mapped[str | None] = mapped_column(String(255), nullable=True)
