from datetime import date, datetime, time

from sqlalchemy import Date, DateTime, Integer, String, Text, Time
from sqlalchemy.orm import Mapped, mapped_column

from ..database import Base


# =========================================================
# EMPLOYEE
# =========================================================

class Employee(Base):
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    employee_id: Mapped[str] = mapped_column(
        String(30),
        unique=True,
        index=True
    )

    name: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True
    )

    email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    phone: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True
    )

    role: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True
    )

    department: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True
    )

    joining_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )


# =========================================================
# US CLIENT
# =========================================================

class USClient(Base):
    __tablename__ = "us_clients"

    # -----------------------------------------------------
    # BASIC DETAILS
    # -----------------------------------------------------

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    client_name: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True
    )

    # -----------------------------------------------------
    # CLIENT PHOTO
    # -----------------------------------------------------

    photo_original_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    photo_stored_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    photo_content_type: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    photo_size_bytes: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    # -----------------------------------------------------
    # AADHAAR CARD
    # -----------------------------------------------------

    aadhar_original_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    aadhar_stored_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    aadhar_content_type: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    aadhar_size_bytes: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    # -----------------------------------------------------
    # PHONE
    # -----------------------------------------------------

    phone_country_code: Mapped[str | None] = mapped_column(
        String(10),
        nullable=True
    )

    phone_number: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True
    )

    # -----------------------------------------------------
    # LOCATION
    # -----------------------------------------------------

    country: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    state_region: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True
    )

    city: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True
    )

    address: Mapped[str | None] = mapped_column(
        Text,
        nullable=True
    )

    # -----------------------------------------------------
    # AVAILABILITY
    # -----------------------------------------------------

    availability: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
        default="Available"
    )

    available_from: Mapped[time | None] = mapped_column(
        Time,
        nullable=True
    )

    available_to: Mapped[time | None] = mapped_column(
        Time,
        nullable=True
    )

    # -----------------------------------------------------
    # REFERENCE EMAIL
    # -----------------------------------------------------

    reference_email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    # -----------------------------------------------------
    # MOU AGREEMENT
    # -----------------------------------------------------

    mou_original_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    mou_stored_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True
    )

    mou_content_type: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True
    )

    mou_size_bytes: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True
    )

    # -----------------------------------------------------
    # NOTES
    # -----------------------------------------------------

    notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True
    )

    # -----------------------------------------------------
    # TIMESTAMPS
    # -----------------------------------------------------

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

