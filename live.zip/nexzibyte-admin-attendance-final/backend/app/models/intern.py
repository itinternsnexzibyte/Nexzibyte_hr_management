from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base


class Intern(Base):
    __tablename__ = "interns"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"),
        unique=True,
        nullable=True,
    )

    intern_code: Mapped[str | None] = mapped_column(
        String(20),
        unique=True,
        nullable=True,
        index=True,
    )

    name: Mapped[str] = mapped_column(
        String(150),
        index=True,
    )

    email: Mapped[str] = mapped_column(
        String(255),
        index=True,
    )

    teams_id: Mapped[str | None] = mapped_column(String(150), nullable=True)

    phone: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    college: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True,
    )

    course: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True,
    )

    internship_role: Mapped[str] = mapped_column(
        String(150),
        default="Full Stack Developer",
    )

    joining_date: Mapped[date] = mapped_column(
        Date
    )

    duration_months: Mapped[int] = mapped_column(
        Integer,
        default=5,
    )

    status: Mapped[str] = mapped_column(
        String(30),
        default="Active",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    user: Mapped["User | None"] = relationship(
        back_populates="intern"
    )

    documents: Mapped[list["InternDocument"]] = relationship(
        back_populates="intern",
        cascade="all, delete-orphan",
    )

    attendance: Mapped[list["Attendance"]] = relationship(
        back_populates="intern",
        cascade="all, delete-orphan",
    )

    assignments: Mapped[list["Assignment"]] = relationship(
        back_populates="intern",
        cascade="all, delete-orphan",
    )

    ratings: Mapped[list["AssignmentRating"]] = relationship(
        back_populates="intern",
        cascade="all, delete-orphan",
    )


class InternDocument(Base):
    __tablename__ = "intern_documents"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    intern_id: Mapped[int] = mapped_column(
        ForeignKey("interns.id"),
        index=True,
    )

    document_type: Mapped[str] = mapped_column(
        String(50),
        default="offer_letter",
    )

    original_name: Mapped[str] = mapped_column(
        String(255)
    )

    stored_name: Mapped[str] = mapped_column(
        String(255),
        unique=True,
    )

    content_type: Mapped[str] = mapped_column(
        String(100)
    )

    size_bytes: Mapped[int] = mapped_column(
        Integer
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    intern: Mapped["Intern"] = relationship(
        back_populates="documents"
    )