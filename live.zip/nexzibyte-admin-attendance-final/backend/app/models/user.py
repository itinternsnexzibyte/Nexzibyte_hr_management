from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    name: Mapped[str] = mapped_column(
        String(150)
    )

    email: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        index=True,
    )

    password_hash: Mapped[str] = mapped_column(
        String(255)
    )

    role: Mapped[str] = mapped_column(
        String(20),
        default="student",
        index=True,
    )

    approval_status: Mapped[str] = mapped_column(
        String(20),
        default="pending",
        index=True,
    )

    is_verified: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    attendance_enabled: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    offer_original_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    offer_stored_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    offer_content_type: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    offer_size_bytes: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    intern: Mapped["Intern | None"] = relationship(
        back_populates="user",
        uselist=False,
    )


class RegistrationOTP(Base):
    __tablename__ = "registration_otps"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    email: Mapped[str] = mapped_column(
        String(255),
        index=True,
    )

    otp_hash: Mapped[str] = mapped_column(
        String(255)
    )

    expires_at: Mapped[datetime] = mapped_column(
        DateTime
    )

    verified: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    used: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    attempts: Mapped[int] = mapped_column(
        Integer,
        default=0,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )