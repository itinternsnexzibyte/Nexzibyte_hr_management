import logging
import smtplib
from pathlib import Path
from email.mime.image import MIMEImage
from email.message import EmailMessage

from .config import settings

logger = logging.getLogger(__name__)


def send_email(
    to_email: str,
    subject: str,
    body: str,
    attachments: list[tuple[str, str, bytes]] | None = None,
) -> None:

    # Never report a notification as sent when SMTP is missing.
    if not settings.email_host or not settings.email_from:
        raise RuntimeError("SMTP is not configured. Set EMAIL_HOST, EMAIL_PORT, EMAIL_USERNAME, EMAIL_PASSWORD, EMAIL_FROM and EMAIL_USE_TLS in backend/.env.")

    # ---------------------------------------------------------
    # REAL EMAIL
    # ---------------------------------------------------------

    msg = EmailMessage()

    msg["From"] = settings.email_from
    msg["To"] = to_email
    msg["Subject"] = subject

    msg.set_content(body)
    # Branded HTML alternative; attach the supplied Nexzibyte logo inline when available.
    logo_path = Path(__file__).resolve().parents[2] / "frontend" / "images" / "nexzibyte_solutions_logo.png"
    logo_path = logo_path.resolve()
    html_body = """<!doctype html><html><body style="margin:0;background:#f4f6fb;font-family:Arial,sans-serif;color:#172554"><div style="max-width:760px;margin:24px auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden"><div style="padding:18px 24px;background:#fff;text-align:center"><img src="cid:nexzibyte-logo" alt="Nexzibyte Solutions Pvt Ltd" style="width:100%;max-width:680px;height:auto;display:block;margin:auto"></div><div style="padding:24px 28px;line-height:1.65;white-space:pre-line">""" + body.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + """</div><div style="padding:14px 24px;background:#f8fafc;color:#64748b;font-size:12px">Automated notification · Nexzibyte Attendance Team</div></div></body></html>"""
    msg.add_alternative(html_body, subtype="html")
    try:
        if logo_path.is_file():
            image_part = MIMEImage(logo_path.read_bytes())
            image_part.add_header("Content-ID", "<nexzibyte-logo>")
            image_part.add_header("Content-Disposition", "inline", filename=logo_path.name)
            msg.get_payload()[-1].add_related(image_part)
    except Exception:
        logger.exception("Could not attach Nexzibyte email logo")

    for filename, mimetype, payload in (attachments or []):
        maintype, _, subtype = mimetype.partition("/")
        msg.add_attachment(payload, maintype=maintype or "application", subtype=subtype or "octet-stream", filename=filename)

    with smtplib.SMTP(
        settings.email_host,
        settings.email_port,
        timeout=15
    ) as smtp:

        if settings.email_use_tls:
            smtp.starttls()

        if settings.email_username:
            smtp.login(
                settings.email_username,
                settings.email_password
            )

        smtp.send_message(msg)

