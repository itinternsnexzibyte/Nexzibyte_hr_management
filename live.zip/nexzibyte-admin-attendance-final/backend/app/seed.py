from pathlib import Path
from datetime import date

from sqlalchemy import select

from .database import Base, SessionLocal, engine
from .config import settings
from .file_service import BASE_STORAGE
from .models import User, Intern, Employee, USClient, InternDocument
from .security import hash_password


Base.metadata.create_all(bind=engine)

INTERNS = [
    ("Amarapu Radhakrishna", "07/09/2026", "Full Stack Developer", 5, "RADHA_OFFER_LETTER.pdf"),
    ("Macha Prashanth", "07/09/2026", "Full Stack Developer", 5, "PRASHANTH_OFFER_LETTER.pdf"),
    ("Mohammed Anas", "07/09/2026", "Full Stack Developer", 5, "ANAS_OFFER_LETTER.pdf"),
    ("Mareedu Yaswanth Babu", "07/09/2026", "Full Stack Developer", 5, "YASWANTH_OFFER_LETTER.pdf"),
]


def parse_date(value: str) -> date:
    d, m, y = value.split("/")
    return date(int(y), int(m), int(d))


def main():
    db = SessionLocal()
    try:
        if not settings.admin_email or not settings.admin_initial_password:
            print("Set ADMIN_EMAIL and ADMIN_INITIAL_PASSWORD in backend/.env before seeding.")
            return

        admin = db.scalar(select(User).where(User.email == settings.admin_email.lower()))
        if not admin:
            admin = User(
                name="Nexzibyte Admin",
                email=settings.admin_email.lower(),
                password_hash=hash_password(settings.admin_initial_password),
                role="admin",
                is_verified=True,
            )
            db.add(admin)

        for name, joining, role, months, pdf_name in INTERNS:
            intern = db.scalar(select(Intern).where(Intern.name == name))
            if not intern:
                intern = Intern(
                    name=name,
                    email=f"{name.lower().replace(' ', '.')}@pending.local",
                    internship_role=role,
                    joining_date=parse_date(joining),
                    duration_months=months,
                    status="Active",
                )
                db.add(intern)
                db.flush()

            source = Path(__file__).resolve().parents[2] / "seed_data" / pdf_name
            destination = BASE_STORAGE / pdf_name
            if source.exists() and not destination.exists():
                destination.write_bytes(source.read_bytes())

            existing_doc = db.scalar(select(InternDocument).where(
                InternDocument.intern_id == intern.id,
                InternDocument.document_type == "offer_letter",
            ))
            if source.exists() and not existing_doc:
                existing_doc = InternDocument(
                    intern_id=intern.id,
                    document_type="offer_letter",
                    original_name=pdf_name,
                    stored_name=pdf_name,
                    content_type="application/pdf",
                    size_bytes=destination.stat().st_size,
                )
                db.add(existing_doc)

        for emp_id in ["003", "004", "005", "006", "007", "008"]:
            if not db.scalar(select(Employee).where(Employee.employee_id == emp_id)):
                db.add(Employee(employee_id=emp_id))

        for slot in [1, 2]:
            if not db.scalar(select(USClient).where(USClient.id == slot)):
                db.add(USClient(id=slot))

        db.commit()
        print("Seed completed.")
    finally:
        db.close()


if __name__ == "__main__":
    main()