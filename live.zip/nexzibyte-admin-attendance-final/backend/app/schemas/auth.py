from pydantic import BaseModel, ConfigDict, EmailStr, Field


class RegisterIn(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=150
    )

    email: EmailStr

    password: str = Field(
        min_length=8,
        max_length=128
    )

    confirm_password: str = Field(
        min_length=8,
        max_length=128
    )


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ForgotPasswordIn(BaseModel):
    email: EmailStr


class ResetPasswordIn(BaseModel):
    token: str

    password: str = Field(
        min_length=8,
        max_length=128
    )

    confirm_password: str = Field(
        min_length=8,
        max_length=128
    )


class SetPasswordIn(BaseModel):
    token: str

    password: str = Field(
        min_length=8,
        max_length=128
    )

    confirm_password: str = Field(
        min_length=8,
        max_length=128
    )


class UserOut(BaseModel):
    id: int

    name: str = Field(
        min_length=2,
        max_length=150
    )

    email: EmailStr

    role: str

    approval_status: str

    is_verified: bool

    model_config = ConfigDict(
        from_attributes=True
    )


class TokenOut(BaseModel):
    access_token: str

    token_type: str

    user: UserOut