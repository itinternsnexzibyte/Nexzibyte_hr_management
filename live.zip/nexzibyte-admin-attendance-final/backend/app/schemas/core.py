from datetime import date

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(
        from_attributes=True
    )


# =========================================================
# INTERN
# =========================================================

class InternCreate(BaseModel):
    # Admin enters this manually.
    # Example: 00114
    intern_code: str = Field(
        min_length=1,
        max_length=20
    )

    name: str

    email: str

    teams_id: str | None = None

    phone: str | None = None

    college: str | None = None

    course: str | None = None

    internship_role: str = "Full Stack Developer"

    joining_date: date

    duration_months: int = Field(
        default=5,
        ge=1,
        le=60
    )

    status: str = "Active"


class InternOut(ORM):
    id: int

    user_id: int | None

    intern_code: str | None

    name: str

    email: str

    teams_id: str | None = None

    phone: str | None

    college: str | None

    course: str | None

    internship_role: str

    joining_date: date

    duration_months: int

    status: str


# =========================================================
# ATTENDANCE
# =========================================================

class AttendanceIn(BaseModel):
    intern_id: int

    attendance_date: date

    login_time: str | None = None

    logout_time: str | None = None

    status: str = "Present"

    working_minutes: int | None = Field(
        default=None,
        ge=0
    )


class AttendanceOut(ORM):
    id: int

    intern_id: int

    attendance_date: date

    login_time: str | None

    logout_time: str | None

    status: str

    working_minutes: int | None


# =========================================================
# ASSIGNMENTS
# =========================================================

class AssignmentIn(BaseModel):
    intern_id: int

    title: str

    description: str | None = None

    due_date: date | None = None

    status: str = "Assigned"


class AssignmentOut(ORM):
    id: int

    intern_id: int

    title: str

    description: str | None

    due_date: date | None

    status: str


# =========================================================
# SUBMISSION
# =========================================================

class SubmissionIn(BaseModel):
    submission_text: str | None = None

    submission_url: str | None = None

# =========================================================
# RATING
# =========================================================

class RatingIn(BaseModel):
    intern_id: int | None = None
    student_id: int | None = None
    rating: int = Field(
        ge=1,
        le=10
    )
    feedback: str | None = None
    rating_date: date


class RatingOut(ORM):
    id: int
    intern_id: int
    rating: int
    feedback: str | None
    rating_date: date

# =========================================================
# EMPLOYEE
# =========================================================

class EmployeeIn(BaseModel):
    employee_id: str

    name: str | None = None

    email: str | None = None

    phone: str | None = None

    role: str | None = None

    department: str | None = None

    joining_date: date | None = None


class EmployeeOut(ORM):
    id: int

    employee_id: str

    name: str | None

    email: str | None

    phone: str | None

    role: str | None

    department: str | None

    joining_date: date | None


# =========================================================
# US CLIENT
# =========================================================

class ClientIn(BaseModel):
    client_name: str

