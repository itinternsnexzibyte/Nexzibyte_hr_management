print("========== NEXZIBYTE INTERNS.PY LOADED ==========")

from datetime import timedelta, timezone, datetime

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    UploadFile,
)

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..email_service import send_email
from ..file_service import delete_stored, save_upload

from ..models import (
    EmailVerificationToken,
    PasswordResetToken,
    Intern,
    InternDocument,
    User,
)

from ..schemas.core import InternCreate, InternOut

from ..security import (
    generate_raw_token,
    hash_password,
    token_hash,
)


router = APIRouter(
    prefix="/api/interns",
    tags=["Interns"],
)


# =========================================================
# LIST INTERNS
# =========================================================

@router.get(
    "",
    response_model=list[InternOut],
)
def list_interns(
    search: str | None = Query(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    stmt = select(
        Intern
    ).order_by(
        Intern.id
    )

    # -----------------------------------------------------
    # INTERN CAN SEE ONLY OWN RECORD
    # -----------------------------------------------------

    if user.role == "student":
        stmt = stmt.where(
            Intern.user_id == user.id
        )

    # -----------------------------------------------------
    # ADMIN CAN SEE ALL
    # -----------------------------------------------------

    elif user.role == "admin" and search:

        q = f"%{search.strip()}%"

        stmt = stmt.where(
            or_(
                Intern.intern_code.ilike(q),
                Intern.name.ilike(q),
                Intern.email.ilike(q),
                Intern.internship_role.ilike(q),
            )
        )

    return list(
        db.scalars(stmt).all()
    )


# =========================================================
# GET MY INTERN DETAILS
# =========================================================

@router.get(
    "/me",
    response_model=InternOut,
)
def get_my_intern(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role != "student":
        raise HTTPException(
            status_code=403,
            detail="This endpoint is only for intern accounts",
        )

    intern = db.scalar(
        select(Intern).where(
            Intern.user_id == user.id
        )
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Your intern details have not been created yet",
        )

    return intern


# =========================================================
# CREATE MY INTERN DETAILS
# =========================================================

@router.post(
    "/me",
    response_model=InternOut,
)
def create_my_intern(
    data: InternCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role != "student":
        raise HTTPException(
            status_code=403,
            detail="Only intern accounts can use this endpoint",
        )

    # -----------------------------------------------------
    # CHECK IF THIS USER ALREADY HAS AN INTERN RECORD
    # -----------------------------------------------------

    existing_own_record = db.scalar(
        select(Intern).where(
            Intern.user_id == user.id
        )
    )

    if existing_own_record:
        raise HTTPException(
            status_code=409,
            detail="Your intern details already exist",
        )

    intern_code = data.intern_code.strip()

    if not intern_code:
        raise HTTPException(
            status_code=400,
            detail="Intern ID is required",
        )

    # -----------------------------------------------------
    # CHECK DUPLICATE INTERN ID
    # -----------------------------------------------------

    existing_code = db.scalar(
        select(Intern).where(
            Intern.intern_code == intern_code
        )
    )

    if existing_code:

        # -------------------------------------------------
        # EXISTING PRELOADED INTERN
        #
        # If the existing record has no user account linked,
        # attach it to this approved intern account instead
        # of creating a duplicate.
        # -------------------------------------------------

        if existing_code.user_id is None:

            existing_code.user_id = user.id
            existing_code.name = user.name
            existing_code.email = user.email

            existing_code.phone = data.phone
            existing_code.college = data.college
            existing_code.course = data.course

            db.commit()
            db.refresh(existing_code)

            return existing_code

        raise HTTPException(
            status_code=409,
            detail=(
                f"Intern ID '{intern_code}' "
                f"is already assigned"
            ),
        )

    # -----------------------------------------------------
    # CHECK EMAIL
    # -----------------------------------------------------

    existing_email = db.scalar(
        select(Intern).where(
            Intern.email == user.email
        )
    )

    if existing_email:

        if existing_email.user_id is None:

            existing_email.user_id = user.id
            existing_email.name = user.name

            existing_email.phone = data.phone
            existing_email.college = data.college
            existing_email.course = data.course

            db.commit()
            db.refresh(existing_email)

            return existing_email

        raise HTTPException(
            status_code=409,
            detail="An intern with this email already exists",
        )

    # -----------------------------------------------------
    # CREATE NEW INTERN RECORD
    # -----------------------------------------------------

    intern = Intern(
        user_id=user.id,
        intern_code=intern_code,
        name=user.name,
        email=user.email,
        teams_id=data.teams_id,
        phone=data.phone,
        college=data.college,
        course=data.course,
        internship_role=data.internship_role,
        joining_date=data.joining_date,
        duration_months=data.duration_months,
        status=data.status,
    )

    db.add(intern)

    db.commit()
    db.refresh(intern)

    return intern


# =========================================================
# UPDATE MY INTERN DETAILS
# =========================================================

@router.put(
    "/me",
    response_model=InternOut,
)
def update_my_intern(
    data: InternCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role != "student":
        raise HTTPException(
            status_code=403,
            detail="Only intern accounts can use this endpoint",
        )

    intern = db.scalar(
        select(Intern).where(
            Intern.user_id == user.id
        )
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Your intern details have not been created yet",
        )

    new_code = data.intern_code.strip()

    if not new_code:
        raise HTTPException(
            status_code=400,
            detail="Intern ID is required",
        )

    # -----------------------------------------------------
    # DUPLICATE INTERN ID CHECK
    # -----------------------------------------------------

    existing_code = db.scalar(
        select(Intern).where(
            Intern.intern_code == new_code,
            Intern.id != intern.id,
        )
    )

    if existing_code:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Intern ID '{new_code}' "
                f"is already assigned"
            ),
        )

    # -----------------------------------------------------
    # UPDATE OWN DETAILS
    # -----------------------------------------------------

    intern.intern_code = new_code

    # The logged-in account remains the owner.
    intern.name = data.name.strip() or user.name
    intern.email = user.email
    intern.teams_id = data.teams_id

    intern.phone = data.phone
    intern.college = data.college
    intern.course = data.course

    intern.internship_role = data.internship_role
    intern.joining_date = data.joining_date
    intern.duration_months = data.duration_months
    intern.status = data.status

    # Keep login identity synchronized with the intern name.
    user.name = intern.name

    db.commit()
    db.refresh(intern)

    return intern


# =========================================================
# GET SINGLE INTERN
# =========================================================

@router.get(
    "/{intern_id}",
    response_model=InternOut,
)
def get_intern(
    intern_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    intern = db.get(
        Intern,
        intern_id,
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found",
        )

    # -----------------------------------------------------
    # INTERN CAN ONLY ACCESS OWN RECORD
    # -----------------------------------------------------

    if (
        user.role == "student"
        and intern.user_id != user.id
    ):
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    return intern


# =========================================================
# CREATE INTERN - ADMIN ONLY
# =========================================================

@router.post(
    "",
    response_model=InternOut,
)
def create_intern(
    data: InternCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    print("CREATE INTERN FUNCTION IS RUNNING")

    intern_code = data.intern_code.strip()
    email = data.email.lower().strip()
    name = data.name.strip()

    if not intern_code:
        raise HTTPException(
            status_code=400,
            detail="Intern ID is required",
        )

    existing_code = db.scalar(
        select(Intern).where(
            Intern.intern_code == intern_code
        )
    )

    if existing_code:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Intern ID '{intern_code}' "
                f"is already assigned"
            ),
        )

    existing_intern = db.scalar(
        select(Intern).where(
            Intern.email == email
        )
    )

    if existing_intern:
        raise HTTPException(
            status_code=409,
            detail=(
                "An intern with this email "
                "already exists"
            ),
        )

    existing_user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if existing_user:
        raise HTTPException(
            status_code=409,
            detail=(
                "A user account with this email "
                "already exists"
            ),
        )

    temporary_password = generate_raw_token()

    user = User(
        name=name,
        email=email,
        password_hash=hash_password(
            temporary_password
        ),
        role="student",
        approval_status="pending",
        is_verified=False,
        is_active=True,
    )

    db.add(user)
    db.flush()

    intern = Intern(
        user_id=user.id,
        intern_code=intern_code,
        name=name,
        email=email,
        teams_id=data.teams_id,
        phone=data.phone,
        college=data.college,
        course=data.course,
        internship_role=data.internship_role,
        joining_date=data.joining_date,
        duration_months=data.duration_months,
        status=data.status,
    )

    db.add(intern)
    db.flush()

    raw_token = generate_raw_token()

    verification_token = EmailVerificationToken(
        user_id=user.id,
        token_hash=token_hash(raw_token),
        expires_at=(
            datetime.now(
                timezone.utc
            ).replace(
                tzinfo=None
            )
            + timedelta(hours=24)
        ),
        used=False,
    )

    db.add(verification_token)

    db.commit()
    db.refresh(intern)

    verification_url = (
        f"{settings.frontend_url}"
        f"/verify.html?token={raw_token}"
    )

    email_body = (
        f"Hello {user.name},\n\n"
        f"You have been invited to join Nexzibyte "
        f"as an intern.\n\n"
        f"Intern ID: {intern.intern_code}\n"
        f"Internship Role: {intern.internship_role}\n"
        f"Joining Date: {intern.joining_date}\n"
        f"Duration: {intern.duration_months} months\n\n"
        f"Please verify your email using the link below:\n\n"
        f"{verification_url}\n\n"
        f"This verification link expires in 24 hours.\n\n"
        f"Regards,\n"
        f"Nexzibyte Solutions"
    )

    send_email(
        email,
        "Nexzibyte Internship Account Verification",
        email_body,
    )

    return intern


# =========================================================
# UPDATE INTERN - ADMIN ONLY
# =========================================================

@router.put(
    "/{intern_id}",
    response_model=InternOut,
)
def update_intern(
    intern_id: int,
    data: InternCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    intern = db.get(
        Intern,
        intern_id,
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found",
        )

    new_code = data.intern_code.strip()
    new_email = data.email.lower().strip()
    new_name = data.name.strip()

    if not new_code:
        raise HTTPException(
            status_code=400,
            detail="Intern ID is required",
        )

    existing_code = db.scalar(
        select(Intern).where(
            Intern.intern_code == new_code,
            Intern.id != intern_id,
        )
    )

    if existing_code:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Intern ID '{new_code}' "
                f"is already assigned"
            ),
        )

    existing_intern = db.scalar(
        select(Intern).where(
            Intern.email == new_email,
            Intern.id != intern_id,
        )
    )

    if existing_intern:
        raise HTTPException(
            status_code=409,
            detail=(
                "Another intern already uses "
                "this email"
            ),
        )

    intern.intern_code = new_code
    intern.name = new_name
    intern.email = new_email
    intern.teams_id = data.teams_id
    intern.phone = data.phone
    intern.college = data.college
    intern.course = data.course
    intern.internship_role = data.internship_role
    intern.joining_date = data.joining_date
    intern.duration_months = data.duration_months
    intern.status = data.status

    if intern.user_id:

        linked_user = db.get(
            User,
            intern.user_id,
        )

        if linked_user:
            linked_user.name = intern.name
            linked_user.email = new_email

    db.commit()
    db.refresh(intern)

    return intern


# =========================================================
# DELETE INTERN - ADMIN ONLY
# =========================================================

@router.delete(
    "/{intern_id}",
)
def delete_intern(
    intern_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    print(
        f"DELETE INTERN REQUEST: {intern_id}"
    )

    intern = db.get(
        Intern,
        intern_id,
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found",
        )

    linked_user = None

    if intern.user_id:
        linked_user = db.get(
            User,
            intern.user_id,
        )

    for document in list(
        intern.documents
    ):
        try:
            delete_stored(
                document.stored_name
            )
        except Exception as error:
            print(
                "Document deletion warning:",
                error,
            )

    if linked_user:

        db.query(
            EmailVerificationToken
        ).filter(
            EmailVerificationToken.user_id
            == linked_user.id
        ).delete(
            synchronize_session=False
        )

        db.query(
            PasswordResetToken
        ).filter(
            PasswordResetToken.user_id
            == linked_user.id
        ).delete(
            synchronize_session=False
        )

    db.delete(intern)

    if linked_user:
        db.delete(linked_user)

    try:
        db.commit()

    except Exception as error:

        db.rollback()

        print(
            "=" * 70
        )
        print(
            "DELETE INTERN ERROR"
        )
        print(
            error
        )
        print(
            "=" * 70
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "Unable to delete intern. "
                "Check the backend terminal."
            ),
        )

    return {
        "message": "Intern deleted"
    }


# =========================================================
# UPLOAD OFFER LETTER - ADMIN ONLY
# =========================================================

@router.post(
    "/{intern_id}/offer-letter",
)
async def upload_offer_letter(
    intern_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    intern = db.get(
        Intern,
        intern_id,
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found",
        )

    stored, content_type, size = (
        await save_upload(file)
    )

    old = db.scalar(
        select(InternDocument).where(
            InternDocument.intern_id == intern_id,
            InternDocument.document_type == "offer_letter",
        )
    )

    if old:

        try:
            delete_stored(
                old.stored_name
            )
        except Exception as error:
            print(
                "Old document deletion warning:",
                error,
            )

        db.delete(old)
        db.flush()

    document = InternDocument(
        intern_id=intern_id,
        document_type="offer_letter",
        original_name=(
            file.filename or "offer-letter"
        ),
        stored_name=stored,
        content_type=content_type,
        size_bytes=size,
    )

    db.add(document)

    db.commit()
    db.refresh(document)

    return {
        "message": "Offer letter uploaded",
        "document_id": document.id,
        "filename": document.original_name,
    }


# =========================================================
# LIST DOCUMENTS
# =========================================================

@router.get(
    "/{intern_id}/documents",
)
def list_documents(
    intern_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    intern = db.get(
        Intern,
        intern_id,
    )

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found",
        )

    if (
        user.role == "student"
        and intern.user_id != user.id
    ):
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    return [
        {
            "id": document.id,
            "filename": document.original_name,
            "type": document.document_type,
            "size": document.size_bytes,
        }
        for document in intern.documents
    ]