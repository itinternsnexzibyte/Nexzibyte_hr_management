from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import AssignmentRating, Intern, User
from ..schemas.core import RatingIn, RatingOut

router = APIRouter(prefix="/api/assignment-ratings", tags=["Daily Ratings"])


@router.get("", response_model=list[RatingOut])
def list_ratings(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    stmt = select(AssignmentRating).order_by(AssignmentRating.rating_date.desc(), AssignmentRating.id.desc())
    
    # Restrict both "student" and "intern" roles to their own ratings
    if user.role in ["student", "intern"]:
        intern = db.scalar(select(Intern).where(Intern.user_id == user.id))
        if not intern:
            return []
        stmt = stmt.where(AssignmentRating.intern_id == intern.id)
        
    return list(db.scalars(stmt).all())


@router.post("", response_model=RatingOut)
def upsert_rating(data: RatingIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    # Support both intern_id and student_id from schema
    intern_id = getattr(data, "intern_id", None) or getattr(data, "student_id", None)
    if not intern_id:
        raise HTTPException(400, "intern_id or student_id is required")

    intern = db.get(Intern, intern_id)
    if not intern:
        raise HTTPException(404, "Intern not found")

    row = db.scalar(
        select(AssignmentRating).where(
            AssignmentRating.intern_id == intern_id,
            AssignmentRating.rating_date == data.rating_date,
        )
    )
    if not row:
        row = AssignmentRating(
            intern_id=intern_id,
            rating_date=data.rating_date,
            rating=data.rating,
            feedback=data.feedback,
        )
        db.add(row)
    else:
        row.rating = data.rating
        row.feedback = data.feedback

    db.commit()
    db.refresh(row)
    return row