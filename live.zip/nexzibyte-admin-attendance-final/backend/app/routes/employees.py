from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..models import Employee, User
from ..schemas.core import EmployeeIn, EmployeeOut

router = APIRouter(prefix="/api/employees", tags=["Employees"])


@router.get("", response_model=list[EmployeeOut])
def list_employees(
    search: str | None = Query(default=None),
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    stmt = select(Employee).order_by(Employee.employee_id)
    if search:
        q = f"%{search.strip()}%"
        stmt = stmt.where(or_(Employee.employee_id.ilike(q), Employee.name.ilike(q)))
    return list(db.scalars(stmt).all())


@router.post("", response_model=EmployeeOut)
def create_employee(data: EmployeeIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    if db.scalar(select(Employee).where(Employee.employee_id == data.employee_id)):
        raise HTTPException(409, "Employee ID already exists")
    row = Employee(**data.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.put("/{employee_id}", response_model=EmployeeOut)
def update_employee(employee_id: int, data: EmployeeIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    row = db.get(Employee, employee_id)
    if not row:
        raise HTTPException(404, "Employee not found")
    for k, v in data.model_dump().items():
        setattr(row, k, v)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/{employee_id}")
def delete_employee(employee_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    row = db.get(Employee, employee_id)
    if not row:
        raise HTTPException(404, "Employee not found")
    db.delete(row)
    db.commit()
    return {"message": "Employee deleted"}
