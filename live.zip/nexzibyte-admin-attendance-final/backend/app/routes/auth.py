import secrets

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
)

from pydantic import BaseModel, EmailStr

from sqlalchemy import select

from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..email_service import send_email
from ..file_service import save_upload
IST = ZoneInfo("Asia/Kolkata")

from ..models import (
    Attendance,
    EmailVerificationToken,
    Intern,
    PasswordResetToken,
    RegistrationOTP,
    User,
)

from ..schemas.auth import (
    ForgotPasswordIn,
    LoginIn,
    ResetPasswordIn,
    SetPasswordIn,
    TokenOut,
    UserOut,
)

from ..security import (
    create_access_token,
    generate_raw_token,
    hash_password,
    token_hash,
    verify_password,
)


router = APIRouter(
    prefix="/api/auth",
    tags=["Auth"],
)


# =========================================================
# OTP REQUEST MODELS
# =========================================================

class RegistrationOTPSendIn(BaseModel):
    email: EmailStr


class RegistrationOTPVerifyIn(BaseModel):
    email: EmailStr
    otp: str


# =========================================================
# USER RESPONSE
# =========================================================

def user_out(user: User) -> UserOut:
    return UserOut.model_validate(user)


# =========================================================
# SEND REGISTRATION OTP
# =========================================================

@router.post("/send-registration-otp")
def send_registration_otp(
    data: RegistrationOTPSendIn,
    db: Session = Depends(get_db),
):
    email = str(data.email).lower().strip()

    # -----------------------------------------------------
    # CHECK WHETHER EMAIL ALREADY EXISTS
    # -----------------------------------------------------

    existing_user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if existing_user:
        raise HTTPException(
            status_code=409,
            detail="Email is already registered",
        )

    # -----------------------------------------------------
    # INVALIDATE OLD OTPs
    # -----------------------------------------------------

    old_otps = db.scalars(
        select(RegistrationOTP).where(
            RegistrationOTP.email == email,
            RegistrationOTP.used.is_(False),
        )
    ).all()

    for old_otp in old_otps:
        old_otp.used = True

    # -----------------------------------------------------
    # GENERATE 6 DIGIT OTP
    # -----------------------------------------------------

    otp = f"{secrets.randbelow(1000000):06d}"

    otp_row = RegistrationOTP(
        email=email,
        otp_hash=token_hash(otp),
        expires_at=(
            datetime.utcnow()
            + timedelta(minutes=10)
        ),
        verified=False,
        used=False,
        attempts=0,
    )

    db.add(otp_row)

    db.commit()

    # -----------------------------------------------------
    # SEND OTP EMAIL
    # -----------------------------------------------------

    send_email(
        email,
        "Nexzibyte Email Verification OTP",
        (
            f"Hello,\n\n"
            f"Your Nexzibyte registration OTP is:\n\n"
            f"{otp}\n\n"
            f"This OTP is valid for 10 minutes.\n"
            f"Do not share this OTP with anyone.\n\n"
            f"Regards,\n"
            f"Nexzibyte Solutions"
        ),
    )

    return {
        "message": "OTP sent successfully",
        "email": email,
    }
# =========================================================
# FORGOT PASSWORD OTP MODELS
# =========================================================

class ForgotPasswordOTPIn(BaseModel):
    email: EmailStr


class VerifyForgotPasswordOTPIn(BaseModel):
    email: EmailStr
    otp: str


class ResetPasswordOTPIn(BaseModel):
    email: EmailStr
    otp: str
    password: str
    confirm_password: str


# =========================================================
# VERIFY REGISTRATION OTP
# =========================================================

@router.post("/verify-registration-otp")
def verify_registration_otp(
    data: RegistrationOTPVerifyIn,
    db: Session = Depends(get_db),
):
    email = str(data.email).lower().strip()
    otp = data.otp.strip()

    # -----------------------------------------------------
    # VALIDATE OTP FORMAT
    # -----------------------------------------------------

    if not otp.isdigit():
        raise HTTPException(
            status_code=400,
            detail="OTP must contain only numbers",
        )

    if len(otp) != 6:
        raise HTTPException(
            status_code=400,
            detail="OTP must contain exactly 6 digits",
        )

    # -----------------------------------------------------
    # GET LATEST ACTIVE OTP
    # -----------------------------------------------------

    row = db.scalar(
        select(RegistrationOTP)
        .where(
            RegistrationOTP.email == email,
            RegistrationOTP.used.is_(False),
        )
        .order_by(
            RegistrationOTP.created_at.desc()
        )
    )

    if not row:
        raise HTTPException(
            status_code=400,
            detail="OTP not found. Please request a new OTP.",
        )

    # -----------------------------------------------------
    # CHECK EXPIRY
    # -----------------------------------------------------

    if row.expires_at < datetime.utcnow():

        row.used = True

        db.commit()

        raise HTTPException(
            status_code=400,
            detail="OTP has expired. Please request a new OTP.",
        )

    # -----------------------------------------------------
    # CHECK ATTEMPTS
    # -----------------------------------------------------

    if row.attempts >= 5:

        row.used = True

        db.commit()

        raise HTTPException(
            status_code=429,
            detail="Too many incorrect attempts. Please request a new OTP.",
        )

    # -----------------------------------------------------
    # VERIFY OTP
    # -----------------------------------------------------

    if token_hash(otp) != row.otp_hash:

        row.attempts += 1

        db.commit()

        raise HTTPException(
            status_code=400,
            detail="Invalid OTP",
        )

    # -----------------------------------------------------
    # MARK EMAIL AS VERIFIED
    # -----------------------------------------------------

    row.verified = True

    db.commit()

    return {
        "message": "Email verified successfully",
        "email": email,
        "verified": True,
    }


# =========================================================
# INTERN SELF REGISTRATION
# =========================================================

@router.post(
    "/register",
    response_model=UserOut,
)
async def register(
    name: str = Form(...),
    email: EmailStr = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    offer_letter: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    name = name.strip()
    email = str(email).lower().strip()

    # -----------------------------------------------------
    # VALIDATE NAME
    # -----------------------------------------------------

    if len(name) < 2:
        raise HTTPException(
            status_code=400,
            detail="Name must contain at least 2 characters",
        )

    if len(name) > 150:
        raise HTTPException(
            status_code=400,
            detail="Name cannot exceed 150 characters",
        )

    # -----------------------------------------------------
    # VALIDATE PASSWORD
    # -----------------------------------------------------

    if len(password) < 8:
        raise HTTPException(
            status_code=400,
            detail="Password must contain at least 8 characters",
        )

    if len(password) > 128:
        raise HTTPException(
            status_code=400,
            detail="Password cannot exceed 128 characters",
        )

    if password != confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Passwords do not match",
        )

    # -----------------------------------------------------
    # CHECK EMAIL OTP VERIFICATION
    # -----------------------------------------------------

    otp_row = db.scalar(
        select(RegistrationOTP)
        .where(
            RegistrationOTP.email == email,
            RegistrationOTP.verified.is_(True),
            RegistrationOTP.used.is_(False),
        )
        .order_by(
            RegistrationOTP.created_at.desc()
        )
    )

    if not otp_row:
        raise HTTPException(
            status_code=403,
            detail="Please verify your email using OTP before creating your account.",
        )

    if otp_row.expires_at < datetime.utcnow():

        otp_row.used = True

        db.commit()

        raise HTTPException(
            status_code=403,
            detail="Email verification has expired. Please request a new OTP.",
        )

    # -----------------------------------------------------
    # CHECK EXISTING USER
    # -----------------------------------------------------

    existing_user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if existing_user:
        raise HTTPException(
            status_code=409,
            detail="Email is already registered",
        )

    # -----------------------------------------------------
    # VALIDATE OFFER LETTER
    # -----------------------------------------------------

    if not offer_letter.filename:
        raise HTTPException(
            status_code=400,
            detail="Offer letter is required",
        )

    extension = (
        offer_letter.filename.rsplit(".", 1)[-1].lower()
        if "." in offer_letter.filename
        else ""
    )

    allowed_extensions = {
        "pdf",
        "jpg",
        "jpeg",
        "png",
    }

    if extension not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail="Offer letter must be PDF, JPG, JPEG, or PNG",
        )

    # -----------------------------------------------------
    # SAVE OFFER LETTER
    # -----------------------------------------------------

    stored_name, content_type, size_bytes = (
        await save_upload(
            offer_letter
        )
    )

    # -----------------------------------------------------
    # CREATE USER
    # -----------------------------------------------------

    user = User(
        name=name,
        email=email,
        password_hash=hash_password(password),
        role="student",
        approval_status="pending",
        is_verified=True,
        is_active=True,
        offer_original_name=(
            offer_letter.filename
        ),
        offer_stored_name=stored_name,
        offer_content_type=content_type,
        offer_size_bytes=size_bytes,
    )

    db.add(user)

    db.flush()

    # -----------------------------------------------------
    # CONSUME OTP
    # -----------------------------------------------------

    otp_row.used = True

    # -----------------------------------------------------
    # SAVE USER
    # -----------------------------------------------------

    db.commit()

    db.refresh(user)

    # -----------------------------------------------------
    # SEND ADMIN NOTIFICATION
    # -----------------------------------------------------

    if settings.admin_email:

        send_email(
            settings.admin_email,
            "New Intern Account Awaiting Approval",
            (
                f"A new intern account has been created.\n\n"
                f"Name: {user.name}\n"
                f"Email: {user.email}\n"
                f"Email verified: Yes\n"
                f"Approval status: Pending\n"
                f"Offer letter: {user.offer_original_name}\n\n"
                f"Please review the intern's offer letter "
                f"and approve or reject the account.\n\n"
                f"Nexzibyte Solutions"
            ),
        )

    return user_out(user)


# =========================================================
# OLD EMAIL VERIFICATION LINK
# =========================================================

@router.get("/verify")
def verify_email(
    token: str,
    db: Session = Depends(get_db),
):
    row = db.scalar(
        select(EmailVerificationToken).where(
            EmailVerificationToken.token_hash
            == token_hash(token),
            EmailVerificationToken.used.is_(False),
        )
    )

    if not row:
        raise HTTPException(
            status_code=400,
            detail="Verification link is invalid or already used",
        )

    if row.expires_at < datetime.utcnow():
        raise HTTPException(
            status_code=400,
            detail="Verification link is expired",
        )

    user = db.get(
        User,
        row.user_id,
    )

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User account not found",
        )

    return {
        "message": "Verification link is valid.",
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "approval_status": user.approval_status,
    }


# =========================================================
# OLD SET PASSWORD / VERIFICATION LINK
# =========================================================

@router.post("/set-password")
def set_password(
    data: SetPasswordIn,
    db: Session = Depends(get_db),
):
    if data.password != data.confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Passwords do not match",
        )

    row = db.scalar(
        select(EmailVerificationToken).where(
            EmailVerificationToken.token_hash
            == token_hash(data.token),
            EmailVerificationToken.used.is_(False),
        )
    )

    if not row:
        raise HTTPException(
            status_code=400,
            detail="Verification link is invalid or already used",
        )

    if row.expires_at < datetime.utcnow():
        raise HTTPException(
            status_code=400,
            detail="Verification link is expired",
        )

    user = db.get(
        User,
        row.user_id,
    )

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User account not found",
        )

    user.password_hash = hash_password(
        data.password
    )

    user.is_verified = True
    user.is_active = True
    user.approval_status = "pending"

    row.used = True

    db.commit()

    return {
        "message": (
            "Email verified successfully. "
            "Your account is waiting for admin approval."
        ),
    }


# =========================================================
# LOGIN
# =========================================================

# =========================================================
# LOGIN
# =========================================================

@router.post(
    "/login",
    response_model=TokenOut,
)
def login(
    data: LoginIn,
    db: Session = Depends(get_db),
):
    email = data.email.lower().strip()

    user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=403,
            detail="Your account is inactive",
        )

    if not user.password_hash:
        raise HTTPException(
            status_code=403,
            detail="Password is not configured",
        )

    if not verify_password(
        data.password,
        user.password_hash,
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password",
        )

    # -----------------------------------------------------
    # STUDENT EMAIL VERIFICATION
    # -----------------------------------------------------

    if (
        user.role == "student"
        and not user.is_verified
    ):
        raise HTTPException(
            status_code=403,
            detail="Please verify your email before logging in",
        )

    # -----------------------------------------------------
    # ADMIN LOGIN
    # -----------------------------------------------------

    if user.role == "admin":

        token = create_access_token(
            user.id,
            user.role,
        )

        return {
            "access_token": token,
            "token_type": "bearer",
            "user": user_out(user),
        }

    # -----------------------------------------------------
    # INTERN LOGIN
    # -----------------------------------------------------

    if user.role == "student":

        if user.approval_status == "pending":

            raise HTTPException(
                status_code=403,
                detail=(
                    "Your email is verified, but your account "
                    "is waiting for admin approval."
                ),
            )

        if user.approval_status == "rejected":

            raise HTTPException(
                status_code=403,
                detail=(
                    "Your account was rejected by the admin."
                ),
            )

        if user.approval_status != "approved":

            raise HTTPException(
                status_code=403,
                detail=(
                    "Your account is not approved for login."
                ),
            )

        # -------------------------------------------------
        # FIND LINKED INTERN
        # -------------------------------------------------

        intern = db.scalar(
            select(Intern).where(
                Intern.user_id == user.id
            )
        )

        if not intern:

            raise HTTPException(
                status_code=403,
                detail=(
                    "Your account is approved, but your "
                    "intern details are not linked yet."
                ),
            )

        from ..services.attendance import check_in
        check_in(db, intern)
        db.commit()

    # -----------------------------------------------------
    # CREATE ACCESS TOKEN
    # -----------------------------------------------------

    token = create_access_token(
        user.id,
        user.role,
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": user_out(user),
    }
# =========================================================
# FORGOT PASSWORD
# =========================================================
# =========================================================
# FORGOT PASSWORD - SEND OTP
# =========================================================

@router.post("/forgot-password")
def forgot_password(
    data: ForgotPasswordOTPIn,
    db: Session = Depends(get_db),
):
    email = str(data.email).lower().strip()

    # -----------------------------------------------------
    # FIND USER
    # -----------------------------------------------------

    user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    # -----------------------------------------------------
    # GENERIC RESPONSE FOR UNKNOWN EMAIL
    # -----------------------------------------------------

    if not user:
        return {
            "message": (
                "If the account exists, a password reset OTP "
                "has been sent."
            ),
        }

    # -----------------------------------------------------
    # INVALIDATE PREVIOUS RESET OTPs
    # -----------------------------------------------------

    old_tokens = db.scalars(
        select(PasswordResetToken).where(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.used.is_(False),
        )
    ).all()

    for old_token in old_tokens:
        old_token.used = True

    # -----------------------------------------------------
    # GENERATE 6 DIGIT OTP
    # -----------------------------------------------------

    otp = f"{secrets.randbelow(1000000):06d}"

    reset_token = PasswordResetToken(
        user_id=user.id,
        token_hash=token_hash(otp),
        expires_at=(
            datetime.utcnow()
            + timedelta(minutes=10)
        ),
        used=False,
    )

    db.add(reset_token)

    db.commit()

    # -----------------------------------------------------
    # SEND OTP EMAIL
    # -----------------------------------------------------

    send_email(
        user.email,
        "Nexzibyte Password Reset OTP",
        (
            f"Hello {user.name},\n\n"
            f"Your Nexzibyte password reset OTP is:\n\n"
            f"{otp}\n\n"
            f"This OTP is valid for 10 minutes.\n"
            f"Do not share this OTP with anyone.\n\n"
            f"Regards,\n"
            f"Nexzibyte Solutions"
        ),
    )

    return {
        "message": (
            "If the account exists, a password reset OTP "
            "has been sent."
        ),
        "email": email,
    }


# =========================================================
# VERIFY FORGOT PASSWORD OTP
# =========================================================

@router.post("/verify-forgot-password-otp")
def verify_forgot_password_otp(
    data: VerifyForgotPasswordOTPIn,
    db: Session = Depends(get_db),
):
    email = str(data.email).lower().strip()
    otp = data.otp.strip()

    # -----------------------------------------------------
    # VALIDATE OTP FORMAT
    # -----------------------------------------------------

    if not otp.isdigit():
        raise HTTPException(
            status_code=400,
            detail="OTP must contain only numbers",
        )

    if len(otp) != 6:
        raise HTTPException(
            status_code=400,
            detail="OTP must contain exactly 6 digits",
        )

    # -----------------------------------------------------
    # FIND USER
    # -----------------------------------------------------

    user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if not user:
        raise HTTPException(
            status_code=400,
            detail="Invalid email or OTP",
        )

    # -----------------------------------------------------
    # FIND LATEST RESET OTP
    # -----------------------------------------------------

    row = db.scalar(
        select(PasswordResetToken)
        .where(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.used.is_(False),
        )
        .order_by(
            PasswordResetToken.id.desc()
        )
    )

    if not row:
        raise HTTPException(
            status_code=400,
            detail=(
                "OTP not found. Please request a new OTP."
            ),
        )

    # -----------------------------------------------------
    # CHECK EXPIRY
    # -----------------------------------------------------

    if row.expires_at < datetime.utcnow():

        row.used = True

        db.commit()

        raise HTTPException(
            status_code=400,
            detail=(
                "OTP has expired. Please request a new OTP."
            ),
        )

    # -----------------------------------------------------
    # VERIFY OTP
    # -----------------------------------------------------

    if token_hash(otp) != row.token_hash:

        raise HTTPException(
            status_code=400,
            detail="Invalid OTP",
        )

    return {
        "message": "OTP verified successfully",
        "email": email,
        "verified": True,
    }


# =========================================================
# RESET PASSWORD USING OTP
# =========================================================

@router.post("/reset-password")
def reset_password(
    data: ResetPasswordOTPIn,
    db: Session = Depends(get_db),
):
    email = str(data.email).lower().strip()
    otp = data.otp.strip()

    # -----------------------------------------------------
    # VALIDATE PASSWORD
    # -----------------------------------------------------

    if len(data.password) < 8:
        raise HTTPException(
            status_code=400,
            detail="Password must contain at least 8 characters",
        )

    if len(data.password) > 128:
        raise HTTPException(
            status_code=400,
            detail="Password cannot exceed 128 characters",
        )

    if data.password != data.confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Passwords do not match",
        )

    # -----------------------------------------------------
    # FIND USER
    # -----------------------------------------------------

    user = db.scalar(
        select(User).where(
            User.email == email
        )
    )

    if not user:
        raise HTTPException(
            status_code=400,
            detail="Invalid email or OTP",
        )

    # -----------------------------------------------------
    # FIND LATEST RESET OTP
    # -----------------------------------------------------

    row = db.scalar(
        select(PasswordResetToken)
        .where(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.used.is_(False),
        )
        .order_by(
            PasswordResetToken.id.desc()
        )
    )

    if not row:
        raise HTTPException(
            status_code=400,
            detail=(
                "OTP not found. Please request a new OTP."
            ),
        )

    # -----------------------------------------------------
    # CHECK EXPIRY
    # -----------------------------------------------------

    if row.expires_at < datetime.utcnow():

        row.used = True

        db.commit()

        raise HTTPException(
            status_code=400,
            detail="OTP has expired. Please request a new OTP.",
        )

    # -----------------------------------------------------
    # VERIFY OTP AGAIN
    # -----------------------------------------------------

    if token_hash(otp) != row.token_hash:
        raise HTTPException(
            status_code=400,
            detail="Invalid OTP",
        )

    # -----------------------------------------------------
    # UPDATE PASSWORD
    # -----------------------------------------------------

    user.password_hash = hash_password(
        data.password
    )

    # -----------------------------------------------------
    # CONSUME OTP
    # -----------------------------------------------------

    row.used = True

    db.commit()

    return {
        "message": "Password changed successfully",
    }