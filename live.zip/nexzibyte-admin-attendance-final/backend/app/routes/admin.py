from pathlib import Path
from datetime import datetime
from pydantic import BaseModel, Field

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..email_service import send_email
from ..file_service import BASE_STORAGE, delete_stored
from ..models import Intern, InternDocument, User, AttendanceAccessRequest
from ..security import hash_password, verify_password


router = APIRouter(
    prefix="/api/admin",
    tags=["Admin"],
)


# ---------------------------------------------------------
# GET PENDING INTERN APPROVALS
# ---------------------------------------------------------

@router.get("/pending-approvals")
def get_pending_approvals(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    users = db.scalars(
        select(User)
        .where(
            User.role == "student",
            User.approval_status == "pending",
        )
        .order_by(User.created_at.asc())
    ).all()

    return [
        {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "is_verified": user.is_verified,
            "approval_status": user.approval_status,
            "offer_original_name": user.offer_original_name,
            "created_at": user.created_at,
        }
        for user in users
    ]


# ---------------------------------------------------------
# VIEW / DOWNLOAD INTERN OFFER LETTER
# ---------------------------------------------------------

@router.get("/pending-approvals/{user_id}/offer-letter")
def get_offer_letter(
    user_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    user = db.get(User, user_id)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User account not found",
        )

    if user.role != "student":
        raise HTTPException(
            status_code=400,
            detail="Offer letter is only available for intern accounts",
        )

    if not user.offer_stored_name:
        raise HTTPException(
            status_code=404,
            detail="Offer letter not found",
        )

    path = (
        BASE_STORAGE
        / Path(user.offer_stored_name).name
    )

    if not path.exists():
        raise HTTPException(
            status_code=404,
            detail="Stored offer letter file is missing",
        )

    return FileResponse(
        path=path,
        media_type=(
            user.offer_content_type
            or "application/octet-stream"
        ),
        filename=(
            user.offer_original_name
            or "offer-letter"
        ),
    )


# ---------------------------------------------------------
# APPROVE INTERN
# ---------------------------------------------------------

@router.post("/approve/{user_id}")
def approve_intern(
    user_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    user = db.get(User, user_id)

    if not user:
        raise HTTPException(
            status_code=404,
            detail=f"User account with ID {user_id} not found",
        )

    if user.role != "student":
        raise HTTPException(
            status_code=400,
            detail="Only intern accounts can be approved",
        )

    if not user.is_verified:
        raise HTTPException(
            status_code=400,
            detail="Intern must verify their email before approval",
        )

    if user.approval_status == "approved":
        raise HTTPException(
            status_code=400,
            detail="Intern account is already approved",
        )

    # -----------------------------------------------------
    # FIND EXISTING INTERN RECORD
    # -----------------------------------------------------

    intern = db.scalar(
        select(Intern).where(
            func.lower(Intern.email)
            == user.email.strip().lower()
        )
    )

    # -----------------------------------------------------
    # IF EMAIL DOES NOT MATCH,
    # TRY TO FIND INTERN USING NAME
    # -----------------------------------------------------

    if not intern:

        name_matches = db.scalars(
            select(Intern).where(
                func.lower(Intern.name)
                == user.name.strip().lower()
            )
        ).all()

        if len(name_matches) == 1:
            intern = name_matches[0]

        elif len(name_matches) > 1:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Multiple intern records have the same name. "
                    "Please link the correct intern manually."
                ),
            )

   # -----------------------------------------------------
    # NO MATCHING INTERN -> AUTO CREATE ONE
    # -----------------------------------------------------

    if not intern:
        from datetime import date

        intern = Intern(
            name=user.name,
            email=user.email,
            joining_date=date.today(),
            internship_role="Full Stack Developer",
            duration_months=5,
            status="Active",
        )
        db.add(intern)
        db.flush()
    # -----------------------------------------------------
    # CHECK WHETHER INTERN IS ALREADY LINKED
    # -----------------------------------------------------

    if intern.user_id and intern.user_id != user.id:
        raise HTTPException(
            status_code=409,
            detail=(
                "This intern is already linked to another user account."
            ),
        )

    # -----------------------------------------------------
    # LINK EXISTING INTERN TO USER
    # -----------------------------------------------------

    intern.user_id = user.id

    # Synchronize only name and email.
    # Other existing intern details remain unchanged.

    intern.name = user.name
    intern.email = user.email

    # -----------------------------------------------------
    # LINK OFFER LETTER
    # -----------------------------------------------------

    if user.offer_stored_name:

        existing_document = db.scalar(
            select(InternDocument).where(
                InternDocument.intern_id == intern.id,
                InternDocument.document_type == "offer_letter",
            )
        )

        if existing_document:

            old_stored_name = existing_document.stored_name

            existing_document.original_name = (
                user.offer_original_name
                or "offer_letter"
            )

            existing_document.stored_name = (
                user.offer_stored_name
            )

            existing_document.content_type = (
                user.offer_content_type
                or "application/octet-stream"
            )

            existing_document.size_bytes = (
                user.offer_size_bytes or 0
            )

            # Delete the previous file when it was replaced.

            if (
                old_stored_name
                and old_stored_name != user.offer_stored_name
            ):
                try:
                    delete_stored(old_stored_name)
                except Exception as error:
                    print(
                        "Old offer letter deletion warning:",
                        error,
                    )

        else:

            document = InternDocument(
                intern_id=intern.id,
                document_type="offer_letter",
                original_name=(
                    user.offer_original_name
                    or "offer_letter"
                ),
                stored_name=user.offer_stored_name,
                content_type=(
                    user.offer_content_type
                    or "application/octet-stream"
                ),
                size_bytes=user.offer_size_bytes or 0,
            )

            db.add(document)

    # -----------------------------------------------------
    # APPROVE USER ACCOUNT
    # -----------------------------------------------------

    user.approval_status = "approved"
    user.is_active = True

    db.commit()
    db.refresh(user)

    # -----------------------------------------------------
    # SEND APPROVAL EMAIL
    # -----------------------------------------------------

    send_email(
        user.email,
        "Nexzibyte Account Approved",
        (
            f"Hello {user.name},\n\n"
            f"Your Nexzibyte intern account has been approved "
            f"by the administrator.\n\n"
            f"You can now log in using your registered email "
            f"address and password.\n\n"
            f"Regards,\n"
            f"Nexzibyte Solutions"
        ),
    )

    return {
        "message": "Intern account approved successfully",
        "id": user.id,
        "intern_id": intern.id,
        "approval_status": user.approval_status,
    }


# ---------------------------------------------------------
# REJECT INTERN
# ---------------------------------------------------------

@router.post("/reject/{user_id}")
def reject_intern(
    user_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    user = db.get(User, user_id)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User account not found",
        )

    if user.role != "student":
        raise HTTPException(
            status_code=400,
            detail="Only intern accounts can be rejected",
        )

    user.approval_status = "rejected"
    user.is_active = False

    db.commit()
    db.refresh(user)

    # -----------------------------------------------------
    # SEND REJECTION EMAIL
    # -----------------------------------------------------

    send_email(
        user.email,
        "Nexzibyte Account Status",
        (
            f"Hello {user.name},\n\n"
            f"Your Nexzibyte intern account request was "
            f"not approved by the administrator.\n\n"
            f"Please contact the Nexzibyte administrator "
            f"for further information.\n\n"
            f"Regards,\n"
            f"Nexzibyte Solutions"
        ),
    )

    return {
        "message": "Intern account rejected",
        "id": user.id,
        "approval_status": user.approval_status,
    }


# ---------------------------------------------------------
# CHANGE ADMIN PASSWORD
# ---------------------------------------------------------

class AdminPasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)

@router.post("/change-password")
def change_admin_password(
    data: AdminPasswordIn,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    if not verify_password(
        data.current_password,
        admin.password_hash,
    ):
        raise HTTPException(
            status_code=400,
            detail="Current password is incorrect",
        )

    if len(data.new_password) < 8:
        raise HTTPException(
            status_code=400,
            detail="New password must contain at least 8 characters",
        )

    admin.password_hash = hash_password(data.new_password)

    db.commit()

    return {
        "message": "Admin password changed successfully",
    }

# ---------------------------------------------------------
# ATTENDANCE REACTIVATION REQUESTS
# ---------------------------------------------------------

@router.get("/attendance-access-requests")
def attendance_access_requests(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    rows = db.scalars(
        select(AttendanceAccessRequest)
        .where(AttendanceAccessRequest.status == "pending")
        .order_by(AttendanceAccessRequest.created_at.asc())
    ).all()
    return [
        {
            "id": r.id,
            "intern_id": r.intern_id,
            "intern_name": db.get(Intern, r.intern_id).name if db.get(Intern, r.intern_id) else "Intern",
            "intern_code": db.get(Intern, r.intern_id).intern_code if db.get(Intern, r.intern_id) else None,
            "reason": r.reason,
            "status": r.status,
            "created_at": r.created_at,
        }
        for r in rows
    ]


@router.post("/attendance-access-requests/{request_id}/approve")
def approve_attendance_access(
    request_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    req = db.get(AttendanceAccessRequest, request_id)
    if not req or req.status != "pending":
        raise HTTPException(404, "Pending attendance access request not found")
    intern = db.get(Intern, req.intern_id)
    if not intern or not intern.user_id:
        raise HTTPException(404, "Linked intern account not found")
    user = db.get(User, intern.user_id)
    user.attendance_enabled = True
    req.status = "approved"
    req.reviewed_at = datetime.utcnow()
    req.reviewed_by = admin.id
    db.commit()
    send_email(
        user.email,
        "Nexzibyte Attendance Enabled",
        f"Hello {user.name},\n\nYour attendance reactivation reason was approved by the administrator. You can now use attendance again from the Intern Portal.\n\nRegards,\nNexzibyte Solutions",
    )
    return {"message": "Attendance enabled for the intern", "intern_id": intern.id}


@router.post("/attendance-access-requests/{request_id}/reject")
def reject_attendance_access(
    request_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    req = db.get(AttendanceAccessRequest, request_id)
    if not req or req.status != "pending":
        raise HTTPException(404, "Pending attendance access request not found")
    intern = db.get(Intern, req.intern_id)
    user = db.get(User, intern.user_id) if intern and intern.user_id else None
    req.status = "rejected"
    req.reviewed_at = datetime.utcnow()
    req.reviewed_by = admin.id
    db.commit()
    if user:
        send_email(
            user.email,
            "Nexzibyte Attendance Request",
            f"Hello {user.name},\n\nYour attendance reactivation request was not approved. Please contact the administrator if you need clarification.\n\nRegards,\nNexzibyte Solutions",
        )
    return {"message": "Attendance request rejected"}
