import re
from datetime import date, datetime
from io import BytesIO
from pathlib import Path
from uuid import uuid4
from PIL import Image, UnidentifiedImageError, ImageOps
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select, or_, update
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import User, Intern, ProfilePhoto, CalendarEvent, Notification, InternDocument
from ..file_service import BASE_STORAGE, delete_stored
from ..services.notifications import notify, recipients
router=APIRouter(prefix="/api",tags=["Calendar, profiles and notifications"])

def own(db,user):
    intern=db.scalar(select(Intern).where(Intern.user_id==user.id))
    if intern is None:
        raise HTTPException(404,"Intern profile not found")
    return intern

def access(db,user,iid):
    intern=db.get(Intern,iid)
    if intern is None:
        raise HTTPException(404,"Intern not found")
    if user.role != "admin" and intern.user_id != user.id:
        raise HTTPException(403,"Access denied")
    return intern

@router.get("/profiles")
def profiles(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    stmt=select(ProfilePhoto)
    if user.role != "admin":
        stmt=stmt.where(ProfilePhoto.intern_id==own(db,user).id)
    return [{"intern_id":p.intern_id,"updated_at":p.updated_at,"has_photo":True} for p in db.scalars(stmt)]

@router.post("/profiles/me/photo")
async def upload_photo(file:UploadFile=File(...),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role == "admin":
        raise HTTPException(403,"Upload the picture from the intern account")
    intern=own(db,user)
    raw=await file.read(5*1024*1024+1)
    if len(raw)>5*1024*1024:
        raise HTTPException(413,"Profile photo must be smaller than 5 MB")
    try:
        with Image.open(BytesIO(raw)) as image:
            if image.format not in ("JPEG","PNG","WEBP"):
                raise HTTPException(400,"Use a JPG, PNG or WebP image")
            if image.width*image.height > 20_000_000:
                raise HTTPException(400,"Image is too large")
            image=ImageOps.exif_transpose(image).convert("RGB")
            image.thumbnail((800,800))
            name=f"profile_{uuid4().hex}.jpg"
            image.save(BASE_STORAGE/name,"JPEG",quality=90)
    except (UnidentifiedImageError,OSError,Image.DecompressionBombError):
        raise HTTPException(400,"Upload a valid image")
    photo=db.get(ProfilePhoto,intern.id)
    old=photo.stored_name if photo else None
    if photo:
        photo.stored_name=name
        photo.updated_at=datetime.utcnow()
    else:
        db.add(ProfilePhoto(intern_id=intern.id,stored_name=name))
    try:
        db.commit()
    except Exception:
        delete_stored(name)
        raise
    delete_stored(old)
    return {"message":"Profile photo updated","intern_id":intern.id}

@router.get("/profiles/{intern_id}/photo")
def photo(intern_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    access(db,user,intern_id)
    photo=db.get(ProfilePhoto,intern_id)
    if photo is None or not (BASE_STORAGE/Path(photo.stored_name).name).exists():
        raise HTTPException(404,"No profile photo uploaded")
    return FileResponse(BASE_STORAGE/Path(photo.stored_name).name,media_type="image/jpeg",headers={"Cache-Control":"private, no-store"})

@router.get("/profiles/{intern_id}/documents")
def all_documents(intern_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    intern=access(db,user,intern_id)
    docs=db.scalars(select(InternDocument).where(InternDocument.intern_id==intern_id)).all()
    result=[{"id":d.id,"original_name":d.original_name,"document_type":d.document_type,"download_path":f"/documents/{d.id}/download"} for d in docs]
    account=db.get(User,intern.user_id) if intern.user_id else None
    if account and account.offer_stored_name and not any(d.stored_name==account.offer_stored_name for d in docs):
        result.append({"id":"registration","original_name":account.offer_original_name or "Registration offer letter","document_type":"registration_offer_letter","download_path":f"/profiles/{intern_id}/registration-document"})
    return result

@router.get("/profiles/{intern_id}/registration-document")
def registration_doc(intern_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    intern=access(db,user,intern_id)
    account=db.get(User,intern.user_id) if intern.user_id else None
    if not account or not account.offer_stored_name:
        raise HTTPException(404,"Document not found")
    path=BASE_STORAGE/Path(account.offer_stored_name).name
    if not path.exists():
        raise HTTPException(404,"Stored file is missing")
    return FileResponse(path,filename=account.offer_original_name or "offer-letter.pdf")

class EventIn(BaseModel):
    title:str=Field(min_length=1,max_length=200)
    description:str=Field(default="",max_length=5000)
    event_date:date
    event_time:str|None=None
    color:str="#f3c440"
    intern_id:int|None=None
    @field_validator("title")
    @classmethod
    def title_valid(cls,v):
        if not v.strip():
            raise ValueError("Enter an event title")
        return v.strip()
    @field_validator("color")
    @classmethod
    def valid_color(cls,v):
        if not re.fullmatch(r"#[0-9a-fA-F]{6}",v):
            raise ValueError("Use a hex color")
        return v
    @field_validator("event_time")
    @classmethod
    def valid_time(cls,v):
        if not v:
            return None
        datetime.strptime(v,"%H:%M")
        return v

def event_out(e):
    return {"id":e.id,"title":e.title,"description":e.description,"event_date":e.event_date,"event_time":e.event_time,"color":e.color,"intern_id":e.intern_id}

@router.get("/calendar/events")
def events(start:date|None=None,end:date|None=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    stmt=select(CalendarEvent).order_by(CalendarEvent.event_date,CalendarEvent.event_time)
    if user.role!="admin":
        stmt=stmt.where(or_(CalendarEvent.intern_id.is_(None),CalendarEvent.intern_id==own(db,user).id))
    if start:
        stmt=stmt.where(CalendarEvent.event_date>=start)
    if end:
        stmt=stmt.where(CalendarEvent.event_date<=end)
    return [event_out(e) for e in db.scalars(stmt)]

@router.post("/calendar/events",status_code=201)
def create_event(data:EventIn,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    if data.intern_id is not None and not db.get(Intern,data.intern_id):
        raise HTTPException(404,"Intern not found")
    e=CalendarEvent(**data.model_dump(),created_by=user.id)
    db.add(e);db.flush()
    notify(db,recipients(db,e.intern_id),"New scheduled event",f"{e.title} — {e.event_date} {e.event_time or 'All day'}. {e.description}","event",f"calendar.html?date={e.event_date}&event={e.id}")
    db.commit()
    return event_out(e)

@router.put("/calendar/events/{event_id}")
def edit_event(event_id:int,data:EventIn,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    e=db.get(CalendarEvent,event_id)
    if not e:
        raise HTTPException(404,"Event not found")
    if data.intern_id is not None and not db.get(Intern,data.intern_id):
        raise HTTPException(404,"Intern not found")
    old=set(recipients(db,e.intern_id))
    for k,v in data.model_dump().items():
        setattr(e,k,v)
    new=set(recipients(db,e.intern_id))
    notify(db,new,"Event updated",f"{e.title} — {e.event_date} {e.event_time or 'All day'}. {e.description}","event",f"calendar.html?date={e.event_date}&event={e.id}")
    notify(db,old-new,"Event no longer assigned to you",e.title,"event","calendar.html")
    db.commit()
    return event_out(e)

@router.delete("/calendar/events/{event_id}")
def delete_event(event_id:int,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    e=db.get(CalendarEvent,event_id)
    if not e:
        raise HTTPException(404,"Event not found")
    notify(db,recipients(db,e.intern_id),"Event cancelled",f"{e.title} on {e.event_date}","event","calendar.html")
    db.delete(e);db.commit()
    return {"message":"Event cancelled and interns notified"}

@router.get("/notifications")
def notifications(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role=="admin":
        return {"unread_count":0,"items":[]}
    iid=own(db,user).id
    items=db.scalars(select(Notification).where(Notification.intern_id==iid).order_by(Notification.id.desc()).limit(100)).all()
    from sqlalchemy import func
    count=db.scalar(select(func.count(Notification.id)).where(Notification.intern_id==iid,Notification.is_read.is_(False))) or 0
    return {"unread_count":count,"items":[{"id":n.id,"title":n.title,"message":n.message,"kind":n.kind,"link":n.link,"is_read":n.is_read,"created_at":n.created_at.isoformat()+"Z"} for n in items]}

@router.post("/notifications/read-all")
def read_all(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=own(db,user).id
    db.execute(update(Notification).where(Notification.intern_id==iid).values(is_read=True));db.commit()
    return {"message":"Notifications marked as read"}

@router.post("/notifications/{notification_id}/read")
def read_one(notification_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    n=db.get(Notification,notification_id)
    if not n or n.intern_id!=own(db,user).id:
        raise HTTPException(404,"Notification not found")
    n.is_read=True;db.commit()
    return {"message":"Notification read"}
