from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Assignment, AssignmentSubmission, Intern, User
from ..services.notifications import notify
from ..schemas.core import SubmissionIn
router=APIRouter(prefix="/api/assignments",tags=["Assignments"])

class AssignmentPayload(BaseModel):
    title:str=Field(min_length=1,max_length=200)
    description:str|None=""
    intern_id:int|None=None
    assigned_to:str|None=None
    due_date:date|None=None
    status:str="Pending"

class AssignmentUpdate(BaseModel):
    title:str|None=Field(default=None,min_length=1,max_length=200)
    description:str|None=None
    intern_id:int|None=None
    due_date:date|None=None
    status:str|None=None

STATES={"Assigned","Pending","In Progress","Completed","Submitted"}

def own_id(db,user):
    iid=db.scalar(select(Intern.id).where(Intern.user_id==user.id))
    if iid is None:
        raise HTTPException(404,"Intern profile not found")
    return iid

def out(db,a):
    i=db.get(Intern,a.intern_id)
    return {"id":a.id,"intern_id":a.intern_id,"title":a.title,"description":a.description,"due_date":a.due_date,"status":a.status,"created_at":a.created_at,"assigned_to":i.name if i else "Intern"}

@router.get("")
@router.get("/")
def list_assignments(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    stmt=select(Assignment).order_by(Assignment.id.desc())
    if user.role!="admin":
        stmt=stmt.where(Assignment.intern_id==own_id(db,user))
    return [out(db,a) for a in db.scalars(stmt)]

@router.post("",status_code=201)
@router.post("/",status_code=201)
def create(data:AssignmentPayload,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    if not data.title.strip():
        raise HTTPException(422,"Enter a title")
    if data.status not in STATES:
        raise HTTPException(422,"Invalid assignment status")
    intern=db.get(Intern,data.intern_id) if data.intern_id else None
    if not intern:
        raise HTTPException(422,"Select an intern")
    a=Assignment(intern_id=intern.id,title=data.title.strip(),description=data.description,due_date=data.due_date,status=data.status)
    db.add(a);db.flush()
    notify(db,[intern.id],"New assignment",f"{a.title}. Due: {a.due_date or 'Not specified'}. {a.description or ''}","assignment",f"assignment.html?task={a.id}")
    db.commit()
    return out(db,a)

@router.put("/{task_id}")
def edit(task_id:int,data:AssignmentUpdate,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    a=db.get(Assignment,task_id)
    if a is None:
        raise HTTPException(404,"Assignment not found")
    if user.role!="admin":
        if a.intern_id!=own_id(db,user):
            raise HTTPException(403,"Access denied")
        if data.status not in STATES:
            raise HTTPException(422,"Choose a valid status")
        # Interns may update progress, never ownership or task content.
        if any(k in data.model_fields_set and getattr(data,k)!=getattr(a,k) for k in ("title","description","due_date","intern_id")):
            raise HTTPException(403,"Only the admin can change assignment details")
        a.status=data.status
    else:
        old=a.intern_id
        if data.intern_id is not None and not db.get(Intern,data.intern_id):
            raise HTTPException(404,"Intern not found")
        if data.status is not None and data.status not in STATES:
            raise HTTPException(422,"Invalid assignment status")
        for k,v in data.model_dump(exclude_unset=True).items():
            if k in ("title","intern_id","status") and (v is None or isinstance(v,str) and not v.strip()):
                raise HTTPException(422,f"{k} cannot be empty")
            setattr(a,k,v)
        notify(db,[a.intern_id],"Assignment updated",f"{a.title}. Due: {a.due_date or 'Not specified'}", "assignment",f"assignment.html?task={a.id}")
        if old!=a.intern_id:
            notify(db,[old],"Assignment reassigned",a.title,"assignment","assignment.html")
    db.commit()
    return out(db,a)

@router.post("/{task_id}/submit")
def submit(task_id:int,data:SubmissionIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    a=db.get(Assignment,task_id)
    if not a or a.intern_id!=own_id(db,user):
        raise HTTPException(403,"Access denied")
    if not data.submission_text and not data.submission_url:
        raise HTTPException(422,"Add a submission note or URL")
    db.add(AssignmentSubmission(assignment_id=a.id,**data.model_dump()))
    a.status="Submitted";db.commit()
    return {"message":"Work submitted"}

@router.get("/{task_id}/submissions")
def submissions(task_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    a=db.get(Assignment,task_id)
    if not a or user.role!="admin" and a.intern_id!=own_id(db,user):
        raise HTTPException(403,"Access denied")
    return [{"id":s.id,"submission_text":s.submission_text,"submission_url":s.submission_url,"submitted_at":s.submitted_at,"status":s.status} for s in db.scalars(select(AssignmentSubmission).where(AssignmentSubmission.assignment_id==task_id).order_by(AssignmentSubmission.id.desc()))]

@router.delete("/{task_id}")
def remove(task_id:int,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    a=db.get(Assignment,task_id)
    if a is None:
        raise HTTPException(404,"Assignment not found")
    notify(db,[a.intern_id],"Assignment removed",a.title,"assignment","assignment.html")
    db.delete(a);db.commit()
    return {"message":"Assignment deleted"}
