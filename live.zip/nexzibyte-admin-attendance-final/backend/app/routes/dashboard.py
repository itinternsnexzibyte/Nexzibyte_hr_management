from datetime import date, timedelta
from ..services.attendance import now_ist, daily_records

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import (
    Attendance,
    Assignment,
    AssignmentRating,
    Employee,
    Intern,
    USClient,
    User,
)

router = APIRouter(
    prefix="/api/dashboard",
    tags=["Dashboard"]
)


@router.get("/summary")
def summary(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role == "admin":
        total_interns = db.scalar(
            select(func.count(Intern.id))
        ) or 0

        total_employees = db.scalar(
            select(func.count(Employee.id))
        ) or 0

        total_assignments = db.scalar(
            select(func.count(Assignment.id))
        ) or 0

        today_attendance = db.scalar(
            select(func.count(func.distinct(Attendance.intern_id))).where(
                Attendance.attendance_date == now_ist().date(),
                Attendance.status.notin_(["Absent", "Leave"])
            )
        ) or 0

        rated_today = db.scalar(
            select(func.count(AssignmentRating.id)).where(
                AssignmentRating.rating_date == now_ist().date()
            )
        ) or 0

        pending_ratings = total_interns - rated_today
        if pending_ratings < 0:
            pending_ratings = 0

        active_us_clients = db.scalar(
            select(func.count(USClient.id)).where(
                USClient.client_name.is_not(None)
            )
        ) or 0

        # Dynamic Approvals Breakdown
        new_registrations = db.scalar(
            select(func.count(User.id)).where(
                User.role == "student",
                User.approval_status == "pending",
            )
        ) or 0

        offer_letters = db.scalar(
            select(func.count(User.id)).where(
                User.role == "student",
                User.offer_stored_name.is_not(None),
                User.approval_status == "pending",
            )
        ) or 0

        # Dynamic 7-day registration history for the Chart
        today = now_ist().date()
        chart_labels = []
        chart_data = []
        for i in range(7, -1, -1):
            day = today - timedelta(days=i)
            chart_labels.append(day.strftime("%b %d"))
            count = db.scalar(
                select(func.count(User.id)).where(
                    func.date(User.created_at) == day
                )
            ) or 0
            chart_data.append(count)

        return {
            "admin_name": "Admin",
            "break_seconds_today": sum(r["break_seconds"] for r in daily_records(db, day=now_ist().date())),
            "total_interns": total_interns,
            "total_employees": total_employees,
            "total_assignments": total_assignments,
            "today_attendance": today_attendance,
            "pending_ratings": pending_ratings,
            "active_us_clients": active_us_clients,
            "breakdown": {
                "new_registrations": new_registrations,
                "offer_letters": offer_letters,
                "approval_requests": new_registrations,
            },
            "chart": {
                "labels": chart_labels,
                "data": chart_data,
            }
        }

    # Student Fallback
    intern = db.scalar(
        select(Intern).where(
            Intern.user_id == user.id
        )
    )

    if not intern:
        return {
            "total_interns": 0,
            "total_employees": 0,
            "total_assignments": 0,
            "today_attendance": 0,
            "pending_ratings": 0,
            "active_us_clients": 0
        }

    total_assignments = db.scalar(
        select(func.count(Assignment.id)).where(
            Assignment.intern_id == intern.id
        )
    ) or 0

    today_attendance = db.scalar(
        select(func.count(func.distinct(Attendance.intern_id))).where(
            Attendance.intern_id == intern.id,
            Attendance.attendance_date == now_ist().date(),
                Attendance.status.notin_(["Absent", "Leave"])
        )
    ) or 0

    return {
        "total_interns": 1,
        "total_employees": 0,
        "total_assignments": total_assignments,
        "today_attendance": today_attendance,
        "pending_ratings": 0,
        "active_us_clients": 0
    }