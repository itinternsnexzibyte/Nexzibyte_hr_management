from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..file_service import BASE_STORAGE, save_upload, delete_stored
from ..models import InternDocument, Intern, User


router = APIRouter(
    prefix="/api/documents",
    tags=["Documents"]
)


# ============================================================
# UPLOAD OFFER LETTER
# Admin only
# ============================================================

@router.post("/intern/{intern_id}/upload")
async def upload_document(
    intern_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    intern = db.get(Intern, intern_id)

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found"
        )

    # Save uploaded file using existing file service
    stored_name, content_type, size_bytes = await save_upload(file)

    document = InternDocument(
        intern_id=intern_id,
        document_type="offer_letter",
        original_name=file.filename or "offer_letter",
        stored_name=stored_name,
        content_type=content_type,
        size_bytes=size_bytes,
    )

    db.add(document)
    db.commit()
    db.refresh(document)

    return {
        "id": document.id,
        "intern_id": document.intern_id,
        "document_type": document.document_type,
        "original_name": document.original_name,
        "content_type": document.content_type,
        "size_bytes": document.size_bytes,
    }


# ============================================================
# LIST DOCUMENTS FOR AN INTERN
# Admin can see all
# Student can see only their own
# ============================================================

@router.get("/intern/{intern_id}")
def list_documents(
    intern_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    intern = db.get(Intern, intern_id)

    if not intern:
        raise HTTPException(
            status_code=404,
            detail="Intern not found"
        )

    # Students can only access their own documents
    if user.role == "student":
        if not intern.user_id or intern.user_id != user.id:
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )

    documents = db.scalars(
        select(InternDocument)
        .where(
            InternDocument.intern_id == intern_id
        )
        .order_by(
            InternDocument.created_at.desc()
        )
    ).all()

    return [
        {
            "id": doc.id,
            "intern_id": doc.intern_id,
            "document_type": doc.document_type,
            "original_name": doc.original_name,
            "content_type": doc.content_type,
            "size_bytes": doc.size_bytes,
            "created_at": doc.created_at,
        }
        for doc in documents
    ]


# ============================================================
# DOWNLOAD / VIEW DOCUMENT
# ============================================================

@router.get("/{document_id}/download")
def download_document(
    document_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    doc = db.get(
        InternDocument,
        document_id
    )

    if not doc:
        raise HTTPException(
            status_code=404,
            detail="Document not found"
        )

    # Students can only download their own documents
    if user.role == "student":
        if (
            not doc.intern.user_id
            or doc.intern.user_id != user.id
        ):
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )

    path = (
        BASE_STORAGE
        / Path(doc.stored_name).name
    )

    if not path.exists():
        raise HTTPException(
            status_code=404,
            detail="Stored file is missing"
        )

    return FileResponse(
        path,
        media_type=doc.content_type,
        filename=doc.original_name,
    )


# ============================================================
# DELETE DOCUMENT
# Admin only
# ============================================================

@router.delete("/{document_id}")
def delete_document(
    document_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    doc = db.get(
        InternDocument,
        document_id
    )

    if not doc:
        raise HTTPException(
            status_code=404,
            detail="Document not found"
        )

    # Delete physical file
    delete_stored(
        doc.stored_name
    )

    # Delete database record
    db.delete(doc)
    db.commit()

    return {
        "message": "Document deleted successfully"
    }