
from datetime import time
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..file_service import BASE_STORAGE, delete_stored, save_upload
from ..models import USClient, User


router = APIRouter(
    prefix="/api/us-client",
    tags=["US Client"]
)


# =========================================================
# HELPER
# =========================================================

def get_client_or_404(
    client_id: int,
    db: Session
) -> USClient:

    row = db.get(USClient, client_id)

    if not row:
        raise HTTPException(
            status_code=404,
            detail="Client not found"
        )

    return row


def parse_time(
    value,
    field_name: str
):
    """
    Convert HH:MM or HH:MM:SS string into Python time.
    """

    if value is None or value == "":
        return None

    if isinstance(value, time):
        return value

    value = str(value).strip()

    try:
        if len(value) == 5:
            return time.fromisoformat(
                value
            )

        return time.fromisoformat(
            value
        )

    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"{field_name} must be a valid time"
        )


# =========================================================
# GET ALL CLIENTS
# =========================================================

@router.get("")
def get_clients(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    rows = list(
        db.scalars(
            select(USClient)
            .order_by(USClient.id)
        ).all()
    )

    return [
        {
            "id": r.id,

            "client_name":
                r.client_name,

            # Photo
            "photo_original_name":
                r.photo_original_name,

            # Aadhaar
            "aadhar_original_name":
                r.aadhar_original_name,

            # Phone
            "phone_country_code":
                r.phone_country_code,

            "phone_number":
                r.phone_number,

            # Location
            "country":
                r.country,

            "state_region":
                r.state_region,

            "city":
                r.city,

            "address":
                r.address,

            # Availability
            "availability":
                r.availability,

            "available_from":
                (
                    r.available_from.isoformat()
                    if r.available_from
                    else None
                ),

            "available_to":
                (
                    r.available_to.isoformat()
                    if r.available_to
                    else None
                ),

            # Reference
            "reference_email":
                r.reference_email,

            # MOU
            "mou_original_name":
                r.mou_original_name,

            # Notes
            "notes":
                r.notes,

            # Dates
            "created_at":
                r.created_at,

            "updated_at":
                r.updated_at,
        }

        for r in rows
    ]


# =========================================================
# CREATE CLIENT
# =========================================================

@router.post("")
def create_client(
    data: dict,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    client_name = str(
        data.get("client_name") or ""
    ).strip()

    if not client_name:
        raise HTTPException(
            status_code=400,
            detail="Client name is required"
        )


    availability = str(
        data.get("availability")
        or "Available"
    ).strip()


    if availability not in {
        "Available",
        "Unavailable"
    }:

        raise HTTPException(
            status_code=400,
            detail=(
                "Availability must be "
                "Available or Unavailable"
            )
        )


    available_from = parse_time(
        data.get("available_from"),
        "Available From"
    )


    available_to = parse_time(
        data.get("available_to"),
        "Available To"
    )


    if availability == "Unavailable":

        available_from = None
        available_to = None


    row = USClient(

        client_name=client_name,

        phone_country_code=(
            str(
                data.get(
                    "phone_country_code"
                )
            ).strip()
            if data.get(
                "phone_country_code"
            )
            else None
        ),

        phone_number=(
            str(
                data.get(
                    "phone_number"
                )
            ).strip()
            if data.get(
                "phone_number"
            )
            else None
        ),

        country=(
            str(
                data.get(
                    "country"
                )
            ).strip()
            if data.get(
                "country"
            )
            else None
        ),

        state_region=(
            str(
                data.get(
                    "state_region"
                )
            ).strip()
            if data.get(
                "state_region"
            )
            else None
        ),

        city=(
            str(
                data.get(
                    "city"
                )
            ).strip()
            if data.get(
                "city"
            )
            else None
        ),

        address=(
            str(
                data.get(
                    "address"
                )
            ).strip()
            if data.get(
                "address"
            )
            else None
        ),

        availability=availability,

        available_from=
            available_from,

        available_to=
            available_to,

        reference_email=(
            str(
                data.get(
                    "reference_email"
                )
            ).strip()
            if data.get(
                "reference_email"
            )
            else None
        ),

        notes=(
            str(
                data.get(
                    "notes"
                )
            ).strip()
            if data.get(
                "notes"
            )
            else None
        ),
    )


    db.add(row)

    db.commit()

    db.refresh(row)


    return {
        "message":
            "Client created successfully",

        "id":
            row.id,

        "client_name":
            row.client_name,
    }


# =========================================================
# UPDATE CLIENT
# =========================================================

@router.put("/{client_id}")
def update_client(
    client_id: int,
    data: dict,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    client_name = str(
        data.get("client_name") or ""
    ).strip()


    if not client_name:

        raise HTTPException(
            status_code=400,
            detail="Client name is required"
        )


    availability = str(
        data.get("availability")
        or "Available"
    ).strip()


    if availability not in {
        "Available",
        "Unavailable"
    }:

        raise HTTPException(
            status_code=400,
            detail=(
                "Availability must be "
                "Available or Unavailable"
            )
        )


    available_from = parse_time(
        data.get("available_from"),
        "Available From"
    )


    available_to = parse_time(
        data.get("available_to"),
        "Available To"
    )


    if availability == "Unavailable":

        available_from = None
        available_to = None


    row.client_name = client_name


    row.phone_country_code = (
        str(
            data.get(
                "phone_country_code"
            )
        ).strip()
        if data.get(
            "phone_country_code"
        )
        else None
    )


    row.phone_number = (
        str(
            data.get(
                "phone_number"
            )
        ).strip()
        if data.get(
            "phone_number"
        )
        else None
    )


    row.country = (
        str(
            data.get(
                "country"
            )
        ).strip()
        if data.get(
            "country"
        )
        else None
    )


    row.state_region = (
        str(
            data.get(
                "state_region"
            )
        ).strip()
        if data.get(
            "state_region"
        )
        else None
    )


    row.city = (
        str(
            data.get(
                "city"
            )
        ).strip()
        if data.get(
            "city"
        )
        else None
    )


    row.address = (
        str(
            data.get(
                "address"
            )
        ).strip()
        if data.get(
            "address"
        )
        else None
    )


    row.availability = availability


    row.available_from = (
        available_from
    )


    row.available_to = (
        available_to
    )


    row.reference_email = (
        str(
            data.get(
                "reference_email"
            )
        ).strip()
        if data.get(
            "reference_email"
        )
        else None
    )


    row.notes = (
        str(
            data.get(
                "notes"
            )
        ).strip()
        if data.get(
            "notes"
        )
        else None
    )


    db.commit()

    db.refresh(row)


    return {
        "message":
            "Client updated successfully",

        "id":
            row.id,

        "client_name":
            row.client_name,
    }


# =========================================================
# UPLOAD PHOTO
# =========================================================

@router.post("/{client_id}/photo")
async def upload_photo(
    client_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    original_name = (
        file.filename or ""
    )


    extension = Path(
        original_name
    ).suffix.lower()


    allowed_extensions = {
        ".jpg",
        ".jpeg",
        ".png"
    }


    if extension not in allowed_extensions:

        raise HTTPException(
            status_code=400,
            detail=(
                "Photo must be JPG, "
                "JPEG, or PNG"
            )
        )


    stored, content_type, size = (
        await save_upload(file)
    )


    delete_stored(
        row.photo_stored_name
    )


    row.photo_original_name = (
        original_name
    )

    row.photo_stored_name = (
        stored
    )

    row.photo_content_type = (
        content_type
    )

    row.photo_size_bytes = (
        size
    )


    db.commit()

    db.refresh(row)


    return {
        "message":
            "Client photo uploaded successfully",

        "filename":
            row.photo_original_name,
    }


# =========================================================
# VIEW / DOWNLOAD PHOTO
# =========================================================

@router.get("/{client_id}/photo")
def download_photo(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    if not row.photo_stored_name:

        raise HTTPException(
            status_code=404,
            detail="Client photo not found"
        )


    path = (
        BASE_STORAGE
        / Path(
            row.photo_stored_name
        ).name
    )


    if not path.exists():

        raise HTTPException(
            status_code=404,
            detail="Stored photo file is missing"
        )


    return FileResponse(
        path,

        media_type=(
            row.photo_content_type
            or "application/octet-stream"
        ),

        filename=(
            row.photo_original_name
            or "client-photo"
        )
    )


# =========================================================
# DELETE PHOTO
# =========================================================

@router.delete("/{client_id}/photo")
def delete_photo(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    delete_stored(
        row.photo_stored_name
    )


    row.photo_original_name = None

    row.photo_stored_name = None

    row.photo_content_type = None

    row.photo_size_bytes = None


    db.commit()


    return {
        "message":
            "Client photo deleted successfully"
    }


# =========================================================
# UPLOAD AADHAAR
# =========================================================

@router.post("/{client_id}/aadhar")
async def upload_aadhar(
    client_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    original_name = (
        file.filename or ""
    )


    extension = Path(
        original_name
    ).suffix.lower()


    allowed_extensions = {
        ".pdf",
        ".jpg",
        ".jpeg",
        ".png"
    }


    if extension not in allowed_extensions:

        raise HTTPException(
            status_code=400,
            detail=(
                "Aadhaar must be PDF, "
                "JPG, JPEG, or PNG"
            )
        )


    stored, content_type, size = (
        await save_upload(file)
    )


    delete_stored(
        row.aadhar_stored_name
    )


    row.aadhar_original_name = (
        original_name
    )

    row.aadhar_stored_name = (
        stored
    )

    row.aadhar_content_type = (
        content_type
    )

    row.aadhar_size_bytes = (
        size
    )


    db.commit()

    db.refresh(row)


    return {
        "message":
            "Aadhaar document uploaded successfully",

        "filename":
            row.aadhar_original_name,
    }


# =========================================================
# VIEW / DOWNLOAD AADHAAR
# =========================================================

@router.get("/{client_id}/aadhar")
def download_aadhar(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    if not row.aadhar_stored_name:

        raise HTTPException(
            status_code=404,
            detail="Aadhaar document not found"
        )


    path = (
        BASE_STORAGE
        / Path(
            row.aadhar_stored_name
        ).name
    )


    if not path.exists():

        raise HTTPException(
            status_code=404,
            detail="Stored Aadhaar file is missing"
        )


    return FileResponse(
        path,

        media_type=(
            row.aadhar_content_type
            or "application/octet-stream"
        ),

        filename=(
            row.aadhar_original_name
            or "Aadhaar-document"
        )
    )


# =========================================================
# DELETE AADHAAR
# =========================================================

@router.delete("/{client_id}/aadhar")
def delete_aadhar(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    delete_stored(
        row.aadhar_stored_name
    )


    row.aadhar_original_name = None

    row.aadhar_stored_name = None

    row.aadhar_content_type = None

    row.aadhar_size_bytes = None


    db.commit()


    return {
        "message":
            "Aadhaar document deleted successfully"
    }


# =========================================================
# UPLOAD MOU
# =========================================================

@router.post("/{client_id}/mou")
async def upload_mou(
    client_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    stored, content_type, size = (
        await save_upload(file)
    )


    delete_stored(
        row.mou_stored_name
    )


    row.mou_original_name = (
        file.filename
    )

    row.mou_stored_name = (
        stored
    )

    row.mou_content_type = (
        content_type
    )

    row.mou_size_bytes = (
        size
    )


    db.commit()

    db.refresh(row)


    return {
        "message":
            "MOU Agreement uploaded",

        "filename":
            row.mou_original_name,
    }


# =========================================================
# VIEW / DOWNLOAD MOU
# =========================================================

@router.get("/{client_id}/mou")
def download_mou(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    if not row.mou_stored_name:

        raise HTTPException(
            status_code=404,
            detail="MOU Agreement not found"
        )


    path = (
        BASE_STORAGE
        / Path(
            row.mou_stored_name
        ).name
    )


    if not path.exists():

        raise HTTPException(
            status_code=404,
            detail="Stored MOU file is missing"
        )


    return FileResponse(
        path,

        media_type=(
            row.mou_content_type
            or "application/octet-stream"
        ),

        filename=(
            row.mou_original_name
            or "MOU-Agreement"
        )
    )


# =========================================================
# DELETE MOU
# =========================================================

@router.delete("/{client_id}/mou")
def delete_mou(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    delete_stored(
        row.mou_stored_name
    )


    row.mou_original_name = None

    row.mou_stored_name = None

    row.mou_content_type = None

    row.mou_size_bytes = None


    db.commit()


    return {
        "message":
            "MOU Agreement deleted"
    }


# =========================================================
# DELETE CLIENT
# =========================================================

@router.delete("/{client_id}")
def delete_client(
    client_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):

    row = get_client_or_404(
        client_id,
        db
    )


    # Remove stored files
    delete_stored(
        row.photo_stored_name
    )

    delete_stored(
        row.aadhar_stored_name
    )

    delete_stored(
        row.mou_stored_name
    )


    db.delete(row)

    db.commit()


    return {
        "message":
            "Client deleted successfully"
    }

