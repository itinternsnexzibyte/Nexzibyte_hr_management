import json
from pathlib import Path
from datetime import datetime
from html import escape
import base64
from html.parser import HTMLParser
from io import BytesIO
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Intern, User
from ..email_service import send_email
from ..config import settings

router = APIRouter(prefix='/api/payroll', tags=['Payroll'])
STORE = Path(__file__).resolve().parents[2] / 'storage' / 'payroll_records'
STORE.mkdir(parents=True, exist_ok=True)

class _TextFromHTML(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]
    def handle_data(self, data):
        value=' '.join(data.split())
        if value: self.parts.append(value)
    def handle_starttag(self, tag, attrs):
        if tag in {'br','p','tr','h1','h2','header','div'}: self.parts.append('\n')

def _fallback_pdf(data, intern):
    """Create a readable PDF fallback when the browser did not submit its exported PDF."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    except ImportError as exc:
        raise RuntimeError('PDF support is missing. Install backend requirements and retry.') from exc
    out=BytesIO(); doc=SimpleDocTemplate(out,pagesize=A4,rightMargin=17*mm,leftMargin=17*mm,topMargin=14*mm,bottomMargin=14*mm)
    styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name='PayslipTitle',parent=styles['Title'],textColor=colors.HexColor('#213b60'),fontSize=18,leading=22,alignment=1))
    money=lambda x:f'₹{float(x or 0):,.2f}'
    story=[Paragraph('NexziByte Solutions Pvt Ltd',styles['Heading2']),Paragraph('EMPLOYEE PAYSLIP',styles['PayslipTitle']),Spacer(1,8)]
    details=[[f"Period: {data.get('period','')}",f"Status: {data.get('status','Pending')}"],[f"Name: {intern.name}",f"Email: {intern.email}"],[f"Designation: {data.get('designation','Intern')}",f"Days worked: {data.get('daysWorked',0)} / {data.get('days',0)}"]]
    t=Table(details,colWidths=[85*mm,85*mm]); t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),6)])); story += [t,Spacer(1,8)]
    earnings=[['Earnings','Amount'],['Monthly basic salary',money(data.get('basic'))],['Basic payable',money(data.get('basicPay'))],['HRA',money(data.get('hra'))],['Conveyance allowance',money(data.get('conveyance'))],['Medical / other allowance',money(data.get('other'))],['Overtime / bonus',money(data.get('bonus'))],['Total earnings',money(data.get('earnings'))]]
    deductions=[['Deductions','Amount'],['Income tax',money(data.get('tax'))],['EPF / employee contribution',money(data.get('epf'))],['ESI / professional tax',money(data.get('otherDeduction'))],['Late penalty / other deduction',money(data.get('penalty'))],['Total deductions',money(data.get('deductions'))]]
    for rows in (earnings,deductions):
        t=Table(rows,colWidths=[120*mm,50*mm]); t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.5,colors.HexColor('#b8c8d8')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#d9effb')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('BACKGROUND',(0,-1),(-1,-1),colors.HexColor('#e0efff')),('FONTNAME',(0,-1),(-1,-1),'Helvetica-Bold'),('PADDING',(0,0),(-1,-1),7)])); story += [t,Spacer(1,10)]
    story += [Paragraph(f"<b>Net salary received: {money(data.get('net'))}</b>",ParagraphStyle('Net',parent=styles['Heading2'],backColor=colors.HexColor('#d7eaff'),borderPadding=9,textColor=colors.HexColor('#213b60'))),Spacer(1,8),Paragraph(f"Total working days: {data.get('days',0)} · Paid leave days: {data.get('leave',0)}",styles['BodyText']),Paragraph('Notes / payment reference: '+str(data.get('notes') or '—').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText'])]
    doc.build(story); return out.getvalue()

class PayrollPayload(BaseModel):
    internId: int
    internName: str
    internEmail: str = ''
    month: str
    period: str
    designation: str = 'Intern'
    basic: float = 0
    hra: float = 0
    conveyance: float = 0
    other: float = 0
    bonus: float = 0
    tax: float = 0
    epf: float = 0
    otherDeduction: float = 0
    penalty: float = 0
    days: int = 0
    daysWorked: float = 0
    dailyBasic: float = 0
    basicPay: float = 0
    leave: int = 0
    status: str = 'Pending'
    notes: str = ''
    sendEmail: bool = False
    earnings: float = 0
    deductions: float = 0
    net: float = 0
    savedAt: str = ''
    editedHtml: str = ''
    hoursPerDay: float = 8
    useNetTime: bool = True
    useDaysWorked: bool = True
    netWorkingSeconds: int = 0
    recordedDays: int = 0
    pdfBase64: str = ''
    changeSummary: str = ''

@router.get('')
def list_payroll(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role != 'admin': raise HTTPException(403, 'Admin access required')
    records=[]
    for path in STORE.glob('*.json'):
        try: records.extend(json.loads(path.read_text(encoding='utf-8')))
        except (ValueError, OSError): continue
    return records

@router.post('')
def save_payroll(payload: PayrollPayload, db: Session = Depends(get_db), user: User = Depends(require_admin)):
    intern = db.get(Intern, payload.internId)
    if not intern: raise HTTPException(404, 'Intern not found')
    data=payload.model_dump()
    pdf_attachment_base64 = data.pop('pdfBase64', '')
    if data['days'] < 1:
        raise HTTPException(422, 'Total working days for the month must be at least 1')
    if data['daysWorked'] > data['days']:
        raise HTTPException(422, 'Days worked cannot exceed total working days')
    data['dailyBasic'] = round(data['basic'] / data['days'], 2)
    day_factor = min(1.0, max(0.0, data.get('recordedDays', data['daysWorked']) / data['days'])) if data.get('useDaysWorked', True) else 1.0
    hours_per_day = min(24.0, max(0.25, float(data.get('hoursPerDay', 8) or 8)))
    data['hoursPerDay'] = hours_per_day
    if not data.get('useNetTime', True) and not data.get('useDaysWorked', True):
        raise HTTPException(422, 'Select at least one basic-pay calculation method')
    time_factor = min(1.0, max(0.0, data.get('netWorkingSeconds', 0) / (data['days'] * hours_per_day * 3600))) if data.get('useNetTime', True) else 1.0
    if data.get('useNetTime', True) and data.get('useDaysWorked', True): factor = min(day_factor, time_factor)
    elif data.get('useNetTime', True): factor = time_factor
    elif data.get('useDaysWorked', True): factor = day_factor
    else: factor = 1.0
    data['basicPay'] = round(data['basic'] * factor, 2)
    data['earnings'] = round(data['basicPay'] + data['hra'] + data['conveyance'] + data['other'] + data['bonus'], 2)
    data['deductions'] = round(data['tax'] + data['epf'] + data['otherDeduction'] + data['penalty'], 2)
    data['net'] = round(data['earnings'] - data['deductions'], 2)
    data['internName']=intern.name
    data['internEmail']=intern.email
    data['savedAt']=datetime.utcnow().isoformat()
    path=STORE / f"intern_{intern.id}.json"
    try: records=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
    except ValueError: records=[]
    previous = next((r for r in records if r.get('month') == data['month']), None)
    if previous:
        ignored = {'savedAt','changeHistory','pdfBase64','editedHtml','changeSummary','email_status'}
        changes=[]
        labels={'basic':'Monthly basic salary','basicPay':'Basic payable','hra':'HRA','conveyance':'Conveyance','other':'Other allowance','bonus':'Bonus','tax':'Income tax','epf':'EPF','otherDeduction':'ESI / professional tax','penalty':'Penalty','days':'Working days','daysWorked':'Days worked','leave':'Paid leave days','status':'Status','notes':'Notes / payment reference','designation':'Designation'}
        for field,label in labels.items():
            before=previous.get(field); after=data.get(field)
            if str(before if before is not None else '') != str(after if after is not None else ''):
                changes.append(f"{label}: {before if before is not None else '—'} → {after if after is not None else '—'}")
        history=list(previous.get('changeHistory') or [])
        if changes:
            data['changeSummary']='; '.join(changes)
            history.append({'changedAt':datetime.utcnow().isoformat(),'summary':data['changeSummary']})
        else:
            data['changeSummary']='No field changes detected.'
        data['changeHistory']=history
    else:
        data['changeSummary']='Initial payroll record created.'
        data['changeHistory']=[{'changedAt':datetime.utcnow().isoformat(),'summary':data['changeSummary']}]
    records=[r for r in records if r.get('month') != data['month']]
    records.append(data)
    path.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    email_status='not_requested'
    if data['sendEmail']:
        if not settings.email_host or not settings.email_from: raise HTTPException(503, 'Email is not configured. Set SMTP settings in backend/.env, then retry.')
        if not intern.email: raise HTTPException(400, 'Selected intern has no email address')
        body=(f"Hello {intern.name},\n\nYour NexziByte payslip for {data['period']} is attached.\nStatus: {data['status']}\nTotal earnings: ₹{data['earnings']:.2f}\nTotal deductions: ₹{data['deductions']:.2f}\nNet salary: ₹{data['net']:.2f}\n\nPlease contact HR if any details need correction.")
        try:
            pdf_bytes = b''
            if pdf_attachment_base64:
                try: pdf_bytes = base64.b64decode(pdf_attachment_base64, validate=True)
                except Exception: raise HTTPException(422, 'The exported payslip PDF was invalid. Download the PDF again and retry.')
                if not pdf_bytes.startswith(b'%PDF-'):
                    raise HTTPException(422, 'The exported payslip is not a valid PDF. Please retry the save.')
            else:
                pdf_bytes = _fallback_pdf(data, intern)
            filename = f"NexziByte_Payslip_{data['period']}.pdf"
            send_email(intern.email, f"NexziByte payslip - {data['period']}", body,
                       attachments=[(filename, "application/pdf", pdf_bytes)])
            email_status='sent'
        except Exception as exc:
            email_status='failed'
            raise HTTPException(502, f'Payroll saved, but email could not be sent: {exc}')
    data['email_status']=email_status
    return {'message':'Payroll saved','record':data,'email_status':email_status}
