from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, delete
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Attendance, Intern, User, WorkSession, AttendanceBreak, AttendanceLocation, AttendanceAccessRequest
from ..schemas.core import AttendanceIn
from ..services.attendance import now_ist, check_in, daily_records, parse_time, record_location, haversine_meters
from datetime import datetime
router = APIRouter(prefix="/api/attendance", tags=["Attendance"])

def own_intern(db, user):
    if user.role not in ("student", "intern"):
        raise HTTPException(403,"Intern access required")
    intern = db.scalar(select(Intern).where(Intern.user_id == user.id).with_for_update())
    if not intern:
        raise HTTPException(404,"Intern details are not linked to this account")
    return intern

@router.get("")
def list_attendance(attendance_date: date | None = None, intern_id: int | None = None, db: Session=Depends(get_db), user: User=Depends(get_current_user)):
    if user.role != "admin":
        intern_id = own_intern(db,user).id
    return daily_records(db,intern_id,attendance_date)

@router.post("/login")
@router.post("/check-in")
def attendance_login(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    if user.role == "admin":
        return {"attendance_recorded":False}
    intern=own_intern(db,user)
    if not user.attendance_enabled:
        pending = db.scalar(select(AttendanceAccessRequest).where(
            AttendanceAccessRequest.intern_id == intern.id,
            AttendanceAccessRequest.status == "pending"
        ))
        raise HTTPException(403, "Automatic attendance is disabled after a forced checkout. Submit a valid reason for admin approval.")
    row = check_in(db,intern)
    active = db.scalar(select(WorkSession).where(
        WorkSession.attendance_id == row.id,
        WorkSession.ended_at.is_(None)
    ).order_by(WorkSession.id.desc()))
    if active:
        active.last_heartbeat_at = now_ist()
    db.commit()
    return {"message":"Checked in", "attendance_recorded":True, "attendance":daily_records(db,intern.id,now_ist().date())[0]}


@router.post("/heartbeat")
def attendance_heartbeat(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    now=now_ist()
    ids=list(db.scalars(select(Attendance.id).where(
        Attendance.intern_id==intern.id,
        Attendance.attendance_date==now.date()
    )))
    active=db.scalar(select(WorkSession).where(
        WorkSession.attendance_id.in_(ids),
        WorkSession.ended_at.is_(None)
    ).order_by(WorkSession.id.desc()))
    if active is None:
        return {"active": False}
    active.last_heartbeat_at=now
    db.commit()
    return {"active": True, "server_time": now.isoformat()}


@router.post("/gps")
def attendance_gps(latitude: float, longitude: float, accuracy: float | None = None,
                   db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    now=now_ist()
    ids=list(db.scalars(select(Attendance.id).where(
        Attendance.intern_id==intern.id,
        Attendance.attendance_date==now.date()
    )))
    active=db.scalar(select(WorkSession).where(
        WorkSession.attendance_id.in_(ids),
        WorkSession.ended_at.is_(None)
    ).order_by(WorkSession.id.desc()))
    if active is None:
        raise HTTPException(409, "No active attendance session")
    row=record_location(db, active.attendance_id, latitude, longitude, accuracy, now)
    active.last_heartbeat_at=now
    db.commit()
    return {
        "message": "GPS location recorded",
        "latitude": row.latitude,
        "longitude": row.longitude,
        "accuracy_meters": row.accuracy_meters,
        "distance_from_start_meters": row.distance_from_start_meters,
    }


class AttendanceAccessReason(BaseModel):
    reason: str = Field(min_length=10, max_length=2000)


@router.post("/access-request")
def request_attendance_access(data: AttendanceAccessReason, db: Session=Depends(get_db), user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    if user.attendance_enabled:
        return {"message":"Attendance is already enabled", "status":"approved"}
    pending=db.scalar(select(AttendanceAccessRequest).where(
        AttendanceAccessRequest.intern_id==intern.id,
        AttendanceAccessRequest.status=="pending"
    ))
    if pending:
        return {"message":"Your reason is already waiting for admin approval.", "status":"pending"}
    req=AttendanceAccessRequest(intern_id=intern.id, reason=data.reason.strip(), status="pending")
    db.add(req)
    db.commit()
    # Email every configured admin; admin portal also polls pending requests.
    from ..email_service import send_email
    from ..config import settings
    if settings.admin_email:
        send_email(settings.admin_email, "Intern attendance reactivation request",
                   f"Intern {intern.name} ({intern.intern_code or intern.id}) requested attendance access again.\\n\\nReason:\\n{req.reason}\\n\\nPlease review it in the Admin Approvals portal.")
    return {"message":"Reason submitted. Waiting for admin approval.", "status":"pending", "id":req.id}


@router.get("/access-status")
def attendance_access_status(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    pending=db.scalar(select(AttendanceAccessRequest).where(
        AttendanceAccessRequest.intern_id==intern.id,
        AttendanceAccessRequest.status=="pending"
    ))
    latest=db.scalar(select(AttendanceAccessRequest).where(
        AttendanceAccessRequest.intern_id==intern.id
    ).order_by(AttendanceAccessRequest.id.desc()))
    return {
        "attendance_enabled": bool(user.attendance_enabled),
        "pending_request": bool(pending),
        "latest_request": {"id":latest.id,"reason":latest.reason,"status":latest.status,"created_at":latest.created_at} if latest else None
    }

@router.post("/logout")
@router.post("/check-out")
def attendance_logout(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    if user.role == "admin":
        return {"attendance_recorded":False}
    intern=own_intern(db,user)
    now=now_ist()
    ids=list(db.scalars(select(Attendance.id).where(Attendance.intern_id==intern.id,Attendance.attendance_date==now.date())))
    for model in (WorkSession,AttendanceBreak):
        for item in db.scalars(select(model).where(model.attendance_id.in_(ids),model.ended_at.is_(None))).all():
            item.ended_at=now
    for row in db.scalars(select(Attendance).where(Attendance.id.in_(ids))).all():
        if row.logout_time is None:
            row.logout_time=now.strftime("%H:%M:%S")
        row.status="Present"
    db.flush()
    data=daily_records(db,intern.id,now.date())
    if data:
        db.get(Attendance,data[0]["id"]).working_minutes=data[0]["working_minutes"]
    db.commit()
    return {"message":"Checked out; any active break was ended", "attendance_recorded":bool(data)}

@router.post("/break-in")
def break_in(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    now=now_ist()
    ids=list(db.scalars(select(Attendance.id).where(Attendance.intern_id==intern.id,Attendance.attendance_date==now.date())))
    session=db.scalar(select(WorkSession).where(WorkSession.attendance_id.in_(ids),WorkSession.ended_at.is_(None)))
    if session is None:
        raise HTTPException(409,"Check in before starting a break")
    if db.scalar(select(AttendanceBreak).where(AttendanceBreak.attendance_id.in_(ids),AttendanceBreak.ended_at.is_(None))):
        raise HTTPException(409,"A break is already running")
    db.add(AttendanceBreak(attendance_id=session.attendance_id,started_at=now))
    db.commit()
    return {"message":"Break started"}

@router.post("/break-out")
def break_out(db: Session=Depends(get_db),user: User=Depends(get_current_user)):
    intern=own_intern(db,user)
    ids=list(db.scalars(select(Attendance.id).where(Attendance.intern_id==intern.id,Attendance.attendance_date==now_ist().date())))
    row=db.scalar(select(AttendanceBreak).where(AttendanceBreak.attendance_id.in_(ids),AttendanceBreak.ended_at.is_(None)))
    if row is None:
        raise HTTPException(409,"There is no active break")
    row.ended_at=now_ist()
    db.commit()
    return {"message":"Break ended"}

@router.post("")
def upsert_attendance(data:AttendanceIn,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    intern=db.scalar(select(Intern).where(Intern.id==data.intern_id).with_for_update())
    if not intern:
        raise HTTPException(404,"Intern not found")
    rows=db.scalars(select(Attendance).where(Attendance.intern_id==intern.id,Attendance.attendance_date==data.attendance_date).order_by(Attendance.id)).all()
    ids=[r.id for r in rows]
    if db.scalar(select(WorkSession).where(WorkSession.attendance_id.in_(ids),WorkSession.ended_at.is_(None))):
        raise HTTPException(409,"Check out the active session before editing attendance")
    if db.scalar(select(AttendanceBreak).where(AttendanceBreak.attendance_id.in_(ids))):
        raise HTTPException(409,"Attendance with recorded breaks cannot be replaced manually")
    start=parse_time(data.login_time) if data.login_time else None
    end=parse_time(data.logout_time) if data.logout_time else None
    if data.login_time and not start or data.logout_time and not end:
        raise HTTPException(422,"Use valid check-in/check-out times")
    if start and end and end<start:
        raise HTTPException(422,"Check-out must follow check-in on the selected day")
    row=rows[0] if rows else Attendance(intern_id=intern.id,attendance_date=data.attendance_date)
    db.add(row)
    for k,v in data.model_dump().items():
        setattr(row,k,v)
    db.flush()
    # Replace only the session history for manually corrected records, after validation.
    db.execute(delete(WorkSession).where(WorkSession.attendance_id.in_(ids)))
    db.execute(delete(AttendanceLocation).where(AttendanceLocation.attendance_id.in_(ids)))
    for extra in rows[1:]:
        db.delete(extra)
    if start:
        db.add(WorkSession(attendance_id=row.id,started_at=datetime.combine(data.attendance_date,start),ended_at=datetime.combine(data.attendance_date,end) if end else None))
    db.commit()
    return {"message":"Attendance saved", "id":row.id}

@router.delete("/{attendance_id}")
def delete_attendance(attendance_id:int,db:Session=Depends(get_db),user:User=Depends(require_admin)):
    row=db.get(Attendance,attendance_id)
    if not row:
        raise HTTPException(404,"Attendance not found")
    ids=list(db.scalars(select(Attendance.id).where(Attendance.intern_id==row.intern_id,Attendance.attendance_date==row.attendance_date)))
    for model in (AttendanceBreak,WorkSession,Attendance):
        col=model.id if model is Attendance else model.attendance_id
        db.execute(delete(model).where(col.in_(ids)))
    db.commit()
    return {"message":"Daily attendance deleted"}
