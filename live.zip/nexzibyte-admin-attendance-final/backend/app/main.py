from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import inspect, text
import threading
import time

from .config import settings
from .database import Base, engine
from . import models  # noqa: F401
from .routes import workforce, auth, interns, documents, attendance, assignments, ratings, employees, us_client, dashboard, admin, payroll

app = FastAPI(title="Nexzibyte Admin Attendance API", version="1.0.0")

origins = [settings.frontend_url]
print("CORS ORIGINS:", origins)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5500",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(workforce.router)
app.include_router(auth.router)
app.include_router(interns.router)
app.include_router(documents.router)
app.include_router(attendance.router)
app.include_router(assignments.router)
app.include_router(ratings.router)
app.include_router(employees.router)
app.include_router(us_client.router)
app.include_router(dashboard.router)
app.include_router(admin.router)
app.include_router(payroll.router)


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    # Lightweight schema upgrade for existing installations. New tables are
    # handled by create_all; these ALTERs add only the new feature columns.
    with engine.begin() as conn:
        inspector = inspect(conn)
        migrations = {
            "interns": [("teams_id", "VARCHAR(150) NULL")],
            "users": [("attendance_enabled", "BOOLEAN NOT NULL DEFAULT TRUE")],
            "work_sessions": [
                ("last_heartbeat_at", "DATETIME NULL"),
                ("forced_checkout", "BOOLEAN NOT NULL DEFAULT FALSE"),
                ("checkout_reason", "VARCHAR(100) NULL"),
            ],
        }
        for table, columns in migrations.items():
            existing = {c["name"] for c in inspect(conn).get_columns(table)}
            for name, definition in columns:
                if name not in existing:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {definition}"))

    from .database import SessionLocal
    from .services.attendance import import_legacy_sessions, force_checkout_inactive
    with SessionLocal() as db:
        import_legacy_sessions(db)
        db.commit()

    def attendance_watchdog():
        while True:
            try:
                with SessionLocal() as db:
                    force_checkout_inactive(db, timeout_seconds=8)
            except Exception as error:
                print("Attendance watchdog warning:", error)
            time.sleep(1)

    threading.Thread(target=attendance_watchdog, daemon=True, name="attendance-watchdog").start()
    from .database import SessionLocal
    from .services.attendance import import_legacy_sessions
    with SessionLocal() as db:
        import_legacy_sessions(db)
        db.commit()


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "Nexzibyte Admin Attendance"}
