from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException, UploadFile

from .config import settings


BASE_STORAGE = Path(__file__).resolve().parents[1] / "storage"
BASE_STORAGE.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png"}


def safe_extension(filename: str) -> str:
    ext = Path(filename or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Unsupported file type")
    return ext


async def save_upload(upload: UploadFile) -> tuple[str, str, int]:
    ext = safe_extension(upload.filename or "")
    data = await upload.read()
    max_bytes = settings.max_file_size_mb * 1024 * 1024
    if len(data) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.max_file_size_mb} MB")
    stored_name = f"{uuid4().hex}{ext}"
    path = BASE_STORAGE / stored_name
    path.write_bytes(data)
    return stored_name, upload.content_type or "application/octet-stream", len(data)


def delete_stored(stored_name: str | None) -> None:
    if not stored_name:
        return
    path = BASE_STORAGE / Path(stored_name).name
    if path.exists():
        path.unlink()
