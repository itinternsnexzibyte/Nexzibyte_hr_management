import os
os.environ.setdefault('DATABASE_URL','sqlite:///./test_nexzibyte.db')
os.environ.setdefault('SECRET_KEY','test-secret')
from datetime import datetime, date, timedelta
from io import BytesIO
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.database import Base, get_db
from app.models import User, Intern, Attendance
from app.security import hash_password, create_access_token
from app.services import attendance as svc
from app.routes import attendance as routes
from app.routes import workforce

@pytest.fixture
def env(monkeypatch,tmp_path):
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool)
    @event.listens_for(engine,'connect')
    def fk(conn,_): conn.execute('PRAGMA foreign_keys=ON')
    Base.metadata.create_all(engine)
    factory=sessionmaker(engine,expire_on_commit=False)
    def override():
        with factory() as db: yield db
    app.dependency_overrides[get_db]=override
    clock=[datetime.combine(date.today(),datetime.min.time()).replace(hour=10)]
    monkeypatch.setattr(svc,'now_ist',lambda:clock[0]);monkeypatch.setattr(routes,'now_ist',lambda:clock[0]);monkeypatch.setattr(workforce,'BASE_STORAGE',tmp_path)
    with factory() as db:
        users=[User(name=n,email=e,role=r,password_hash=hash_password('Password123'),is_verified=True,approval_status='approved') for n,e,r in [('Admin','admin@test.com','admin'),('Intern One','one@test.com','student'),('Intern Two','two@test.com','student')]]
        db.add_all(users);db.flush()
        interns=[Intern(name=u.name,email=u.email,user_id=u.id,intern_code=f'00{u.id}',joining_date=date.today(),status='Active') for u in users[1:]]
        db.add_all(interns);db.commit()
        headers=[{'Authorization':'Bearer '+create_access_token(u.id,u.role)} for u in users];ids=[i.id for i in interns]
    yield TestClient(app),headers,ids,clock,factory
    app.dependency_overrides.clear();engine.dispose()

def test_repeat_login_breaks_daily_count(env):
    c,h,ids,t,_=env
    for _ in range(3): assert c.post('/api/auth/login',json={'email':'one@test.com','password':'Password123'}).status_code==200
    t[0]+=timedelta(minutes=30)
    assert c.post('/api/attendance/break-in',headers=h[1]).status_code==200
    assert c.post('/api/attendance/break-in',headers=h[1]).status_code==409
    t[0]+=timedelta(minutes=10);c.post('/api/attendance/break-out',headers=h[1])
    t[0]+=timedelta(minutes=20);c.post('/api/attendance/break-in',headers=h[1])
    t[0]+=timedelta(minutes=5);c.post('/api/attendance/check-out',headers=h[1])
    rows=c.get('/api/attendance',headers=h[0]).json()
    assert len(rows)==1 and rows[0]['break_seconds']==900 and rows[0]['working_seconds']==3000
    assert len(rows[0]['breaks'])==2
    t[0]+=timedelta(minutes=10);c.post('/api/auth/login',json={'email':'one@test.com','password':'Password123'})
    t[0]+=timedelta(minutes=15);c.post('/api/attendance/check-out',headers=h[1])
    rows=c.get('/api/attendance',headers=h[0]).json()
    assert len(rows)==1 and rows[0]['session_count']==2 and rows[0]['working_seconds']==3900
    assert c.get('/api/dashboard/summary',headers=h[0]).json()['today_attendance']==1

def test_break_without_checkin_and_isolation(env):
    c,h,ids,t,_=env
    assert c.post('/api/attendance/break-in',headers=h[1]).status_code==409
    c.post('/api/attendance/check-in',headers=h[1])
    assert c.get(f'/api/attendance?intern_id={ids[0]}',headers=h[2]).json()==[]
    assert c.get(f'/api/interns/{ids[0]}',headers=h[2]).status_code==403

def test_calendar_notification_delivery_and_read_ownership(env):
    c,h,ids,t,_=env
    data={'title':'Project review','event_date':str(t[0].date()),'event_time':'14:00','color':'#f3c440','description':'Bring work'}
    r=c.post('/api/calendar/events',headers=h[0],json=data);assert r.status_code==201,r.text
    eid=r.json()['id']
    for header in h[1:]: assert c.get('/api/notifications',headers=header).json()['unread_count']==1
    data.update(title='Updated review',intern_id=ids[0],event_date=str(t[0].date()+timedelta(days=1)))
    assert c.put(f'/api/calendar/events/{eid}',headers=h[0],json=data).status_code==200
    assert c.get('/api/calendar/events',headers=h[2]).json()==[]
    assert c.get('/api/notifications',headers=h[1]).json()['unread_count']==2
    assert c.post('/api/calendar/events',headers=h[1],json=data).status_code==403
    c.delete(f'/api/calendar/events/{eid}',headers=h[0])
    assert c.get('/api/notifications',headers=h[1]).json()['unread_count']==3
    nid=c.get('/api/notifications',headers=h[1]).json()['items'][0]['id']
    assert c.post(f'/api/notifications/{nid}/read',headers=h[2]).status_code==404
    c.post('/api/notifications/read-all',headers=h[1])
    assert c.get('/api/notifications',headers=h[1]).json()['unread_count']==0
    assert len(c.get('/api/notifications',headers=h[1]).json()['items'])==3

def test_assignment_target_and_content_protection(env):
    c,h,ids,t,_=env
    r=c.post('/api/assignments',headers=h[0],json={'title':'Build API','intern_id':ids[0],'due_date':str(t[0].date()),'description':'Use FastAPI'})
    assert r.status_code==201,r.text
    aid=r.json()['id']
    assert c.get('/api/notifications',headers=h[1]).json()['unread_count']==1
    assert c.get('/api/notifications',headers=h[2]).json()['unread_count']==0
    assert c.get('/api/assignments',headers=h[2]).json()==[]
    assert c.put(f'/api/assignments/{aid}',headers=h[2],json={'status':'Completed'}).status_code==403
    assert c.put(f'/api/assignments/{aid}',headers=h[1],json={'title':'Tampered','status':'Completed'}).status_code==403
    assert c.put(f'/api/assignments/{aid}',headers=h[1],json={'status':'In Progress'}).status_code==200
    assert c.put(f'/api/assignments/{aid}',headers=h[0],json={'due_date':str(t[0].date()+timedelta(days=1))}).status_code==200
    assert c.get('/api/notifications',headers=h[1]).json()['unread_count']==2
    assert c.post(f'/api/assignments/{aid}/submit',headers=h[1],json={'submission_text':'Done'}).status_code==200
    assert c.get(f'/api/assignments/{aid}/submissions',headers=h[2]).status_code==403

def test_photo_validation_and_access(env):
    c,h,ids,t,_=env
    buf=BytesIO();Image.new('RGB',(40,40),'yellow').save(buf,format='PNG')
    r=c.post('/api/profiles/me/photo',headers=h[1],files={'file':('pic.png',buf.getvalue(),'image/png')});assert r.status_code==200,r.text
    assert c.get(f'/api/profiles/{ids[0]}/photo',headers=h[0]).status_code==200
    assert c.get(f'/api/profiles/{ids[0]}/photo',headers=h[1]).headers['content-type']=='image/jpeg'
    assert c.get(f'/api/profiles/{ids[0]}/photo',headers=h[2]).status_code==403
    assert c.get(f'/api/profiles/{ids[0]}/photo').status_code==401
    assert c.post('/api/profiles/me/photo',headers=h[1],files={'file':('fake.png',b'not image','image/png')}).status_code==400
    assert c.post('/api/profiles/me/photo',headers=h[1],files={'file':('huge.png',b'a'*(5*1024*1024+1),'image/png')}).status_code==413

def test_legacy_duplicates_count_once_and_overlap_not_added(env):
    c,h,ids,t,factory=env
    with factory() as db:
        db.add_all([Attendance(intern_id=ids[0],attendance_date=t[0].date(),login_time='09:00:00',logout_time='10:00:00',status='Present'),Attendance(intern_id=ids[0],attendance_date=t[0].date(),login_time='09:30:00',logout_time='10:00:00',status='Present')]);db.commit();svc.import_legacy_sessions(db);db.commit()
    rows=c.get('/api/attendance',headers=h[0]).json()
    assert len(rows)==1 and rows[0]['working_seconds']==3600
    assert c.get('/api/dashboard/summary',headers=h[0]).json()['today_attendance']==1
    assert c.get('/api/attendance?attendance_date=2000-01-01',headers=h[0]).json()==[]

def test_midnight_closes_previous_day_break(env):
    c,h,ids,t,_=env
    t[0]=t[0].replace(hour=23,minute=30);c.post('/api/attendance/check-in',headers=h[1])
    t[0]+=timedelta(minutes=15);c.post('/api/attendance/break-in',headers=h[1])
    t[0]+=timedelta(minutes=45);c.post('/api/attendance/check-in',headers=h[1])
    rows=c.get('/api/attendance',headers=h[1]).json();old=rows[1]
    assert old['break_seconds']==900 and old['working_seconds']==900
    assert not old['on_break'] and not old['is_online'] and len(rows)==2
