# Payroll draft/save behavior update

- Editing payroll fields or the editable payslip preview does not trigger a save or send an email by itself.
- Click **Save payroll** to persist the selected intern's payroll. If **Email the payslip to this intern after saving** is selected, the backend sends the email during that explicit save operation, after writing the payroll record.
- Pressing **Enter** in a payroll input moves focus to the next visible payroll field instead of submitting the form early. Use the **Save payroll** button when ready to commit.
- **Save payslip as PDF** opens the editable preview and launches the browser print dialog so the user can save it as a PDF; it does not save payroll data or send an email.
- After a successful email send, the saved UI record clears the email checkbox to reduce accidental duplicate sends on the next edit.

The automated pytest command did not finish within the available test window. JavaScript syntax validation (`node --check`) and Python compilation checks completed successfully.
