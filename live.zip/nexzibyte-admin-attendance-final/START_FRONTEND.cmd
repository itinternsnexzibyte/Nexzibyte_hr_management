@echo off
setlocal
cd /d "%~dp0frontend"
start "" "http://localhost:5500/login.html"
python -m http.server 5500
pause
