# Enhanced Attendance Features

## Added
- GPS tracking starts at check-in and records view-only location history.
- Current GPS coordinates, accuracy, distance from check-in, and movement history are visible to the intern and admin.
- GPS data cannot be edited from either portal.
- Browser heartbeat detects prolonged inactivity/sleep/shutdown/crash and the backend watchdog forces checkout.
- Forced checkout records the last confirmed heartbeat time and marks the session as `Forced checkout`.
- Forced checkout disables further attendance until an intern submits a reason.
- The reason is emailed to the configured admin and appears in Admin -> Approvals.
- Admin approval re-enables attendance and emails the intern.
- Check-in/check-out counts, work sessions, total working time, and total break time are shown.
- Calendar supports month navigation and admin intern selection for month-level attendance records and totals.
- Intern profile details include Teams ID.

## Important behavior
GPS requires browser location permission. If location permission is denied, attendance can still be recorded, but GPS history cannot be captured.
A browser/device that is fully powered off cannot send a signal at the exact moment it powers off; the backend heartbeat watchdog therefore detects the missing signal and forces checkout after the configured timeout (60 seconds).


## Faster automatic checkout notifications

- Intern heartbeat is sent every 5 seconds while the portal is active.
- The backend force-checkout threshold is 15 seconds without a heartbeat.
- The watchdog checks every 2 seconds, so detection is usually around 15–17 seconds after the last heartbeat, plus runtime scheduling.
- Forced-checkout emails are submitted to a small background worker pool after the attendance transaction commits, so SMTP delays do not block the watchdog.
- SMTP connection timeout is 8 seconds. Actual inbox delivery still depends on the SMTP provider.
- A brief network interruption may trigger forced checkout; use admin approval to restore attendance.
